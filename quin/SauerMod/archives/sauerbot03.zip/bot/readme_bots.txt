= SauerBot =

Current Version: v0.3 (BETA)

Offline test and practice AI for the Sauerbraten Engine by Quinton Reeves.

== Introduction ==

''SauerBot'' is ''gameplay modification'' based on the current CVS version of the Sauerbraten Engine, efforts will be made to maintain compatibility. The overall goal will be for an effective AI for offline multiplayer games, which can be added easily to any version of Sauerbraten (or mod thereof) through the modularity provided by the object orientivity (C++) of current builds.

The source for this project is a derivitave work of ''fpsgame'' and moreso ''monster.h'' therein. It is released under the Sauerbraten Engine License, which you can find in Sauerbraten or ''bot/readme_source.txt''.

== Getting Started ==

As a ''gameplay modification'', you are given the source files (and perhaps executables) to provide the gameplay. You must already have, or obtain, the current full distribution of the Sauerbraten Engine [[http://sauerbraten.org]].

To run, extract the contents of this archive directly into your Sauerbraten directory, keeping paths intact. It will not overwrite or otherwise modify any original Sauerbraten data.

== Building ==

Currently, only a Microsoft Windows 32bit build is provided. If you are on another operating system/architechture you will need to compile your own binaries (which is beyond the scope of this document).

Included in the ''bot/'' directory is only the //modified source files//. Copy the contents of your Sauerbraten installations ''src/'' and //DO NOT OVERWRITE// the included files, then all should go well.

== ToDo ==

 * improve waypoint auto-dropping (detect invalid points, remove points that lead to death).
 * improve waypoint navigation (move away from current position(s), edge falling)
 * weapon switching (check most appropriate weapon using waypoint mesh?)
 * projectile evasion
 * water and jumppad detection
 * strafing (and tricks?)
 * home in on vectors using waypoints for guidance (fall-off-edge bug/ignoring invalid vectors)
 * have some form of navigation without waypoints again?
 * identify points of interest and home in on them (quad, health, etc), especially if needed

== Changes ==

 - sauerbraten gui edition
 * make cg shooting smarter/faster
 * don't populate bots automatically on waypointless maps
 * update internal nodes after teleport
 * entity/pickup emulation
 * timings tweaks to improve stupidity:accuracy ratio
 * bots avoid shooting teammates directly in team games
 * preliminary weapon switching
 * improved source layout for modularity and compilation on other machines/mods
 - sauerbraten water edition
 * colourful ''to'' and ''from'' waypoint nodes in botshow mode
 * improved navigation choices
 * bots node choices limited to ones that haven't been to last
 * waypoint dropping takes into account corners and finds/creates needed nodes if out of sight
 * improved waypoint dropping to take into account line of sight (no more paths through walls)
 * preliminary strafing with added randomness
 * reduce fakeness of retaliation by homing in first (to look like a search)
 * limit line of sight angles
 * limit line of sight distances
 * force bots to wait a little after being fragged
 * cl.bs.botkilled() added for cl.dodamage()
 - sauerbraten normalmap edition
 * initial version

== Commands ==

{{
	botadd N T
}}
Loads ''N'' bots at rate ''T'', both parameters are optional and defaults will be provided.

{{
	botdel N
}}
Deletes ''N'' bots, the parameter is optional. No value will delete one bot, a value of ''0'' will delete all bots.

{{
	botload
	botsave
}}
Load and save commands for the associated waypoint file of the current map. Note that loading is done automatically if the waypoint file is found on map start.

== Variables ==

{{
	botrate N
}}
Sets the automatically provided rate of update and judgement errors for loading bots, from ''1..100'' (default: 10).

{{
	botauto B
}}
Toggles bot automatic loading on map start, boolean ''0'' or ''1'' (default: 1).

{{
	botnum N
}}
Sets how many bots to load when automatically loading bots, from ''0..15'' (default: 0). A value of ''0'' makes it determine the number based on the amount of ''PLAYERSTART'' entities in the map.

{{
	botdrop B
}}
Toggles automatic waypoint dropping during movement around the level, boolean ''0' or ''1'' (default: 0). The value of this is determined on map start, if there is no waypoint file it will default to ''1'' and generate some waypoints from selected entities.

{{
	botshow B
}}
Toggles viewing of bot and waypoint debugging information, boolean ''0'' or ''1'' (default: 0). This currently just shows waypoint positions and node links and is also determined on map start, if there is no waypoint file it will default to ''1''.

== Mod Installation ==

The following is a quick (and unsupported) guide to installing sauerbot for use with the Sauerbraten source (and mods thereof). Modified the named files with the provided data.

=== fpsgame/fps.cpp ===

{{
    #include "bot.h" // SauerBot by Quin
}}
Add this line before {{ #include "monster.h" }} at the beginning of {{ struct fpsclient : igameclient }}.

{{
    botset      bs; // SauerBot by Quin
}}
Add this line before {{ monsterset ms; }} below {{ weaponstate ws; }}.

{{
	 bs(*this),
}}
Add this to {{ fpsclient() : .. }} after {{ ws(*this), }} but before {{ ms(*this), }}.

{{
        bs.botrender(); // SauerBot by Quin
}}
Add this line to the end of {{ rendergame() }}.

{{
		if (!bs.botplayers(curtime)) // SauerBot by Quin
}}
Add this line to {{ updateworld() }} before {{ otherplayers(); }}.

{{
		bs.botclear(); // SauerBot by Quin
}}
Add this line to {{ startmap() }} before {{ ms.monsterclear(); }}.

{{
        bs.botstart(name, gamemode); // SauerBot by Quin
}}
Add this line to the end of {{ startmap() }}.

{{
		else if(bs.bot((fpsent *)d)) bs.botdamage((fpsent *)d, damage, -1, (fpsent *)d); // SauerBot by Quin
}}
Add this line to {{ worldhurts() }} before {{ else if(d->type==ENT_AI) .. }}.

{{
       			bs.botfrags(act, 1);
}}
Add this to {{ selfdamage() }} above {{ conoutf("\f2you got killed by %s!", &act->name); }}

{{
		       			bs.botfrags(a, -1);
}}
Add this to {{ selfdamage() }} above {{ conoutf("\f2you got fragged by a teammate (%s)", a->name); }}

{{
		       			bs.botfrags(a, 1);
}}
Add this to {{ selfdamage() }} above {{ conoutf("\f2you got fragged by %s", a->name); }}

=== fpsgame/game.h ===

{{
    int botstate, botrate;	  					// SauerBot by Quin
    vec botrot, botvec;		   					// targeting/homing vector
    int botms, botstart;           				// millis at which transition to another aistate takes place
    int botcurnode, botlastnode;				// waypoint nodes
	fpsent *botenemy;                           // bot last enemy
}}
Add this line to {{ struct fpsent : dynent }} after {{ editinfo *edit; }}.

{{
	, botstate(M_NONE)
}}
Add this to the list of defaults in {{ fpsent() : .. }}, right after {{ edit(NULL) }}.

=== fpsgame/weapon.h ===

{{
		else if(cl.bs.bot(d))    { if(isrl) vel.mul(5); d->vel.add(vel); cl.bs.botdamage(d, damage, at==d ? -1 : -2, at); } // SauerBot by Quin
}}
Add this line to {{ hit() }} before {{ else if(d->type==ENT_AI) .. }}.

=== fpsgame/fpsserver.h ===

{{
    char *getdefaultmaster() { return "0"; }; // SauerBot by Quin - Don't use master server.
}}
This should be done as mods are not permitted on public servers.

----
(C) 2006 Quinton Reeves, Sauerbraten ZLIB License.
