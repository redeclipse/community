// SauerBot - Offline test and practice AI by Quinton Reeves

#define BOTVERSION		1 								// SauerBot version
#define BOTWPVERSION	1								// waypoint file format
#define BOTWPDIST		36.0f							// minimum distance between wapoints

#define BOTJUMPDIST		3.5f
#define BOTBACKDIST		36.0f
#define BOTRADIALDIST	48.0f
#define BOTLOSDIST(x)	(514.0f - (x * 2.0))			// = 512 MAX
#define BOTFOVX(x)		(96.5f - (x * 0.5))				// = 96 MAX
#define BOTFOVY(x)		(128.5f - (x * 0.5))			// = 128 MAX
#define BOTRNDMOVE(x)	(rnd(x) == 0 ? rnd(3)-1 : 0)    // -1, 0, 1

struct botway
{
	vec pos;
	vector<int> nodes;
};
