// SauerBot - Offline test and practice AI by Quinton Reeves

void bottrans(fpsent *d, int stat, int mv, int st, bool dev, int n)
{
    d->move = mv;
    d->strafe = st;
	int q = (dev ? rnd(d->botrate) : 0), v = n + q;
	d->botstate = stat;
	d->botms = cl.lastmillis + v;
	conoutf("# %s transition to %d (%d)", d->name, d->botstate, v);
}

void botthink(fpsent *d)
{
	conoutf("# %s is thinking..", d->name);
	if(d->state == CS_SPECTATOR || d->state == CS_EDITING)
	{
		d->state = CS_DEAD;
		bottrans(d, M_PAIN, 0, 0, false, 10);
	}

   	botaction(d);

    if(d->state==CS_ALIVE)
    {
		float bk = curtime * (1.01f - (d->botrate * 0.01f));

		if (d->botstate != M_SLEEP && d->botstate != M_PAIN)
			botvector(d); // recalc bot vector

	    if(d->botrot.y>d->yaw)             // slowly turn bot towards his target
        {
            d->yaw += bk;
            if(d->botrot.y<d->yaw) d->yaw = d->botrot.y;
        }
        else
        {
            d->yaw -= bk;
            if(d->botrot.y>d->yaw) d->yaw = d->botrot.y;
        }

        botquad(d, curtime);
    	botitems(d);

		botmove(d, 2, true); // main update

		if (d->botstate == M_HOME)
		{
			if (d->o.dist(d->botvec) <= d->radius*4)
			{
			    bottrans(d, M_SEARCH, 0, 0, false, 10);
			}
			else if (d->botvec.x-d->o.x <= d->radius*2 && d->botvec.y-d->o.y <= d->radius*2 && d->botvec.z-d->o.z >= BOTJUMPDIST)
			{
				// TODO: check for jumppads
				d->jumpnext = true;
			}
		}
    }
    else
    {
        d->move = d->strafe = 0;

        if(cl.lastmillis-d->lastaction<2000)
        {
			botmove(d, 2, false);
        }
    }
	d->lastupdate = cl.lastmillis;
}

void bothome(fpsent *d, vec &v, int trans, int wp)
{
	conoutf("# %s homing vector %f,%f,%f [%d,%d]", d->name, v.x, v.y, v.z, trans, wp);

	d->botvec.sub(d->botvec);

	if (waypoints.inrange(wp))
	{
		d->botlastnode = d->botcurnode;
		d->botcurnode = wp;
		d->botvec.add(v);
	}
	else
	{
		if (wp == -2)
		{
			d->botvec.add(v);
		}
		else
		{
			while(1)
			{
				d->botcurnode = (waypoints.inrange(d->botcurnode) ? d->botcurnode : botnode(d, true));

				if (waypoints.inrange(d->botcurnode))
				{
					int bwp = -1;
					loopv(waypoints[d->botcurnode]->nodes)
					{
						int node = waypoints[d->botcurnode]->nodes[i];

						if (!waypoints.inrange(bwp) || (waypoints.inrange(node) && waypoints[node]->pos.dist(v) < waypoints[bwp]->pos.dist(v)))
						    bwp = node;
					}
					if (waypoints.inrange(bwp))
					{
						d->botlastnode = d->botcurnode;
						d->botcurnode = bwp;
						d->botvec.add(waypoints[bwp]->pos);
						break;
					}
				}
				botcoord(d, 0);
				return;
			}
		}
	}

	botvector(d);

	if (trans)
	{
		d->botstart = cl.lastmillis;
		bottrans(d, M_HOME, 1, 0, true, trans);
	}
}

bool botenemy(fpsent *d, fpsent *p, int trans)
{
	if (p && d != p && p->state == CS_ALIVE && !botteam(d->team, p->team))
	{
		vec target;

		conoutf("# %s making enemy of %s", d->name, p->name);

		if (insight(d, p->o, target, BOTLOSDIST(d->botrate)))
		{
			int *ammo = d->ammo;

			d->botenemy = p;
			bothome(d, target, 0, -2);

			botweapon(d); // choose most appropriate weapon
			bottrans(d, M_AIMING, (d->o.dist(p->o) > BOTBACKDIST ? 1 : -1), BOTRNDMOVE(d->botrate), true, trans);

			conoutf("# %s aiming at %s", d->name, p->name);
			
			return true;
		}
		else
		{
			bothome(d, p->o, 100*d->botrate, -1);
		}
	}
	return false;
}

bool bottarget(fpsent *d)
{
	vec target;
	float dist[3], c;
	int a = -1, b, lvl = -1, targ[3], amt[3];

	conoutf("# %s looking for target", d->name);
	
	#define inittarg(n) \
				lvl++; \
				dist[lvl] = 99999.f; \
				targ[lvl] = -1; \
				amt[lvl] = n;

	#define disttarg(q,r) \
				if (q && q->state == CS_ALIVE && ((physent *)d) != ((physent *)q) && !botteam(d->team, q->team) && insight(d, q->o, target, BOTLOSDIST(d->botrate)) && d->o.dist(q->o) < dist[lvl] && d->o.dist(q->o) > d->radius*2) \
				{ \
					dist[lvl] = d->o.dist(q->o); \
					targ[lvl] = r; \
				}

	inittarg(1); // 0 - Player
	disttarg(cl.player1,0);

	inittarg(cl.players.length()); // 1 - Other Players
	loopv(cl.players)
	{
		disttarg(cl.players[i],i);
	}

	inittarg(cl.ms.monsters.length()); // 2 - Monsters (for SP and DMSP)
	loopv(cl.ms.monsters)
	{
		disttarg(cl.ms.monsters[i],i);
	}
	
	for (lvl = 0, c = 99999.f; lvl <= 2; lvl++)
	{
		if ((targ[lvl] >= 0) && (targ[lvl] < amt[lvl]) && (dist[lvl] > d->radius*2) && (dist[lvl] < c))
		{
			a = lvl;
			c = dist[lvl];
		}
	}

	if ((a >= 0) && (a <= 2))
	{
		b = targ[a];
		
		conoutf("# %s target %d (%d/%d) selected [%f].", d->name, a, b, amt[a], dist[a]);
		
		switch (a)
		{
			case 0:
				{
					return botenemy(d, cl.player1, 100);
					break;
				}
			case 1:
				{
					return botenemy(d, cl.players[b], 100);
					break;
				}
			case 2:
				{
					return botenemy(d, cl.ms.monsters[b], 100);
					break;
				}
			default:
				break;
		}
	}
	else
	{
		conoutf("# %s got no target", d->name);
	}
	return false;
}

void botaim(fpsent *d)
{
	if (d->yaw == d->botrot.y)
	{
		conoutf("# %s aimed at %f,%f,%f", d->name, d->botvec.x, d->botvec.y, d->botvec.z);
    	bottrans(d, M_ATTACKING, (d->o.dist(d->botvec) > BOTBACKDIST ? 1 : -1), BOTRNDMOVE(d->botrate), true, 25); // that's it, we're committed
	}
}

void botattack(fpsent *d)
{
	vec target;
	conoutf("# %s is attacking %f,%f,%f", d->name, d->botvec.x, d->botvec.y, d->botvec.z);
	hitvec(d->o, d->botvec, target);
    botshoot(d, target);
	botenemy(d, d->botenemy, d->gunwait);
}

int botnode(fpsent *d, bool any)
{
	int w = -1;
	vec target;
	
	loopv(waypoints)
	{
		if ((any || (waypoints[i]->pos.dist(d->o) < BOTWPDIST && inlos (d->o, waypoints[i]->pos, target))) && (!waypoints.inrange(w) || waypoints[i]->pos.dist(d->o) < waypoints[w]->pos.dist(d->o)))
		{
			w = i;
		}
	}
	return w;
}

void botcoord(fpsent *d, int retry)
{
	int c = (retry == 0 && waypoints.inrange(d->botcurnode) ? d->botcurnode : botnode(d, retry > 1)), r = -1;
	
	conoutf("# %s looking for waypoint (retries: %d)", d->name, retry);
	
	if (waypoints.inrange(c))
	{
		int q = waypoints[c]->nodes.length();

		conoutf("# %s is in node %d", d->name, c);

		if (q > 1)
		{
			int n = rnd(q);
			
			conoutf("# %s is trying a random node", d->name);

			// try a random node
			if (waypoints[c]->nodes.inrange(n) && waypoints[c]->nodes[n] != d->botcurnode && waypoints[c]->nodes[n] != d->botlastnode)
			{
				r = waypoints[c]->nodes[n];
			}
			else
			{
				// resort to a loop and find one
				for (n = 0; n < q; n++)
				{
					if (waypoints[c]->nodes.inrange(n) && waypoints[c]->nodes[n] != d->botcurnode && waypoints[c]->nodes[n] != d->botlastnode)
					{
						r = waypoints[c]->nodes[n];
						break;
					}
				}
			}
		}
		else if (q > 0)
		{
			r = waypoints[c]->nodes[0]; // looks like there's only one choice
		}
	}

	if (waypoints.inrange(r))
	{
		conoutf("# %s attempting home on %d", d->name, r);
		bothome(d, waypoints[r]->pos, 100*d->botrate, r);
	}
	else if (retry > 2)
	{
		conoutf("# %s attempting to backtrack to %d", d->name, d->botlastnode);
		if (waypoints.inrange(d->botlastnode))
			bothome(d, waypoints[d->botlastnode]->pos, 100*d->botrate, d->botlastnode); // backtrack
		else
		    bottrans(d, M_SEARCH, BOTRNDMOVE(d->botrate), BOTRNDMOVE(d->botrate), true, 100);
	}
	else
	{
		conoutf("# %s attempting to get coordinates another way", d->name);
		botcoord(d, retry+1);
	}
}

void botaction(fpsent *d)
{
	if(d->botms<cl.lastmillis)
    {
		conoutf("# %s doing action %d", d->name, d->botstate);

		switch(d->botstate)
		{
			case M_PAIN:
        		{
					botspawn(d);
				}
				break;

    		case M_SLEEP:
				{
					if (!bottarget(d))
					    bottrans(d, M_SEARCH, 1, 0, true, 100);
				}

    		case M_SEARCH:
				{
					if (!bottarget(d))
						botcoord(d, 0);
				}
				break;

			case M_HOME:
				{
					d->botcurnode = d->botlastnode = -1;
					if (!bottarget(d))
					    bottrans(d, M_SEARCH, 1, 0, true, 10);
				}
				break;

    		case M_AIMING:
				{
					botaim(d);
				}
				break;
    
            case M_ATTACKING:
				{
					botattack(d);
				}
				break;

			default:
				break;
        }
	}
}
