// SauerBot - Offline test and practice AI by Quinton Reeves

void botwayclear()
{
	loopv(waypoints)
	{
		loopvj(waypoints[i]->nodes)
		{
			waypoints[i]->nodes.remove(j);
		}
		waypoints[i]->nodes.setsize(0);
		DELETEP(waypoints[i]);
	}
	waypoints.setsize(0);
	waylast = -1;
	wayname[0] = 0;
}

int botwaypoint(int x, int y, int z, bool force)
{
	int n = waypoints.length();
	botway *e = new botway;
	vec p(x, y, z);

	e->pos.sub(e->pos);
	e->pos.add(p);
	e->nodes.setsize(0);
	
	waypoints.add(e);

	if (!force)
	{
		if (waypoints.inrange(n))
		{
			if (waypoints.inrange(waylast))
				botwaynodeadd(waylast, n, force);
			waylast = n;
		}
	}

	conoutf("# waypoint placed at %f,%f,%f", e->pos.x, e->pos.y, e->pos.z);
					
	return n;
}

bool botwayjoined (int a, int b)
{
	if (a != b && waypoints.inrange(a) && waypoints.inrange(b))
	{
		loopv(waypoints[a]->nodes)
		{
			if (waypoints[a]->nodes[i] == b)
				return true;
		}
	}
	return false;
}

void botwaypos(bool force)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		if (force || (cl.player1->state == CS_ALIVE && botdrop()))
		{
			bool inode = false;
			
			conoutf("# checking to generate waypoint.");

			loopv(waypoints)
			{
				if (waypoints[i]->pos.dist(cl.player1->o) < BOTWPDIST/3*2)
				{
					if (i != waylast)
					{
						if (waypoints.inrange(waylast))
							botwaynodeadd(waylast, i, force);
							
						waylast = i;
					}
					inode = true;
				}
			}
			if (!inode)
			{
				conoutf("# dropping waypoint..");
				botwaypoint((int)cl.player1->o.x, (int)cl.player1->o.y, (int)cl.player1->o.z, false);
			}
				
			return;
		}
	}
	waylast = -1;
}

void botwaynodes()
{
	conoutf("# auto generating nodes");

	execute("botdrop 1");
	
	loopv(cl.et.ents)
	{
		int t = cl.et.ents[i]->type;
		
		if ((t >= I_SHELLS && t <= TELEPORT) || t == JUMPPAD || t == BASE)
			botwaypoint((int)cl.et.ents[i]->o.x, (int)cl.et.ents[i]->o.y, (int)cl.et.ents[i]->o.z, true);
	}
	conoutf("# generated %d waypoint(s) without nodes from %d ent(s)", waypoints.length(), cl.et.ents.length());

	conoutf("# WARNING: You are in waypoint dropping mode, to exit, you will need to type: /botdrop 0");
	//conoutf("# To hide the waypoints: /botshow 0");
	//conoutf("# To populate map default bot numbers, use: /botadd");
}

int botwaynodeadd(int n, int m, bool force)
{
	conoutf("# attempting to connect node %d with %d", n, m);

	if (waypoints.inrange(n) && waypoints.inrange(m))
	{
		vec target;

		if (n != m && !botwayjoined(n, m))
		{
			if (inlos (waypoints[n]->pos, waypoints[m]->pos, target))
			{
				waypoints[n]->nodes.add(m);
				//waypoints[m]->nodes.add(n);
				conoutf("# waypoint node %d connected with %d", n, m);
			}
			else if (!force)
			{
				// no line of sight, try connecting with different nodes
				int w = -1;
				
				vec t(0, 0, 0), v(0, 0, 0), r(0, 0, 0);

				conoutf("# unable to find a line of sight node, trying to find a close node");
					
				t.add(waypoints[m]->pos);
				t.sub(waypoints[n]->pos);

				v.add(t);
				v.mul(0.5);

				r.add(waypoints[n]->pos);
				r.add(v);
				
				loopv(waypoints)
				{
					if (i != n && i != m && !botwayjoined(n, m) && waypoints[i]->pos.dist(r) < BOTWPDIST && (!waypoints.inrange(w) || waypoints[i]->pos.dist(r) < waypoints[w]->pos.dist(r)))
					{
						if (inlos (waypoints[n]->pos, waypoints[i]->pos, target) && inlos (waypoints[m]->pos, waypoints[i]->pos, target))
						{
							w = i;
						}
					}
				}
				if (waypoints.inrange(w))
				{
					botwaynodeadd(n, w, false);
					botwaynodeadd(w, m, false);
				}
				else
				{
					// gee, that sucks, can we make a node to connect them both?
					conoutf("# can't even get a node, making one then.");

					loopi(6)
					{
						v.sub(v);
						v.add(t);
						
						if (i == 1 || i == 2 || i == 5)
							v.x = 0.0;
						if (i == 0 || i == 2 || i == 4)
							v.y = 0.0;
						if (i == 0 || i == 1 || i == 3)
							v.x = 0.0;
						
						r.sub(r);
						r.add(waypoints[n]->pos);
						r.add(v);

						if (inlos (waypoints[n]->pos, r, target) && inlos (waypoints[m]->pos, r, target))
						{
							w = botwaypoint((int)r.x, (int)r.y, (int)r.z, true);
							
							if (waypoints.inrange(w))
							{
								botwaynodeadd(n, w, false);
								botwaynodeadd(w, m, false);
							}
							break;
						}
					}
				}
			}
		}
	}
}

int botgetint(gzFile f)
{
	int t;
    gzread(f, &t, sizeof(int));
    endianswap(&t, sizeof(int), 1);
    return t;
}

void botputint(gzFile f, int x)
{
	int t = (int)x;
   	endianswap(&t, sizeof(int), 1);
   	gzwrite(f, &t, sizeof(int));
}

bool botwayload()
{
    gzFile f = gzopen(wayname, "rb9");
    if(f)
	{
		bool ans = false;

		char head[4];
		int version;

	    gzread(f, &head, 4);
	    version = botgetint(f);
	    			
		if (!strncmp(head, "WAYP", 4))
		{
			if (version == BOTWPVERSION)
			{
				int ways, x, y, z;
				
				ways = botgetint(f); // number of waypoints
				
				loopi(ways) // load waypoint positions
				{
					x = botgetint(f);
					y = botgetint(f);
					z = botgetint(f);
					botwaypoint(x, y, z, true);
				}					
				
				loopi(ways) // load waypoint node connections, this is done after because of validity checks
				{
					x = botgetint(f); // number of nodes
					
					loopj(x)
					{
						y = botgetint(f); // node waypoint number
	
						//waypoints[i]->nodes.add(y);
						botwaynodeadd(i, y, true);
					}
				}
				ans = true;
				conoutf("loaded %d waypoint(s) from %s", waypoints.length(), wayname);
			}
			else
				conoutf("waypoint file %s made with a %s version", wayname, (version > BOTWPVERSION ? "newer" : "older"));
		}
		else
			conoutf("waypoint file %s is corrupt", wayname);
		gzclose(f);
		return ans;
	}
	conoutf("could not load waypoint file %s", wayname);
	
	return false;
}

bool botwaysave()
{
    gzFile f = gzopen(wayname, "wb9");
    if(f)
	{
		char head[4];
		int version;

	    strncpy(head, "WAYP", 4);
		gzwrite(f, &head, 4);
		botputint(f, BOTWPVERSION);
					
		botputint(f, waypoints.length());

		loopv(waypoints)
		{
			botputint(f, waypoints[i]->pos.x);
			botputint(f, waypoints[i]->pos.y);
			botputint(f, waypoints[i]->pos.z);
		}
		loopv(waypoints)
		{
			botputint(f, waypoints[i]->nodes.length());
			
			loopvj(waypoints[i]->nodes)
			{
				botputint(f, waypoints[i]->nodes[j]);
			}
		}
		
		conoutf("saved %d waypoint(s) to %s", waypoints.length(), wayname);

		gzclose(f);
		return true;
	}
	conoutf("could not save waypoint file %s", wayname);
	return false;
}
