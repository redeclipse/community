// SauerBot - Offline test and practice AI by Quinton Reeves

struct botset
{
    fpsclient &cl;
    vector<extentity *> &ents;

	#include "botdef.h"	// definitions
	#include "botutl.h"	// utilities
	#include "botemu.h"	// emulation layer
	#include "botmgr.h"	// management
	#include "botway.h"	// waypoints and nodes
	#include "botai.h"	// intelligence

    int bottotal, waylast, gamemode, curtime;
	vector<botway *> waypoints;
    string wayname;
	
    botset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents), bottotal(0), waylast(-1)
	{
        CCOMMAND(botset, botadd, "ii", { int num = (args[0][0] ? atoi(args[0]) : -1); int ar = (args[1][0] ? atoi(args[1]) : -1); self->botadd(num, ar); });
        CCOMMAND(botset, botdel, "i", { int num = (args[0][0] ? atoi(args[0]) : -1); self->botdel(num); });
        CCOMMAND(botset, botload, "", { self->botwayload(); });
        CCOMMAND(botset, botsave, "", { self->botwaysave(); });
	}
    
    IVAR(botrate, 1, 25, 100);	// rate of action updates and judgement errors
    IVAR(botauto, 0, 1, 1);		// autmically load bots on start of map
    IVAR(botnum, 0, 0, 15);		// set to force a number of bots when automatically loading
    IVAR(botdrop, 0, 0, 1);		// drop waypoints during play (auto-set but toggleable)
    IVAR(botshow, 0, 0, 1);		// show bot debugging like waypoints
};

