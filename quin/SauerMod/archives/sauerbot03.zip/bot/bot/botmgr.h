// SauerBot - Offline test and practice AI by Quinton Reeves

void botclear()
{
    if (!cl.cc.remote)
    {
		loopv(cl.players)
			if (cl.players[i])
      			DELETEP(cl.players[i]);

		cl.players.setsize(0);
		cleardynentcache();

        bottotal = 0;
        
		botwayclear();

		execute("botdrop 0");
	}
}

void botstart(const char *map, int gm)
{
	gamemode = gm; // so m_* macro's work.
	
    if (!cl.cc.remote)
    {
        if (*map) // otherwise we may be editing..
        {
			conoutf("# sauerbot loading...");

			cl.cc.currentmaster = cl.player1->clientnum;
	
			botnames(map);
			
			if (!botwayload())
				botwaynodes();
			if (botauto())
	    		botadd(-1, -1);

			conoutf("# sauerbot loaded.");
		}
	}
}

bool botplayers(int ct)
{
	curtime = ct;
	
	if (!cl.cc.remote && !cl.intermission)
	{
		botwaypos(false); // player1 waypoint dropping

		conoutf("# ai update (%d player(s))", cl.players.length());

		loopv(cl.players) // state of other 'clients'
		{
	       	if (cl.players[i] && bot(cl.players[i]))
	       	{
				botthink(cl.players[i]);
			}
		}

		return true;
	}
	return false;
}

void botrender()
{
	conoutf("# bot render pass..");

	if (botshow() == 1)
	{
		conoutf("# displaying waypoints...");

		loopv(waypoints) // purrty waypoints
		{
			vec target;
	
			if (inlos (cl.player1->o, waypoints[i]->pos, target))
			{
				int red = 0, blue = 0; // shows bot targets
				string wp;
	
				loopvj(cl.players)
				{
					if (cl.players[j] && bot(cl.players[j]) && cl.players[j]->state == CS_ALIVE)
					{
						if (i == cl.players[j]->botcurnode)
						{
							blue++;
						}
						else if (i == cl.players[j]->botlastnode)
						{
							red++;
						}
					}
				}

				s_sprintf(wp)("@waypoint (%d)", i);
    	        particle_text(waypoints[i]->pos, wp, (red || blue ? (red > blue ? 13 : 16) : 14), 1);
	    	    particle_splash((red || blue ? (red > blue ? 3 : 2) : 0), 2, 50, waypoints[i]->pos);

				loopvj(waypoints[i]->nodes)
				{
					int y = waypoints[i]->nodes[j];
					
					if (waypoints.inrange(y))
					{
						particle_flare(waypoints[i]->pos, waypoints[y]->pos, 1);
					}
				}
			}
		}
	}
}

void botadd(int num, int ar)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		int n = (num >= 0 ? num : botnum()), s = (ar >= 0 ? ar : botrate());
		
		if (n == 0)
		{
			int r = 0;
			loopv(ents) if (ents[i]->type == PLAYERSTART)
			{
				r++;
			}
			n = max(r >= 8 ? r - (r / 3) : r - 2, 2);
			
		}
		
		if (n <= 0)
			return;

        while (n > 0 && bottotal < 15)
        {
       		bottotal++; // doubles as clientnum, just treat bots as a stack.

           	fpsent *d = cl.newclient(bottotal);

			if (d)
			{
		        char bottxt[MAXTRANS];

		        d->move = d->strafe = 0;
	          	cl.spawnstate(d);
				
		        conoutf("# bot %s starting.", d->name);
				d->state = CS_DEAD;
				d->botrate = (s < 1 ? 1 : (s > 100 ? 100 : s));
	
		        s_sprintf(bottxt)("bot_%02d", bottotal);
		        s_strcpy(d->name, bottxt);
		        s_sprintf(bottxt)("%s", (d->clientnum % 2 ? "good" : "evil"));
		        s_strcpy(d->team, bottxt);

				conoutf("connected: %s", &d->name);
	            
				bottrans(d, M_PAIN, 0, 0, true, bottotal*10);
	           	n--;
			}
			else
				fatal("cannot get bot entity");
		}
	}
	else
		conoutf("addbot is only available in active offline games");
}

void botdel(int num)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		if (cl.players.length() <= 1) return;

		int n = (num >= 0 ? num : 1);
		
		if (n == 0 || !cl.players.inrange(n))
		{
			n = cl.players.length()-1;
		}	
		
		int x = cl.players.length()-1;
		
        while (x >= 0 && n > 0 && cl.players.length() > 1) 
		{
			if (cl.players.inrange(x) && bot(cl.players[x]))
        	{
                conoutf("player %s disconnected", &cl.players[x]->name);
                DELETEP(cl.players[x]);
                cleardynentcache();
				n--;
        		bottotal--;
			}
			x--;
		}
	}
	else
		conoutf("delbot is only available in active offline games");
}
