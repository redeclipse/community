// SauerBot - Offline test and practice AI by Quinton Reeves

bool bot(fpsent *d)
{
	return !cl.cc.remote && d != NULL && d->botstate != M_NONE;
}

bool botteam(char *a, char *b)
{
	return (m_teammode ? isteam(a, b) : false);
}

void botnames(const char *fname)
{
    string mapname;
    if(strpbrk(fname, "/\\")) s_strcpy(mapname, fname);
    else s_sprintf(mapname)("base/%s", fname);

    s_sprintf(wayname)("packages/%s.wpz", mapname);
    path(wayname);
}

bool inlos(vec &o, vec &q, vec &v)
{
    vec ray(q.x, q.y, q.z);
    ray.sub(o);
    v.sub(v);
    float mag = ray.magnitude();
    float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
    return distance >= mag; 
}

bool insight(fpsent *d, vec &q, vec &v, float mdist)
{
	vec see(d->o.x, d->o.y, d->o.z);
	float dist = see.dist(q);
	
	if (dist <= mdist)
	{
		float x = fabs((asin((q.z - d->o.z) / dist) / RAD) - d->botrot.x);
		float y = fabs((-(float)atan2(q.x - d->o.x, q.y - d->o.y)/PI*180+180) - d->botrot.y);

		if (x <= BOTFOVX(d->botrate) && y <= BOTFOVY(d->botrate))
			return inlos(d->o, q, v);
	}
	
	return false;
}

void hitvec(vec &o, vec &q, vec &v)
{
    vec ray(q.x, q.y, q.z);
    ray.sub(o);
    v.sub(v);
    float mag = ray.magnitude();
    raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
}

void botvector(fpsent *d)
{
	d->botrot.y = -(float)atan2(d->botvec.x - d->o.x, d->botvec.y - d->o.y)/PI*180+180;
    if(d->yaw<d->botrot.y-180.0f) d->yaw += 360.0f;
    if(d->yaw>d->botrot.y+180.0f) d->yaw -= 360.0f;
    float dist = d->o.dist(d->botvec);
	d->botrot.x = d->pitch = asin((d->botvec.z - d->o.z) / dist) / RAD; 
}
