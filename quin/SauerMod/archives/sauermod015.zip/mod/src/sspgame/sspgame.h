// SauerMod - SSPGAME - Side Scrolling Platformer by Quinton Reeves
// This is the primary SSP definitions.

#define SSPDEBUG		1
#define SSPVERSION		1

#define PLAYEROFFSET	12.0f
#define WORLDOFFSET		64.0f

#define TIMELIMIT		300

extern int thirdperson;
extern physent *camera1;
extern bool menuactive();

enum { COIN = ET_GAMESPECIFIC, POWERUP, INVINCIBLE, LIFE, ENEMY, GOAL, JUMPPAD, TELEPORT, TELEDEST, MAXITEMS };
enum { PWR_HIT = 0, PWR_GRENADE, PWR_ROCKET };

struct sspent : dynent
{
    int lastaction, lastpain;
    bool attacking;

	int lives, coins, power, weapon, timeinwater;
    float offset;
    
    sspent() : lastaction(0), lastpain(0), attacking(false)
	{
		setup();
	}
	
	void spawn()
	{
		dynent::reset();
		state = CS_ALIVE;
	}

	void respawn()
	{
		spawn();
		power = 1;
		weapon = 0;
	}

	void setup()
	{
		respawn();
		lives = 5;
		coins = 0;
	}
};

struct sspentity : extentity
{
    sspentity() {}
};

struct sspdummycom : iclientcom
{
    ~sspdummycom() {}

    void gamedisconnect() {}
    void parsepacketclient(int chan, ucharbuf &p) {}
    int sendpacketclient(ucharbuf &p, bool &reliable, dynent *d) { return -1; }
    void gameconnect(bool _remote) {}
    bool allowedittoggle() { return true; }
    void writeclientinfo(FILE *f) {}
    void toserver(char *text) {}
    void changemap(const char *name) { load_world(name); }
};

struct sspdummyserver : igameserver
{
    ~sspdummyserver() {}

    void *newinfo() { return NULL; }
    void resetinfo(void *ci) {}
    void serverinit(char *sdesc, char *adminpass) {}
    void clientdisconnect(int n) {}
    int clientconnect(int n, uint ip) { return DISC_NONE; }
    void localdisconnect(int n) {}
    void localconnect(int n) {}
    char *servername() { return "none"; }
    void parsepacket(int sender, int chan, bool reliable, ucharbuf &p) {}
    bool sendpackets() { return false; }
    int welcomepacket(ucharbuf &p, int n) { return -1; }
    void serverinforeply(ucharbuf &p) {}
    void serverupdate(int seconds) {}
    bool servercompatible(char *name, char *sdec, char *map, int ping, const vector<int> &attr, int np) { return false; }
    void serverinfostr(char *buf, const char *name, const char *desc, const char *map, int ping, const vector<int> &attr, int np) {}
    int serverinfoport() { return 0; }
    int serverport() { return 0; }
    char *getdefaultmaster() { return "none"; }
    void sendservmsg(const char *s) {}
};
