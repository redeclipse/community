// SauerMod - SSPGAME - Side Scrolling Platformer by Quinton Reeves
// This is the SSP entities.

struct sspentities : icliententities
{
    sspclient &cl;
    vector<sspentity *> ents;

	struct sspitem
	{
		char *name;				// item name
		bool touch, pickup;		// item is touchable / collectable
		int dist, yaw, zoff;	// item pickup distance / yaw, z offset (-1 for bobbing)
	} *sspitems;
    
    sspentities(sspclient &_cl) : cl(_cl)
    {
		static sspitem _sspitems[] = {
			{ "none?",			false,	false,		0,		0,		0 },
			{ "light",			false,	false,		0,		0,		0 },
			{ "mapmodel",		false,	false,		0,		0,		0 },
			{ "playerstart",	false,	false,		0,		0,		0 },
			{ "envmap",			false,	false,		0,		0,		0 }, 
			{ "particles",		false,	false,		0,		0,		0 },
			{ "sound",			false,	false,		0,		0,		0 },
			{ "coin",			true,	true,		12,		-1,		-1 },
			{ "powerup",		true,	true,		12,		-1,		-1 },
			{ "invincible",		true,	true,		12,		-1,		-1 },
			{ "life",			true,	true,		12,		-1,		-1 },
			{ "enemy",			true,	false,		0,		0,		0 },
			{ "goal",			true,	false,		6,		270,	0 },
			{ "jumppad",		true,	false,		12,		0,		0 },
			{ "teleport",		true,	false,		12,		-1,		-1 },
			{ "teledest",		false,	false,		0,		0,		0 }
		};
		sspitems = _sspitems;
    }
	~sspentities() {}

    vector<extentity *> &getents() { return (vector<extentity *> &)ents; }

    void renderent(sspentity &e, const char *mdlname, float z, float yaw, int frame = 0, int anim = ANIM_MAPMODEL|ANIM_LOOP, int basetime = 0, float speed = 10.0f)
    {
        rendermodel(e.color, e.dir, mdlname, anim, 0, 0, e.o.x, e.o.y, z+e.o.z, yaw, 0, speed, basetime);
    }

	char *renderentmdl(sspentity &e)
	{
		char *imdl = NULL;
		
		switch (e.type)
		{
			case COIN:
				//if (e.attr1 > 1)
				imdl = "tentus/moneybag";
				//else imdl = "tentus/key";
				break;
			case POWERUP:
				{
					switch (e.attr1)
					{
						case PWR_HIT:
							imdl = "tentus/magic";
							break;
						case PWR_GRENADE:
							imdl = "grenades";
							break;
						case PWR_ROCKET:
							imdl = "rockets";
							break;
						default:
							break;
					}
					break;
				}
			case INVINCIBLE:
				imdl = "quad";
				break;
			case LIFE:
				imdl = "boost";
				break;
			case ENEMY:
				break;
			case GOAL:
				if (cl.levelend) imdl = "flags/red";
				else imdl = "flags/neutral";
				break;
			case JUMPPAD:
				imdl = "dcp/jumppad2";
				break;
			case TELEPORT:
				imdl = "teleporter";
				break;
			default:
				break;
		}
		return imdl;
	}

    void renderentities()
    {
        loopv(ents)
        {
            sspentity &e = *ents[i];
            
			if(!e.spawned) continue;

            sspitem &i = sspitems[e.type];
			float z = (i.zoff == -1 ? (float)(1+sin(cl.lastmillis/100.0+e.o.x+e.o.y)/20) : i.zoff);
			float yaw = (i.yaw == -1 ? cl.lastmillis/10.0f : i.yaw);
			char *imdl = renderentmdl(e);

			if (imdl) renderent(e, imdl, z, yaw);
        }
    }

    void editent(int i)
	{
        /*sspentity &e = *ents[i];
        switch(e.type)
        {
            default:
				break;
        }*/
	}

    const char *entnameinfo(entity &e) { return ""; }
    const char *entname(int i) { return i>=0 && i<MAXITEMS ? sspitems[i].name : ""; }

    int extraentinfosize() { return 0; }
    void writeent(entity &e, char *buf) { }
    void readent (entity &e, char *buf) { }

    float dropheight(entity &e) { return e.type==ET_MAPMODEL ? 0.f : 4.f; }

    void rumble(const extentity &e) { playsoundname("free/rumble", &e.o); }
    void trigger(extentity &e) {}

    extentity *newentity() { return new sspentity; }

    void fixentity(extentity &e)
    {
        /*switch(e.type)
        {
            default:
				break;
        }*/
    }

    void teleport(sspent *d, sspentity &e)
    {
        loopv(ents)
		{
			if (ents[i]->type == TELEDEST && ents[i]->attr1 == e.attr1)
			{
                d->vel = vec(0, 0, 0);
                d->move = d->strafe = 0;
                setposition(d, ents[i]->o.x, ents[i]->o.y, ents[i]->o.z);
				return;
			}
		}
		conoutf("no teleport destination for tag %d", e.attr1);
    }

	void pickup(sspentity &e)
	{
        sspitem &i = sspitems[e.type];

		switch(e.type)
		{
			case COIN:
				cl.player1->coins += e.attr1 ? e.attr1 : 1;
				if (cl.player1->coins >= 100)
				{
					cl.player1->lives++;
					cl.player1->coins -= 100;
				}
				playsoundname("free/tick", &e.o);
				break;
			case POWERUP:
				{
					switch (e.attr1)
					{
						case PWR_HIT:
							if (cl.player1->power == 1) cl.player1->power = 2;
							playsoundname("aard/tak", &e.o);
							break;
						case PWR_GRENADE:
						case PWR_ROCKET:
							cl.player1->power = 3;
							cl.player1->weapon = e.attr1;
							playsoundname("aard/weapload", &e.o);
							break;
						default:
							break;
					}
					break;
				}
			case INVINCIBLE:
				// TODO
				playsoundname("aard/acid5", &e.o);
				break;
			case LIFE:
				cl.player1->lives += e.attr1 ? e.attr1 : 1;
				playsoundname("aard/bang", &e.o);
				break;
			case GOAL:
                cl.player1->vel = vec(0, 0, 0);
                cl.player1->move = cl.player1->strafe = 0;
				cl.levelend = 1;
				break;
			case JUMPPAD:
                cl.player1->timeinair = 0;
                cl.player1->gravity = vec(0, 0, 0);
				cl.player1->vel.z = e.attr1;
				cl.player1->vel.y += e.attr2;
				playsoundname("free/boing_x", &e.o);
				break;
			case TELEPORT:
				teleport(cl.player1, e);
				playsoundname("free/teleport", &e.o);
				break;
			default:
				break;
		}
		if (i.pickup) e.spawned = false;
	}

    void checkitems() // semi-borrowed from fpsgame
    {
        vec o = cl.player1->o;
        o.z -= cl.player1->eyeheight;
        loopv(ents)
        {
            sspentity &e = *ents[i];
            sspitem &i = sspitems[e.type];
            if(!e.spawned || !i.touch) continue;
            float dist = e.o.dist(o);
            if(dist<i.dist) pickup(e);
        }
    }

	void setposition(sspent *d, float x, float y, float z)
	{
        d->o.x = d->offset = x;
		d->o.y = y;
		d->o.z = z;
       	d->pitch = 0.f;
       	d->yaw = 180.f;
        entinmap(d);
	}
    
    void spawnents(bool restart)
    {
        loopv(ents)
        {
            ents[i]->spawned = true; 
        }
    }
    
    void spawnplayer(bool respawn)
    {
		if (cl.player1->lives > 0)
		{
			cl.leveltime = 0;
			
			spawnents(true);
			if (respawn) { cl.player1->respawn(); }
			else { cl.player1->spawn(); }
			
			loopv(ents)
			{
				if (ents[i]->type == ET_PLAYERSTART)
				{
					setposition(cl.player1, ents[i]->o.x, ents[i]->o.y, ents[i]->o.z);
					return;
				}
			}
			setposition(cl.player1, WORLDOFFSET+PLAYEROFFSET, WORLDOFFSET+PLAYEROFFSET, 0.5f*getworldsize());
		}
		else
		{ // outta lives, go back to the start
			cl.player1->setup();
			cl.cc.changemap(cl.gamestartmap());
		}
	}

	void entprerender() // pre-render entities to avoid stutter
	{
		bool rendered[MAXITEMS];
		loopv(ents)
		{
			sspentity &e = *ents[i];
			if (e.type >= ET_GAMESPECIFIC && !rendered[e.type])
			{
				vec v(0, 0, 0);
				char *mdlname = renderentmdl(e);
		        rendermodel(v, v, mdlname, ANIM_MAPMODEL|ANIM_LOOP, 0, 0, cl.player1->o.x, cl.player1->o.y, cl.player1->o.z+8.f, 0.f, 0, 0, 10.f);
			}
		}

		char *powers[] = { "monster/ogro", "monster/ogro", "monster/ogro/blue", "monster/ogro/red" };

		loopi(4)
		{
			renderclient(cl.player1, powers[i], "monster/ogro/vwep", false, 0, 0);
		}
	}
};
