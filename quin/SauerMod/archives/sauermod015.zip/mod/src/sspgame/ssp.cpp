// SauerMod - SSPGAME - Side Scrolling Platformer by Quinton Reeves
// This is the primary SSP game module.

#include "pch.h"
#include "cube.h"
#include "iengine.h"
#include "igame.h"
#include "sspgame.h"

struct sspclient : igameclient, g3d_callback
{
	#include "ssprender.h"
    #include "sspents.h"

    sspentities		et;
    sspdummycom		cc;
    
    sspent *player1;

    int curtime, lastmillis, leveltime, levelend;
    string mapname;
    
    sspclient() : et(*this), player1(new sspent()), lastmillis(0)
    {
        CCOMMAND(sspclient, map, "s", load_world(args[0]));
        
        // Kludges to remove warning messages in config from fpsgame.
        CCOMMAND(sspclient, name, "", self->ignore());
        CCOMMAND(sspclient, team, "", self->ignore());

        #ifdef SSPDEBUG
		CCOMMAND(sspclient, cheat, "ss", self->cheat(atoi(args[0]), atoi(args[1])));
		#endif
    }
    ~sspclient() {}

    icliententities *getents() { return &et; }
    iclientcom *getcom() { return &cc; }

	void ignore() { return; }

	#ifdef SSPDEBUG
	void cheat(int a, int b)
	{
		switch (a)
		{
			case 0:
				player1->power += b;
				if (player1->power < 1) player1->power = 1;
				else if (player1->power > 3) player1->power = 3;
				break;
			default:
				break;
		}
	}
	#endif
	
    void updateworld(vec &pos, int ct, int lm)
    {
        lastmillis = lm;
		curtime = ct;
		
		if(!curtime) return;
		
		physicsframe();
        
		if(player1->state == CS_DEAD)
        {
            if(lastmillis - player1->lastaction < 2000)
            {
                player1->move = player1->strafe = 0;
                moveplayer(player1, 10, false);
            }
        }
        else if (levelend)
        {
			levelend += curtime;
			if (levelend > 5000)
			{
                s_sprintfd(nextmapalias)("nextmap_%s", mapname);
                const char *map = getalias(nextmapalias); // look up map in the cycle
                if (*map) cc.changemap(map);
				else cc.changemap(gamestartmap());
			}
			else
			{
				int strafe = player1->strafe, move = player1->move;

                player1->move = player1->strafe = 0;
				moveplayer(player1, 10, false);

				if (!editmode)
				{
					player1->move = move;
					player1->strafe = strafe;
					player1->o.x = player1->offset; // stop X direction movement
				}
			}
		}
		else
        {
			int strafe = player1->strafe, move = player1->move;
			bool jump = player1->jumpnext && !player1->timeinair, water = player1->inwater;

			// Wooo, hacky
			if (!editmode)
			{
				leveltime += curtime;
				if (leveltime/1000 >= TIMELIMIT) selfdamage(player1->power);

				if (water) { player1->timeinwater += curtime; }
				else { player1->timeinwater = 0; }

				if (!thirdperson)
				{
					player1->move = (strafe ? 1 : 0);
					player1->strafe = 0;
					
					if (strafe) player1->yaw = (strafe > 0 ? 0.0f : 180.0f);
				}
				else
				{
					player1->move = (move ? 1 : 0);
					player1->strafe = 0;
					
					if (move) player1->yaw = (move > 0 ? 180.0f : 0.0f);
				}
			}
            
			moveplayer(player1, 20, true);
			
			if (!editmode)
			{
				player1->move = move;
				player1->strafe = strafe;
				player1->o.x = player1->offset; // stop X direction movement
				
				// hacks for Z velocity
				if (jump) { player1->vel.z *= 1.5f; }
				else if (water) { player1->vel.z -= (curtime*0.05f); }

	            checktriggers();
	            et.checkitems();
			}
			
			if(player1->attacking && lastmillis-player1->lastaction>250)
            {
                player1->lastaction = lastmillis;
            }
        }
    }
    
    void initclient() {}
        
    void physicstrigger(physent *d, bool local, int floorlevel, int waterlevel)
    {
        if     (waterlevel>0) playsoundname("free/splash1", &d->o);
        else if(waterlevel<0) playsoundname("free/splash2", &d->o);
        if     (floorlevel>0) playsoundname("aard/jump", &d->o);
        else if(floorlevel<0) playsoundname("aard/land", &d->o);    
    }
    
    void edittrigger(const selinfo &sel, int op, int arg1 = 0, int arg2 = 0, int arg3 = 0) {}
    char *getclientmap() { return mapname; }

	void resetgame(bool restart)
	{
	    leveltime = levelend = 0;
		et.spawnents(restart);
	}

    void resetgamestate()
	{
		resetgame(true);
		et.setposition(player1, player1->offset, player1->o.y, player1->o.z);
	}
    
	void selfdamage(int damage)
	{
		if (player1->state == CS_ALIVE)
		{
	        int dam = (damage > 3 ? player1->power : damage);
	        
			player1->lastpain = lastmillis;
			
	        if((player1->power -= dam)<=0)
	        {
	            player1->attacking = false;
	            player1->state = CS_DEAD;
	            player1->lives--;
	            player1->pitch = player1->roll = 0;
	            
				playsoundname("aard/die1", &player1->o);
	            
				vec vel = player1->vel;
	            player1->reset();
	            player1->vel = vel;
	            player1->lastaction = lastmillis;
			}
	        else
	        {
	            playsoundname("aard/pain6", &player1->o);
	        }
		}
	}
	
	void worldhurts(physent *d, int damage)
	{
        if(d == player1) selfdamage(damage);
	}
    
	void newmap(int size) {}

	void startmap(const char *name)
    {
		s_strcpy(mapname, name);
	    resetgame(false);
		et.spawnplayer(false);
		et.entprerender();
    }
    
    bool canjump() { return true; }
    
    void doattack(bool on)
	{
        if(levelend) return;
		if (player1->attacking = on)
		{
			if (player1->state == CS_DEAD)
			{
				player1->attacking = false;
				et.spawnplayer(true);
			}
			else if (player1->power < 3) player1->attacking = false;
		}
	}
	
    dynent *iterdynents(int i) { return i ? NULL : player1; }
    int numdynents() { return 1; }

    void writegamedata(vector<char> &extras) {}
    void readgamedata(vector<char> &extras) {}

    char *gameident() { return "ssp"; }
	char *gamestartmap() { return "ssp/demo"; }

	void doquit() { }
};

REGISTERGAME(sspgame, "ssp", new sspclient(), new sspdummyserver());

