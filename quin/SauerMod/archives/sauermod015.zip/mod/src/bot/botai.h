// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// This is the main intelligence and logic for the bots.

void bottrans(fpsent *d, int stat, int mv, int st, bool dev, int n)
{
    d->move = mv;
    d->strafe = st;
	int q = (dev ? rnd(d->botrate) : 0), v = n + q;
	d->botstate = stat;
	d->botms = cl.lastmillis + v;
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# %s transition to %d (%d)", d->name, d->botstate, v);
	#endif
}

void botthink(fpsent *d)
{
	#ifdef BOTDEBUG
	if (botdebug() >= 2) conoutf("# %s is thinking.. (%d,%d,%d)", d->name, d->botcurnode, d->botlastnode, d->botprevnode);
	#endif
	if(d->state == CS_SPECTATOR || d->state == CS_EDITING)
	{
		d->state = CS_DEAD;
		bottrans(d, M_PAIN, 0, 0, false, 10);
	}

   	botaction(d);

    if(d->state==CS_ALIVE)
    {
		botaimat(d);
        botquad(d);
    	botitems(d);

		if (d->botstate == M_HOME)
		{
			int gamemode = cl.gamemode;
			bool chk = false;
			if (m_capture && d->botenemy == NULL)
			{
				#ifdef BOTDEBUG
				if (botdebug() >= 2) conoutf("# %s checking for bases", d->name);
				#endif
				loopv(cl.cpc.bases)
				{
					if (cl.cpc.insidebase(cl.cpc.bases[i], d->botvec))
					{
						if ((!botteam(d->team, cl.cpc.bases[i].owner) || cl.cpc.bases[i].enemy[0]) && cl.cpc.insidebase(cl.cpc.bases[i], d->botvec))
						{
							#ifdef BOTDEBUG
							if (botdebug() >= 2) conoutf("# %s gaurding base %d", d->name, i);
							#endif
						    bottrans(d, M_HOME, 0, 0, false, 10);
						}
						chk = true;
						break;
					}
				}
			} 
			
			if (!chk && d->o.dist(d->botvec) <= BOTISNEAR)
			{
			    bottrans(d, M_HOME, 0, 0, false, 10);
			    chk = true;
			}
			
			if (!chk && d->botvec.z-d->o.z >= BOTJUMPDIST)
			{
				#ifdef BOTDEBUG
				if (botdebug() >= 2) conoutf("# %s could probably jump (%4.2f-%4.2f:%4.2f > %4.2f:%4.2f)", d->name, d->botvec.z, d->o.z, d->botvec.z-d->o.z, BOTJUMPDIST, BOTJUMPMAX);
				#endif
				
				// TODO: check for jumppads
				if (d->botvec.z-d->o.z >= BOTJUMPMAX) { bottrans(d, M_SEARCH, 0, 0, false, 10); }
				else { d->jumpnext = true; }
				chk = true;
			}
		}

		botmove(d, 2); // main update
    }
    else
    {
        d->move = d->strafe = 0;

        if(cl.lastmillis-d->lastaction<2000)
        {
			botmove(d, 2);
        }
    }
	d->lastupdate = cl.lastmillis;
}

void bothome(fpsent *d, vec &v, int trans, int wp)
{
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# %s homing vector %f,%f,%f [%d,%d]", d->name, v.x, v.y, v.z, trans, wp);
	#endif

	d->botvec.sub(d->botvec);

	if (botwaypoints.inrange(wp))
	{
		d->botprevnode = d->botlastnode;
		d->botlastnode = d->botcurnode;
		d->botcurnode = wp;
		d->botvec.add(v);
	}
	else
	{
		if (wp == -2)
		{
			d->botvec.add(v);
		}
		else
		{
			while(1)
			{
				d->botcurnode = (botwaypoints.inrange(d->botcurnode) ? d->botcurnode : botnode(d, true));

				if (botwaypoints.inrange(d->botcurnode))
				{
					int bwp = -1;
					loopv(botwaypoints[d->botcurnode]->nodes)
					{
						int node = botwaypoints[d->botcurnode]->nodes[i];

						if (!botwaypoints.inrange(bwp) || (botwaypoints.inrange(node) && botwaypoints[node]->pos.dist(v) < botwaypoints[bwp]->pos.dist(v)))
						    bwp = node;
					}
					if (botwaypoints.inrange(bwp))
					{
						d->botprevnode = d->botlastnode;
						d->botlastnode = d->botcurnode;
						d->botcurnode = bwp;
						d->botvec.add(botwaypoints[bwp]->pos);
						break;
					}
				}
				botcoord(d, 0, trans);
				return;
			}
		}
	}

	if (trans)
	{
		d->botstart = cl.lastmillis;
		bottrans(d, M_HOME, 1, 0, true, trans);
	}
}

bool botenemy(fpsent *d, fpsent *p, int trans, bool hunt)
{
	if (d != NULL && d->state == CS_ALIVE && p != NULL && d != p && p->state == CS_ALIVE && !botteam(d->team, p->team))
	{
		vec target;
		vec po(p->o.x, p->o.y, p->o.z);
		
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s making enemy of %s", d->name, p->name);
		#endif

		d->botenemy = p;

		if (hunt)
		{
			bothome(d, po, 10*d->botrate, -1); // home in

			return true;
		}
		else if (insight(d, po, target, BOTLOSDIST(d->botrate)))
		{
			bool circle = (d->o.dist(p->o) <= BOTRADIALDIST);
			int *ammo = d->ammo, strafe = (circle ? rnd(3)-1 : 0);

			if (circle && strafe == 0 && d->botrate <= 50) strafe++;

			bothome(d, po, 0, -2);

			botweapon(d); // choose most appropriate weapon
			bottrans(d, M_AIMING, 0, strafe, true, trans);

			#ifdef BOTDEBUG
			if (botdebug() >= 1) conoutf("# %s aiming at %s (strafe: %d)", d->name, p->name, strafe);
			#endif
	
			return true;
		}
		else
			bothome(d, po, 100*d->botrate, -1); // quick search
	}
	else
	    bottrans(d, M_HOME, 0, 0, true, trans); // buh-bye

	d->botenemy = NULL;
	
	return false;
}

bool bottarget(fpsent *d)
{ // one does feel a bit convoluted at times, does one not?
	if (d->botenemy && botenemy(d, d->botenemy, 100, false)) return true;

	d->botenemy = NULL;

	int gamemode = cl.gamemode;
	vec target;
	float dist[5], c;
	int a = -1, b, lvl = 0, targ[5], amt[5], inbase = -1;
	bool targplayers = m_mp(gamemode) && !m_dmsp;
	
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# %s looking for target", d->name);
	#endif
	
	#define inittarg(n) \
				dist[lvl] = 99999.f; \
				targ[lvl] = -1; \
				amt[lvl] = n; \
				if (botdebug() >= 9) conoutf("# %s initialising argument %d (%d)", d->name, lvl, n); \
				lvl++;

	#define disttarg(q,r) \
				if (q && q->state == CS_ALIVE && ((physent *)d) != ((physent *)q) && !botteam(d->team, q->team) && insight(d, q->o, target, BOTLOSDIST(d->botrate))) \
				{ \
					float ds = (m_capture && cl.cpc.bases.inrange(inbase) && cl.cpc.insidebase(cl.cpc.bases[inbase], q->o)) ? 0.0f : d->o.dist(q->o); \
					if (botdebug() >= 9) conoutf("# %s parsing targetable entity %s (%d)", d->name, q->name, r); \
					if (ds <= dist[lvl] && ds >= BOTISNEAR) \
					{ \
						dist[lvl] = ds; \
						targ[lvl] = r; \
						if (botdebug() >= 9) conoutf("# %s new closest %s (%d)", d->name, q->name, r); \
					} \
				}

	if (m_capture)
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 3) conoutf("# %s scanning capture game bases", d->name);
		#endif

		inittarg(cl.cpc.bases.length()); // 0 - Bases (for CAPTURE)
		loopv(cl.cpc.bases)
		{
			if (cl.cpc.insidebase(cl.cpc.bases[i], d->o))
				inbase = i; // to fend off enemies
			
			float ds = inbase ? 0.0f : d->o.dist(cl.cpc.bases[i].o)/2;
			if (!botteam(d->team, cl.cpc.bases[i].owner) && insight(d, cl.cpc.bases[i].o, target, BOTLOSDIST(d->botrate)) && ds <= dist[lvl] && ds >= BOTISNEAR)
			{
				dist[lvl] = ds;
				targ[lvl] = i;
			}
		}
	}
	else { inittarg(0); }

	if (targplayers)
	{
		inittarg(1); // 1 - Player
		disttarg(cl.player1,0);
	}
	else { inittarg(0); }

	if (targplayers)
	{
		inittarg(cl.players.length()); // 2 - Other Players
		loopv(cl.players)
		{
			#ifdef BOTDEBUG
			if (cl.players[i] && botdebug() >= 3) conoutf("# %s scanning #%d (%s)", d->name, i, cl.players[i]->name);
			#endif
			disttarg(cl.players[i],i);
		}
	}
	else { inittarg(0); }

	if (m_sp || m_dmsp)
	{
		inittarg(cl.ms.monsters.length()); // 3 - Monsters (for SP and DMSP)
		loopv(cl.ms.monsters)
		{
			disttarg(cl.ms.monsters[i],i);
		}
	}
	else { inittarg(0); }
	
	#ifdef BOTDEBUG
	if (botdebug() >= 2) conoutf("# %s compiled list of targets", d->name);
	#endif

	for (lvl = 0, c = 99999.f; lvl <= 3; lvl++)
	{ // find the closest one in sight
		if ((targ[lvl] >= 0) && (targ[lvl] < amt[lvl]) && (dist[lvl] >= BOTISNEAR) && (dist[lvl] <= c))
		{
			a = lvl;
			c = dist[lvl];
		}
	}


	if ((a >= 0) && (a <= 3))
	{
		b = targ[a];
		
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s target %d (%d/%d) selected [%f].", d->name, a, b, amt[a], dist[a]);
		#endif
		
		switch (a)
		{
			case 0:
				{
					if (cl.cpc.insidebase(cl.cpc.bases[b], d->o))
					    bottrans(d, M_HOME, 0, 0, false, 10);
					else
						bothome(d, cl.cpc.bases[b].o, 10*d->botrate, -1);
					
					return true;
					break;
				}
			case 1:
				{
					return botenemy(d, cl.player1, 100, true);
					break;
				}
			case 2:
				{
					return botenemy(d, cl.players[b], 100, true);
					break;
				}
			case 3:
				{
					return botenemy(d, cl.ms.monsters[b], 100, true);
					break;
				}
			default:
				break;
		}
	}
	else
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s got no target", d->name);
		#endif
	}
	return false;
}

void botaim(fpsent *d)
{
	if (d->yaw == d->botrot.y)
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s aimed at %f,%f,%f", d->name, d->botvec.x, d->botvec.y, d->botvec.z);
		#endif
    	bottrans(d, M_ATTACKING, 0, 0, true, 25); // that's it, we're committed
	}
}

void botattack(fpsent *d)
{
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# %s is attacking %f,%f,%f", d->name, d->botvec.x, d->botvec.y, d->botvec.z);
	#endif
	botvec(d);
    botshoot(d);
	botenemy(d, d->botenemy, (int)(d->gunwait+(d->gunwait*0.1)), true);
}

int botnode(fpsent *d, bool any)
{
	int w = -1;
	vec target;
	
	loopv(botwaypoints)
	{
		if ((any || botwaypoints[i]->pos.dist(d->o) <= BOTISNEAR) && inlos (d->o, botwaypoints[i]->pos, target) && (!botwaypoints.inrange(w) || botwaypoints[i]->pos.dist(d->o) < botwaypoints[w]->pos.dist(d->o)))
		{
			w = i;
		}
	}
	return w;
}

void botcoord(fpsent *d, int retry, int trans)
{
	int c = (retry == 0 && botwaypoints.inrange(d->botcurnode) ? d->botcurnode : botnode(d, retry > 1)), r = -1;
	
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# %s looking for botwaypoint (retries: %d)", d->name, retry);
	#endif
	
	if (botwaypoints.inrange(c))
	{
		int q = botwaypoints[c]->nodes.length();
		vec target;

		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s is in node %d (%d, last: %d, prev: %d)", d->name, c, d->botcurnode, d->botlastnode, d->botprevnode);
		#endif

		if (q > 1)
		{
			int n = rnd(q);
			
			#ifdef BOTDEBUG
			if (botdebug() >= 1) conoutf("# %s is trying a node", d->name);
			#endif

			// try a random node
			if (botwaypoints[c]->nodes.inrange(n) && botwaypoints.inrange(botwaypoints[c]->nodes[n]) && botwaypoints[c]->nodes[n] != d->botcurnode && botwaypoints[c]->nodes[n] != d->botlastnode && (retry > 1 || (botwaypoints[c]->nodes[n] != d->botprevnode && inlos(d->o, botwaypoints[botwaypoints[c]->nodes[n]]->pos, target))))
			{
				r = botwaypoints[c]->nodes[n];
			}
			else
			{
				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# %s resorting to error loop", d->name);
				#endif

				// resort to a loop and find one
				for (n = 0; n < q; n++)
				{
					if (botwaypoints[c]->nodes.inrange(n) && botwaypoints.inrange(botwaypoints[c]->nodes[n]) && botwaypoints[c]->nodes[n] != d->botcurnode && botwaypoints[c]->nodes[n] != d->botlastnode && (retry > 1 || (botwaypoints[c]->nodes[n] != d->botprevnode && inlos(d->o, botwaypoints[botwaypoints[c]->nodes[n]]->pos, target))))
					{
						r = botwaypoints[c]->nodes[n];
						break;
					}
				}
			}
		}
		else if (q > 0)
		{
			r = botwaypoints[c]->nodes[0]; // looks like there's only one choice
		}
	}

	if (botwaypoints.inrange(r))
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s attempting home on %d", d->name, r);
		#endif
		bothome(d, botwaypoints[r]->pos, trans, r);
	}
	else if (retry > 2)
	{
		if (botwaypoints.inrange(d->botlastnode))
		{
			#ifdef BOTDEBUG
			if (botdebug() >= 1) conoutf("# %s attempting to backtrack to %d", d->name, d->botlastnode);
			#endif
			bothome(d, botwaypoints[d->botlastnode]->pos, 100*d->botrate, d->botlastnode); // backtrack
		}
		else
		{
			#ifdef BOTDEBUG
			if (botdebug() >= 1) conoutf("# %s is lost", d->name);
			#endif
		    bottrans(d, M_SEARCH, 1, 0, true, 100);
		}
	}
	else
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s attempting to get coordinates another way", d->name);
		#endif
		botcoord(d, retry+1, trans);
	}
}

void botaction(fpsent *d)
{
	if(d->botms<cl.lastmillis)
    {
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s doing action %d", d->name, d->botstate);
		#endif

		switch(d->botstate)
		{
			case M_PAIN:
        		{ // pain is used for unspawned or dead
					botspawn(d);
				}
				break;

    		case M_SLEEP:
    		case M_SEARCH:
				{ // take a look around
					d->botcurnode = d->botlastnode = d->botprevnode = -1;
					if (!bottarget(d))
						botcoord(d, 0, 100*d->botrate);
				}
				break;

			case M_HOME:
				{
					if (!bottarget(d))
						botcoord(d, 0, 100*d->botrate);
				}
				break;

    		case M_AIMING:
				{
					botaim(d);
				}
				break;
    
            case M_ATTACKING:
				{
					botattack(d);
				}
				break;

			default:
				break;
        }
	}
}
