// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// This is msotly parts of the engine that need emulating, hijacked from the engine.

void botmove(fpsent *d, int n)
{
	moveplayer(d, n, false); // using physics to move and detect
}

void botfrags(fpsent *d, int incr)
{
	s_sprintfd(ds)("@%d", d->frags += incr);
	particle_text(d->abovehead(), ds, 9);
}

void botdamage(fpsent *d, int damage, int actor, fpsent *act)
{
    if(d->state!=CS_ALIVE || cl.intermission) return;
    int ad = damage*(d->armourtype+1)*25/100;     // let armour absorb when possible
    if(ad>d->armour) ad = d->armour;
    d->armour -= ad;
    damage -= ad;
    float droll = damage/0.5f;
    d->roll += d->roll>0 ? droll : (d->roll<0 ? -droll : (rnd(2) ? droll : -droll));  // give player a kick depending on amount of damage
    if((d->health -= damage)<=0)
    {
		if(actor==-1)
        {
            actor = d->clientnum;
        }
        else if (actor == -2)
        {
            actor = act->clientnum;
		}			

		int gamemode = cl.gamemode;

        if(actor==d->clientnum)
        {
			botfrags(d, -1);
            conoutf("\f2%s suicided", d->name);
        }
        else if(actor==cl.player1->clientnum)
        {
            int frags;
            if(isteam(cl.player1->team, d->team))
            {
                frags = -1;
                conoutf("\f2you fragged a teammate (%s)", d->name);
            }
            else
            {
                frags = 1;
                conoutf("\f2you fragged %s", d->name);
            };
            cl.cc.addmsg(SV_FRAGS, "ri", cl.player1->frags += frags);
        }
        else
        {
            fpsent *a = cl.getclient(actor);
            if(a)
            {
                if(isteam(a->team, d->name))
                {
	       			botfrags(a, -1);
                    conoutf("\f2%s fragged his teammate (%s)", a->name, d->name);
                }
                else
                {
	       			botfrags(a, 1);
                    conoutf("\f2%s fragged %s", a->name, d->name);
                };
            };
        };
        d->superdamage = -d->health;

        d->lifesequence++;
        d->attacking = false;
        d->state = CS_DEAD;
        d->deaths++;
        d->pitch = 0;
        d->roll = 0;

        cl.ws.superdamageeffect(d->vel, d);

        playsound(S_DIE1+rnd(2), &d->o);

        vec vel = d->vel;

        cl.spawnstate(d);

        d->vel = vel;
        d->lastaction = cl.lastmillis;

		bottrans(d, M_PAIN, 0, 0, false, 250);
    }
    else
    {
		if (d != act) // other keep going about their business
            botenemy(d, act, 25, true);

        playsound(S_PAIN1+rnd(5), &d->o);
    };
};

void botspawn(fpsent *d)
{
	if (d->state!=CS_ALIVE)
	{
		int gamemode = cl.gamemode;
        d->botvec.sub(d->botvec);
        d->botcurnode = d->botlastnode = d->botprevnode = -1;
        d->botenemy = NULL;
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# %s is now spawning", d->name);
		#endif
        findplayerspawn(d, m_capture ? cl.cpc.pickspawn(d->team) : (cl.respawnent>=0 ? cl.respawnent : -1));
        cl.spawnstate(d);
        d->state = CS_ALIVE;
		entinmap(d);
	}
    bottrans(d, M_SLEEP, 0, 0, true, 50);
}

// weapons
void botweapon(fpsent *d)
{
    int *ammo = d->ammo;
    int s = d->gunselect;

    if(ammo[GUN_RL] && d->botvec.dist(d->o) >= BOTRADIALDIST) s = GUN_RL;
    else if(ammo[GUN_GL] && d->botvec.dist(d->o) >= BOTRADIALDIST)s = GUN_GL;
    else if(ammo[GUN_CG]) s = GUN_CG;
    else if(ammo[GUN_SG]) s = GUN_SG;
    else if(ammo[GUN_RIFLE]) s = GUN_RIFLE;
    else if(ammo[GUN_PISTOL]) s = GUN_PISTOL;
    else s = GUN_FIST;

	if (s != d->gunselect)
	{
    	playsound(S_WEAPLOAD, &d->o);
    	d->gunselect = s;
	}
}

void botshoot(fpsent *d)
{
    int attacktime = cl.lastmillis-d->lastaction;
    //if(attacktime<d->gunwait) return;
    d->gunwait = 0;
    if(!d->attacking) d->attacking = true;
    d->lastaction = cl.lastmillis;
    d->lastattackgun = d->gunselect;
    if(!d->ammo[d->gunselect]) { cl.playsoundc(S_NOAMMO); d->gunwait = 600; d->lastattackgun = -1; botweapon(d); return; };
    if(d->gunselect) d->ammo[d->gunselect]--;
    vec from = d->o;
    vec to = d->botpos;
    from.z -= 0.8f;    // below eye

    vec unitv;
    float dist = to.dist(from, unitv);
    unitv.div(dist);
    vec kickback(unitv);
    kickback.mul(cl.ws.guns[d->gunselect].kickamount*-2.5f);
    d->vel.add(kickback);
    if(d->pitch<80.0f) d->pitch += cl.ws.guns[d->gunselect].kickamount*0.05f;
    float shorten = 0.0f;

    if(dist>1024) shorten = 1024;
    if(d->gunselect==GUN_FIST || d->gunselect==GUN_BITE) shorten = 12;
    float barrier = raycube(d->o, unitv, dist, RAY_CLIPMAT|RAY_POLY);
    if(barrier < dist && (!shorten || barrier < shorten))
	shorten = barrier;
    if(shorten)
    {
        to = unitv;
        to.mul(shorten);
        to.add(from);
    };

    if(d->gunselect==GUN_SG) cl.ws.createrays(from, to);
    else if(d->gunselect==GUN_CG) cl.ws.offsetray(from, to, 1, to);

    if(d->quadmillis && attacktime>200) playsound(S_ITEMPUP, &d->o);

    if(!cl.ws.guns[d->gunselect].projspeed) cl.ws.raydamage(from, to, d);

    cl.ws.shootv(d->gunselect, from, to, d, true);

    //if(d->type!=ENT_AI) cl.cc.addmsg(SV_SHOT, "ri7", d->gunselect, (int)(from.x*DMF), (int)(from.y*DMF), (int)(from.z*DMF), (int)(to.x*DMF), (int)(to.y*DMF), (int)(to.z*DMF));

    d->gunwait = cl.ws.guns[d->gunselect].attackdelay;

    d->totalshots += cl.ws.guns[d->gunselect].damage*(d->quadmillis ? 4 : 1)*(d->gunselect==GUN_SG ? cl.ws.SGRAYS : 1);
};

// entities
void botradditem(int i, int &v, fpsent *d)
{
    cl.et.ents[i]->spawned = false;
    v += cl.et.itemstats[ents[i]->type-I_SHELLS].add;
    if(v>cl.et.itemstats[ents[i]->type-I_SHELLS].max) v = cl.et.itemstats[ents[i]->type-I_SHELLS].max;
    playsound(cl.et.itemstats[ents[i]->type-I_SHELLS].sound, &d->o);
};

void botrealpickup(int n, fpsent *d)
{
    char *name = cl.et.itemname(n);
    if(name) particle_text(d->abovehead(), name, 15);
    switch(cl.et.ents[n]->type)
    {
        case I_SHELLS:     botradditem(n, d->ammo[GUN_SG], d); break;
        case I_BULLETS:    botradditem(n, d->ammo[GUN_CG], d); break;
        case I_ROCKETS:    botradditem(n, d->ammo[GUN_RL], d); break;
        case I_ROUNDS:     botradditem(n, d->ammo[GUN_RIFLE], d); break;
        case I_GRENADES:   botradditem(n, d->ammo[GUN_GL], d); break;
        case I_CARTRIDGES: botradditem(n, d->ammo[GUN_PISTOL], d); break;
        case I_HEALTH:     botradditem(n, d->health, d); break;

        case I_BOOST:
            d->maxhealth += 10;
            botradditem(n, d->health, d);
            break;

        case I_GREENARMOUR:
            botradditem(n, d->armour, d);
            d->armourtype = A_GREEN;
            break;

        case I_YELLOWARMOUR:
            botradditem(n, d->armour, d);
            d->armourtype = A_YELLOW;
            break;

        case I_QUAD:
            botradditem(n, d->quadmillis, d);
            break;
    };
};

// these functions are called when the client touches the item

void botadditem(int i, int &v, int sec, fpsent *d)
{
    if(v<cl.et.itemstats[cl.et.ents[i]->type-I_SHELLS].max)                              // don't pick up if not needed
    {
        if(cl.et.ents[i]->spawned)
        {
            cl.et.ents[i]->spawned = false;
            if(cl.et.ents[i]->type==I_QUAD || cl.et.ents[i]->type==I_BOOST) sec += rnd(40)-20;
            //sv->sents[i].spawned = false;
            //sv->sents[i].spawnsecs = sec;
			botrealpickup(i, d);
        };
    };
};

void botteleport(int n, fpsent *d)     // also used by monsters
{
    int e = -1, tag = cl.et.ents[n]->attr1, beenhere = -1;
    for(;;)
    {
        e = findentity(TELEDEST, e+1);
        if(e==beenhere || e<0) { conoutf("no teleport destination for tag %d", tag); return; };
        if(beenhere<0) beenhere = e;
        if(cl.et.ents[e]->attr2==tag)
        {
            d->o = cl.et.ents[e]->o;
            d->yaw = cl.et.ents[e]->attr1;
            d->pitch = 0;
            d->vel = vec(0, 0, 0);//vec(cosf(RAD*(d->yaw-90)), sinf(RAD*(d->yaw-90)), 0);
            entinmap(d);
            playsound(S_TELEPORT, &d->o);

			d->botcurnode = d->botlastnode = d->botprevnode = botnode(d, false); // update location after teleport
			botcoord(d, 0, 100*d->botrate);
            break;
        };
    };
};

void botpickup(int n, fpsent *d)
{
    int np = 1;
    loopv(cl.players) if(cl.players[i] && cl.players[i]->state!=CS_SPECTATOR) np++;
    np = np<3 ? 4 : (np>4 ? 2 : 3);         // spawn times are dependent on number of players
    int ammo = np*4;
    switch(cl.et.ents[n]->type)
    {
        case I_SHELLS:     botadditem(n, d->ammo[GUN_SG], ammo, d); break;
        case I_BULLETS:    botadditem(n, d->ammo[GUN_CG], ammo, d); break;
        case I_ROCKETS:    botadditem(n, d->ammo[GUN_RL], ammo, d); break;
        case I_ROUNDS:     botadditem(n, d->ammo[GUN_RIFLE], ammo, d); break;
        case I_GRENADES:   botadditem(n, d->ammo[GUN_GL], ammo, d); break;
        case I_CARTRIDGES: botadditem(n, d->ammo[GUN_PISTOL], ammo, d); break;
        case I_HEALTH:     botadditem(n, d->health,  np*5, d); break;
        case I_BOOST:      botadditem(n, d->health,  60, d); break;

        case I_GREENARMOUR:
            // (100h/100g only absorbs 200 damage)
            if(d->armourtype==A_YELLOW && d->armour>=100) break;
            botadditem(n, d->armour, 20, d);
            break;

        case I_YELLOWARMOUR:
            botadditem(n, d->armour, 20, d);
            break;

        case I_QUAD:
            botadditem(n, d->quadmillis, 60, d);
            break;

        case TELEPORT:
        {
            //static int lastteleport = 0;
            //if(cl.lastmillis-lastteleport<500) break;
            //lastteleport = cl.lastmillis;
            botteleport(n, d);
            break;
        };

        //case RESPAWNPOINT:
        //    if(n==cl.respawnent) break;
        //    cl.respawnent = n;
        //    conoutf("\f2respawn point set!");
        //    playsound(S_V_RESPAWNPOINT);
        //    break;

        case JUMPPAD:
        {
            //static int lastjumppad = 0;
            //if(cl.lastmillis-lastjumppad<300) break;
            //lastjumppad = cl.lastmillis;
            vec v((int)(char)cl.et.ents[n]->attr3*10.0f, (int)(char)cl.et.ents[n]->attr2*10.0f, cl.et.ents[n]->attr1*12.5f);
            d->timeinair = 0;
            d->gravity = vec(0, 0, 0);
            d->vel = v;
//                cl.player1->vel.z = 0;
//                cl.player1->vel.add(v);
            playsound(S_JUMPPAD, &d->o);
            break;
        };
    };
};

void botitems(fpsent *d)
{
    cl.et.itemstats[I_HEALTH-I_SHELLS].max = d->maxhealth;
    vec o = d->o;
    o.z -= d->eyeheight;
    loopv(cl.et.ents)
    {
        extentity &e = *cl.et.ents[i];
        if(e.type==NOTUSED) continue;
        if(!e.spawned && e.type!=TELEPORT && e.type!=JUMPPAD && e.type!=RESPAWNPOINT) continue;
        float dist = e.o.dist(o);
        if(dist<(e.type==TELEPORT ? 16 : 12)) botpickup(i, d);
    };
};

void botquad(fpsent *d)
{
	extern int curtime;
    if(d->quadmillis && (d->quadmillis -= curtime)<0)
    {
        d->quadmillis = 0;
        playsound(S_PUPOUT, &d->o);
    };
};
