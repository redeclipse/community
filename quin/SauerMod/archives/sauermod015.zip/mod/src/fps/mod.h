// SauerMod - MODGAME - Game Extensions by Quinton Reeves
// This is the primary mod hook into fpsgame.

#include "modfps.h"

struct modgame
{
    fpsclient &cl;

	#include "moddef.h"
	#include "modutl.h"
	#include "bot.h"

	IVAR(scoreshud, 0, 0, 1);		// saved setting, show scores on the hud
	IVAR(cameracycle, 0, 0, 600);	// unsaved setting, cycle camera every N secs
	IVAR(crosshair, 0, 1, 1);		// saved setting, show the crosshair

    modgame(fpsclient &_cl) : cl(_cl), bs(_cl), cameranum(-1), cameracycled(0)
	{
        CCOMMAND(modgame, cameradir, "i", { self->modcameradir(atoi(args[0])); });

		execfile("mod/data/mod.cfg");
   	}
};
modgame md; // SauerMod
