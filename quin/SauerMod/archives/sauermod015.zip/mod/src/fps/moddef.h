// SauerMod - MODGAME - Game Extensions by Quinton Reeves
// Definitions and addons for modgame.

#define MODVERSION		1								// mod version

// extended entities
enum {
	MAXEXTENTS
};
