// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/game.h

int botstate, botrate;	  					// bot state and movement/error rate
vec botpos, botrot, botvec;		 			// targeting/homing vector
int botms, botstart;           				// millis at which transition to another aistate takes place
int botcurnode, botlastnode;				// waypoint nodes
bool botret; 		                         // retaliation
fpsent *botenemy;                           // bot last enemy
