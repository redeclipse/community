// SauerMod - MODGAME - Game Extensions by Quinton Reeves

struct modgame
{
    fpsclient &cl;

	#include "moddef.h"

    modgame(fpsclient &_cl) : cl(_cl)
	{
		extern bool persistidents;
	    persistidents = true;
		execfile("mod/data/mod.cfg");
	    persistidents = false;
   	}
};

