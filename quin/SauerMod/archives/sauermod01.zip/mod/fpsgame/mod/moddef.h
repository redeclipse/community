// SauerMod - MODGAME - Game Extensions by Quinton Reeves

#define MODVERSION		1								// mod version

// extended entities
enum {
	FLAG = 100,
	MAXEXTENTS
};
