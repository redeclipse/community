// SauerMod - SSPGAME - Side Scrolling Platformer by Quinton Reeves
// This is the SSP rendering processes.

physent sspcamera;

void fixcamerarange(physent *d)
{
    const float MAXPITCH = 90.0f;
    if(d->pitch>MAXPITCH) d->pitch = MAXPITCH;
    if(d->pitch<-MAXPITCH) d->pitch = -MAXPITCH;
    while(d->yaw<0.0f) d->yaw += 360.0f;
    while(d->yaw>=360.0f) d->yaw -= 360.0f;
}

void mousemove(int dx, int dy)
{
    const float SENSF = 33.0f;     // try match quake sens
    extern int sensitivity, sensitivityscale, invmouse;

    if (editmode)
	{
		player1->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
    	player1->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
    
		fixcamerarange((physent *)player1);
	}
	else if (menuactive())
	{
		camera1->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
    	camera1->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
    
		fixcamerarange((physent *)camera1);
	}
}

void recomputecamera()
{
	camera1 = &sspcamera;
	
	if (camera1->type != ENT_CAMERA)
	{
		camera1->reset();
		camera1->type = ENT_CAMERA;
	}

	camera1->move = camera1->strafe = 0;
	camera1->o = player1->o;

	if (!editmode)
	{
		if (!thirdperson)
		{ // side view ala 2D Mario
			camera1->o.x -= WORLDOFFSET;
			//camera1->o.y += player1->vel.y*0.25f; // acts funny when jumping, how should we do this?
			camera1->o.z -= player1->eyeheight/2;
			
			if (!menuactive())
			{
				camera1->yaw = 90.f;
				camera1->pitch = 0.f;
			}

	    	camera1->eyeheight = 1;

			// keep camera in the level, for aesthetic reasons really
			#define keepinlevel(x) \
				if (x < WORLDOFFSET*2) { x = WORLDOFFSET*2; } \
				else if (x > getworldsize()-(WORLDOFFSET*2)) { x = getworldsize()-(WORLDOFFSET*2); }
			
			keepinlevel(camera1->o.y);
			keepinlevel(camera1->o.z);
		}
		else
		{ // behind view ala 3D crash bandicoot
			camera1->o.y -= WORLDOFFSET;
			camera1->o.z += player1->eyeheight;

			if (!menuactive())
			{
				camera1->yaw = 180.f;
				camera1->pitch = 0.f;
			}

	    	camera1->eyeheight = 1;
		}
	}
	else
	{
		camera1->yaw = player1->yaw;
		camera1->pitch = player1->pitch;
		camera1->eyeheight = player1->eyeheight;
	}
	
    fixcamerarange(camera1);
}

void rendergame()
{
    if (!editmode)
	{
		int strafe = player1->strafe, move = player1->move;
		//float pitch = player1->pitch;
		int powr = (player1->power >= 0 && player1->power <= 3 ? player1->power : 0);
		char *powers[] = { "monster/ogro", "monster/ogro", "monster/ogro/blue", "monster/ogro/red" };
		const char *vwep = (player1->power > 2 ? "monster/ogro/vwep" : NULL);

		if (levelend)
		{
			player1->move = player1->strafe = 0;
		}
		else
		{
			if (!thirdperson)
			{
				player1->move = (strafe ? 1 : 0);
				player1->strafe = 0;
			}
			else
			{
				player1->move = (move ? 1 : 0);
				player1->strafe = 0;
			}
		}

		/* looks pretty, but breaks proper collision detection
		if (player1->inwater)
		{
			float wp = 270.f * (player1->timeinwater < 100 ? player1->timeinwater*0.01f : 1.f);
			player1->pitch = -wp;
		}	
		else player1->pitch = 0.f;
		*/
		
		renderclient(player1, powers[powr], vwep, false, player1->lastaction, player1->lastpain);
		
		player1->move = move;
		player1->strafe = strafe;
		//player1->pitch = pitch;
	}
    et.renderentities();
    en.renderenemies();
}

void drawicon(const char *icon, float x, float y)
{
    settexture(icon);
    glBegin(GL_QUADS);
    int s = 120;
    glTexCoord2f(0.0f, 0.0f); glVertex2i(x,   y);
    glTexCoord2f(1.0f, 0.0f); glVertex2i(x+s, y);
    glTexCoord2f(1.0f, 1.0f); glVertex2i(x+s, y+s);
    glTexCoord2f(0.0f, 1.0f); glVertex2i(x,   y+s);
    glEnd();
}

void gameplayhud(int w, int h)
{
    glLoadIdentity();
    glOrtho(0, w*900/h, 900, 0, -1, 1);
    if(!editmode)
    {
		if (player1->lives > 0)
		{
	        draw_textf("x %d", 90, 822, player1->lives);
	        draw_textf("x %d", 390, 822, player1->coins);
	        
			if (leveltime/1000 < TIMELIMIT)
	        	draw_textf("%d", 690, 822, TIMELIMIT-(leveltime/1000));
	        else
	        	draw_textf("TIME UP", 690, 822);
	
	        glLoadIdentity();
	        glOrtho(0, w*1800/h, 1800, 0, -1, 1);
	
	        glDisable(GL_BLEND);
	
	        drawicon("packages/icons/ogro.jpg", 20, 1650);
			drawicon("packages/icons/coins.jpg", 620, 1650);
			drawicon("packages/icons/action.jpg", 1220, 1650);
		}
		else
	        draw_textf("GAME OVER", 20, 822);
	}	
}
void drawhudgun() {}
    
void gui(g3d_gui &g, bool firstpass) {}
void g3d_gamemenus() {}

bool wantcrosshair() { return editmode; }
