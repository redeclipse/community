// SauerMod - SSPGAME - Side Scrolling Platformer by Quinton Reeves
// This is the SSP enemies


struct sspenemy
{
	sspclient &cl;

	vector<enemyent *> enemies;
	
	struct enemytype
	{
		int type, scale;			// enum of the enemy / scale of enemy
		char *name, *model;			// name of enemy / model of enemy
	} *enemytypes;

	sspenemy(sspclient &_cl) : cl(_cl)
	{
		static enemytype _enemytypes[] = {
			{ EN_HELLPIG, 8, "hellpig", "monster/hellpig" },
		};
		enemytypes = _enemytypes;
	}		

	void setenemy(enemyent *d, int a, int b)
	{
		d->enemytype = (a < 0 || a >= EN_MAX ? 0 : a);
		d->power = (b < 0 || b >= PWR_MAX ? 1 : b);
		d->state = CS_ALIVE;
        d->type = ENT_AI;
        d->enemystate = ES_WAIT;
        d->move = d->strafe = 0;
        d->eyeheight = 8.0f;
        d->aboveeye = 7.0f;
        d->radius *= enemytypes[d->enemytype].scale/10.0f;
        d->eyeheight *= enemytypes[d->enemytype].scale/10.0f;
        d->aboveeye *= enemytypes[d->enemytype].scale/10.0f;
        d->yaw = 0;
        d->pitch = 0;
        d->roll = 0;
	}

	void addenemy(int a, int b, int c, vec &o)
	{
        enemyent *d = new enemyent;
        enemies.add(d);
        setenemy(d, a, b);
        d->o = o;
        entinmap(d);
	}

	void clearenemies()
	{
        loopv(enemies) delete enemies[i]; 
        cleardynentcache();
        enemies.setsize(0);
	}
	
	void checkenemies()
	{
        loopv(enemies)
        {
            enemyent *d = enemies[i];

	        vec from = cl.player1->o;
	        vec to = cl.player1->o;
	        to.z -= cl.player1->eyeheight+2.f;

            if (d->state == CS_ALIVE)
            {
				vec dist;
				dist = d->o;
				dist.sub(to);
				
				if (abs(dist.x) <= d->radius && abs(dist.y) <= d->radius && abs(dist.z) <= d->aboveeye)
				{
			        vec v(to);
			        v.sub(from);
			        v.normalize();
			        v.mul(cl.player1->jumpnext ? -250 : -100);
					cl.player1->vel.add(v);
					
					d->power--;
					
					if (d->power <= 0)
					{
						d->state = CS_DEAD;
		                d->lastaction = cl.lastmillis;
					}
					else
					{
						v.mul(-1);
						d->vel.add(v);
					}
				}
			}

            if (d->state == CS_ALIVE)
            {
				moveplayer(d, 2, false);
			}
			else
            {
				if(cl.lastmillis-d->lastaction<2000)
				{
				    d->move = d->strafe = 0;
				    moveplayer(d, 2, false);
				}
            }
        }
	}

	void renderenemies()
	{
        loopv(enemies)
        {
            enemyent *d = enemies[i];
            if(d->state!=CS_DEAD || cl.lastmillis-d->lastaction<2000) renderclient(d, enemytypes[d->enemytype].model, NULL, d->enemystate==ES_ATTACK, d->lastaction, d->lastpain);
        }
	}
};
