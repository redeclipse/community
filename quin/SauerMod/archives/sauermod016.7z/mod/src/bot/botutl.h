// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// This is a set of helpful macros used throughout the bot code.

bool bot(fpsent *d)
{
	return d != NULL && d != cl.player1 && d->botstate != M_NONE;
}

bool botteam(char *a, char *b)
{
	int gamemode = cl.gamemode;
	return (m_teammode ? isteam(a, b) : false);
}

void botnames(const char *fname)
{
    string mapname;
    if(strpbrk(fname, "/\\")) s_strcpy(mapname, fname);
    else s_sprintf(mapname)("base/%s", fname);

    s_sprintf(botcfgname)("mod/data/%s.bcf", mapname);
    path(botcfgname);

    s_sprintf(botwayname)("mod/data/%s.wpz", mapname);
    path(botwayname);
}

bool inlos(vec &o, vec &q, vec &v)
{
    vec ray(q.x, q.y, q.z);
    ray.sub(o);
    v.sub(v);
    float mag = ray.magnitude();
    float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
    return distance >= mag; 
}

bool insight(fpsent *d, vec &q, vec &v, float mdist)
{
	vec see(d->o.x, d->o.y, d->o.z);
	float dist = see.dist(q);
	
	if (dist <= mdist)
	{
		float x = fabs((asin((q.z - d->o.z) / dist) / RAD) - d->botrot.x);
		float y = fabs((-(float)atan2(q.x - d->o.x, q.y - d->o.y)/PI*180+180) - d->botrot.y);

		if (x <= BOTFOVX(d->botrate) && y <= BOTFOVY(d->botrate))
			return inlos(d->o, q, v);
	}
	
	return false;
}

void botaimat(fpsent *d)
{
	extern int curtime;
	float bk = curtime * (1.01f - (d->botrate * 0.01f));

	d->botrot.y = -(float)atan2(d->botvec.x - d->o.x, d->botvec.y - d->o.y)/PI*180+180;
    if(d->yaw<d->botrot.y-180.0f) d->yaw += 360.0f;
    if(d->yaw>d->botrot.y+180.0f) d->yaw -= 360.0f;
    float dist = d->o.dist(d->botvec);
	d->botrot.x = asin((d->botvec.z - d->o.z) / dist) / RAD;
    if(d->botrot.x>90.f) d->botrot.x = 90.f;
    if(d->botrot.x<-90.f) d->botrot.x = -90.f;

    if(d->botrot.y>d->yaw)             // slowly turn bot towards his target
    {
        d->yaw += bk;
        if(d->botrot.y<d->yaw) d->yaw = d->botrot.y;
    }
    else if(d->botrot.y<d->yaw)
    {
        d->yaw -= bk;
        if(d->botrot.y>d->yaw) d->yaw = d->botrot.y;
    }

    if(d->botrot.x>d->pitch)
    {
        d->pitch += bk;
        if(d->botrot.x<d->pitch) d->pitch = d->botrot.x;
    }
    else if(d->botrot.x<d->pitch)
    {
        d->pitch -= bk;
        if(d->botrot.x>d->pitch) d->pitch = d->botrot.x;
    }

    vec dir(0, 0, 0);
    vecfromyawpitch(d->yaw, d->pitch, 1, 0, dir);
    if(raycubepos(d->o, dir, d->botpos, 0, RAY_CLIPMAT|RAY_SKIPFIRST) == -1)
        d->botpos = dir.mul(10).add(d->o);
}

void botvec(fpsent *d)
{
    vec ray(d->botpos.x, d->botpos.y, d->botpos.z);
    ray.sub(d->o);
    float mag = ray.magnitude();
    raycubepos(d->o, ray, d->botpos, mag, RAY_CLIPMAT|RAY_POLY);
}

void botrender()
{
	if (!cl.cc.remote && !cl.intermission)
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 4) conoutf("# bot render pass..");
		#endif
	
		if (botshow())
		{
			#ifdef BOTDEBUG
			if (botdebug() >= 5) conoutf("# displaying botwaypoints...");
			#endif
	
			loopv(botwaypoints) // purrty botwaypoints
			{
				vec target;
				extern physent *camera1;
				if (inlos (camera1->o, botwaypoints[i]->pos, target))
				{
					int red = 0, blue = 0; // shows bot targets
					string wp;
		
					loopvj(cl.players)
					{
						if (cl.players[j] && bot(cl.players[j]) && cl.players[j]->state == CS_ALIVE)
						{
							if (i == cl.players[j]->botcurnode)
							{
								blue++;
							}
							else if (i == cl.players[j]->botlastnode)
							{
								red++;
							}
						}
					}
	
					s_sprintf(wp)("@botwaypoint (%d)", i);
	    	        particle_text(botwaypoints[i]->pos, wp, (red || blue ? (red > blue ? 13 : 16) : 14), 1);
		    	    particle_splash((red || blue ? (red > blue ? 3 : 2) : 0), 2, 50, botwaypoints[i]->pos);
	
					loopvj(botwaypoints[i]->nodes)
					{
						int y = botwaypoints[i]->nodes[j];
						
						if (botwaypoints.inrange(y))
						{
							particle_flare(botwaypoints[i]->pos, botwaypoints[y]->pos, 1);
						}
					}
				}
			}
		}
	}
}
