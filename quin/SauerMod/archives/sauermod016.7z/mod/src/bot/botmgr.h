// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// These are hooks for the console/script commands to manage the bots and their waypoints.

void botreset()
{
	execute("botnum 0");
	execute("botdrop 0");
	//execute("botshow 0");
	extern int nonlocalclients;
	nonlocalclients = 0;
	botwaylast = -1;
	botcfgname[0] = botwayname[0] = 0;
}

void botwritecfg()
{
	FILE *f = fopen("mod/data/bot.cfg", "w");
	if(!f) return;
	fprintf(f, "// bot settings are saved here\n\n");
	fprintf(f, "botrate %d\n", botrate());
	fprintf(f, "botauto %d\n", botauto());
	fclose(f);
}

void botclear()
{
	/*if (cl.players.length() > 0)
	{
		loopv(cl.players)
		{
			if (cl.players[i])
			{
  				DELETEP(cl.players[i]);
			}
		}
	}

	cl.players.setsize(0);
	cleardynentcache();*/

	botreset();
	botwayclear();
}

void botstart(const char *map)
{
    if (!cl.cc.remote)
    {
        if (*map && !editmode) // otherwise we may be editing..
        {
			int gamemode = cl.gamemode;
			extern void show_out_of_renderloop_progress(float bar1, const char *text1, float bar2 = 0, const char *text2 = NULL);
			
			//if (!cl.getclient(0)) cl.players.add(NULL);
			//cl.players[0] = cl.player1;
			cl.cc.currentmaster = cl.player1->clientnum = 0;
			
			if (BOTGAMEMODE(gamemode))
			{
				show_out_of_renderloop_progress(0, "loading bots...");

				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# bots loading...");
				#endif
	
				botnames(map);
				execfile(botcfgname);
				
				show_out_of_renderloop_progress(0.5f, "populating bot data...");

				if (!botwayload())
					botwaynodes();
				else if (botauto())
					botadd(-1, -1);
				
				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# bots loaded.");
				#endif
			}
			show_out_of_renderloop_progress(1, "bots loaded.");
		}
	}
}

bool botplayers()
{
	extern int nonlocalclients;
			
	botwaypos(false); // player1 botwaypoint dropping

	if (!cl.cc.remote && !cl.intermission && nonlocalclients)
	{
		#ifdef BOTDEBUG
		if (botdebug() >= 5) conoutf("# ai update (%d player(s))", cl.players.length());
		#endif

		loopv(cl.players) // state of other 'clients'
		{
	       	if (cl.players.inrange(i) && bot(cl.players[i]))
	       	{
				botthink(cl.players[i]);
			}
		}

		#ifdef BOTDEBUG
		if (botdebug() >= 5) conoutf("# ai update complete.");
		#endif

		return true;
	}
	return false;
}

void botadd(int num, int ar)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		extern int nonlocalclients;
		int gamemode = cl.gamemode;
		if (BOTGAMEMODE(gamemode))
		{
			int n = (num >= 0 ? num : botnum()), s = (ar >= 0 ? ar : botrate());
			
			if (n == 0)
			{
				int r = 0;
				loopv(ents) if (ents[i]->type == PLAYERSTART)
				{
					r++;
				}
				n = max(r >= 8 ? r - (r / 3) : r - 2, 2);
				
			}
			
			if (n <= 0)
				return;
	
	        while (n > 0 && nonlocalclients < 16)
	        {
	       		nonlocalclients++; // doubles as clientnum, just treat bots as a stack.
	
	           	fpsent *d = cl.newclient(nonlocalclients);
	
				if (d)
				{
			        string botname;
	
			        d->move = d->strafe = 0;
		          	cl.spawnstate(d);
					
			        #ifdef BOTDEBUG
					if (botdebug() >= 1) conoutf("# bot %s starting.", d->name);
					#endif
					
					d->state = CS_DEAD;
					d->botrate = (s < 1 ? 1 : (s > 100 ? 100 : s));
		
			        s_sprintf(botname)("bot_%02d", d->clientnum);
			        s_strcpy(d->name, botname);
			        s_sprintf(botname)("%s", (d->clientnum % 2 ? "good" : "evil"));
			        s_strcpy(d->team, botname);
	
					conoutf("connected: %s", &d->name);
		            
					bottrans(d, M_PAIN, 0, 0, true, nonlocalclients*100);
		           	n--;
				}
				else
					fatal("cannot get bot entity");
			}
			//execute("botshow 0");
		}
		else
			conoutf("ERROR: Bots are not available in this game mode");
	}
	else
		conoutf("ERROR: Bots are only available in active offline games");
}

void botdel(int num)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		if (cl.players.length() <= 1) return;

		int n = (num >= 0 ? num : 1);
		extern int nonlocalclients;
		
		if (n == 0 || !cl.players.inrange(n))
		{
			n = cl.players.length()-1;
		}	
		
		int x = cl.players.length()-1;
		
        while (x >= 0 && n > 0 && cl.players.length() > 1) 
		{
			if (cl.players.inrange(x) && bot(cl.players[x]))
        	{
                conoutf("player %s disconnected", &cl.players[x]->name);
                DELETEP(cl.players[x]);
                cleardynentcache();
				n--;
        		nonlocalclients--;
			}
			x--;
		}
	}
	else
		conoutf("delbot is only available in active offline games");
}
