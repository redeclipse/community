// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/game.h
// These are the extra fpsent variables the bots use.
// TODO: Transfer bot specific stuff to fpsent subclass `botent'.

int botstate, botrate;	  					// bot state and movement/error rate
vec botpos, botrot, botvec;		 			// targeting/homing vector
int botms, botstart;           				// millis at which transition to another aistate takes place
int botcurnode, botlastnode, botprevnode;	// waypoint nodes
fpsent *botenemy;                           // bot last enemy
