// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/fps.cpp
// This is the primary bot hook for fpsgame called by modgame.

struct botset
{
    fpsclient &cl;
    vector<extentity *> &ents;

	#include "botdef.h"	// definitions
	#include "botutl.h"	// utilities
	#include "botemu.h"	// emulation layer
	#include "botmgr.h"	// management
	#include "botway.h"	// botwaypoints and nodes
	#include "botai.h"	// artificial intelligence

    int botwaylast;
	vector<botway *> botwaypoints;
    string botcfgname, botwayname;

	IVAR(botrate, 1, 25, 100);	// saved setting, rate of action updates and judgement errors
	IVAR(botauto, 0, 1, 1);		// saved setting, automically load bots on start of map
	IVAR(botnum, 0, 0, 15);		// unsaved setting, set to force a number of bots when automatically loading
	IVAR(botdrop, 0, 0, 1);		// automatic setting, drop botwaypoints during play
	IVAR(botshow, 0, 0, 1);		// unsaved setting, show bot debugging like botwaypoints
#ifdef BOTDEBUG
	IVAR(botdebug, 0, 0, 9);	// unsaved debug setting, view debug messages
#endif

    botset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents), botwaylast(-1)
	{
        CCOMMAND(botset, botadd, "ss", { int num = (args[0][0] ? atoi(args[0]) : -1); int ar = (args[1][0] ? atoi(args[1]) : -1); self->botadd(num, ar); });
        CCOMMAND(botset, botdel, "s", { int num = (args[0][0] ? atoi(args[0]) : -1); self->botdel(num); });
        CCOMMAND(botset, botload, "", { self->botwayload(); });
        CCOMMAND(botset, botsave, "", { self->botwaysave(); });
        CCOMMAND(botset, botwaydrop, "", { self->botwaypos(true); });

		execfile("mod/data/bot.cfg");
	}
};

botset      bs; // SauerMod

