// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// This is the core of the waypoint navigational system used by the bots.

void botwayclear()
{
	if (botwaypoints.length() > 0)
	{
		loopv(botwaypoints)
		{
			loopvj(botwaypoints[i]->nodes)
			{
				botwaypoints[i]->nodes.remove(j);
			}
			botwaypoints[i]->nodes.setsize(0);
			DELETEP(botwaypoints[i]);
		}
	}
	botwaypoints.setsize(0);
}

int botwaypoint(int x, int y, int z, bool force)
{
	int n = botwaypoints.length();
	botway *e = new botway;
	vec p(x, y, z);

	e->pos = p;
	e->nodes.setsize(0);
	
	botwaypoints.add(e);

	if (!force)
	{
		if (botwaypoints.inrange(n))
		{
			if (botwaypoints.inrange(botwaylast))
				botwaynodeadd(botwaylast, n, force);
			botwaylast = n;
		}
	}

	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# botwaypoint placed at %4.0f,%4.0f,%4.0f", e->pos.x, e->pos.y, e->pos.z);
	#endif
					
	return n;
}

bool botwayjoined (int a, int b)
{
	if (a != b && botwaypoints.inrange(a) && botwaypoints.inrange(b))
	{
		loopv(botwaypoints[a]->nodes)
		{
			if (botwaypoints[a]->nodes[i] == b)
				return true;
		}
	}
	return false;
}

void botwaypos(bool force)
{
    if (!cl.cc.remote && !cl.intermission)
    {
		bool isdropping = (cl.player1->state == CS_ALIVE && botdrop());
		if (force || isdropping)
		{
			#ifdef BOTDEBUG
			if (botdebug() >= 5) conoutf("# checking to generate botwaypoint..");
			#endif
			
			if (isdropping)
			{
				loopv(botwaypoints)
				{
					if (botwaypoints[i]->pos.dist(cl.player1->o) <= BOTISNEAR)
					{
						if (i != botwaylast)
						{
							if (botwaypoints.inrange(botwaylast))
								botwaynodeadd(botwaylast, i, force);
							
							botwaylast = i;
						}
					}
				}
			}
			if (force || !botwaypoints.inrange(botwaylast) || botwaypoints[botwaylast]->pos.dist(cl.player1->o) >= BOTWPDIST)
			{
				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# dropping botwaypoint..");
				#endif
				botwaypoint((int)cl.player1->o.x, (int)cl.player1->o.y, (int)cl.player1->o.z, false);
			}
				
			return;
		}
	}
	botwaylast = -1;
}

void botwaynodes()
{
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# auto generating nodes");
	#endif
	
	execute("botdrop 1");
	execute("botshow 1");
	
	conoutf("WARNING: No botwaypoints saved for this map, entering generation mode.");
	
	loopv(cl.et.ents)
	{
		int t = cl.et.ents[i]->type;
		
		if ((t >= I_SHELLS && t <= TELEPORT) || t == JUMPPAD || t == BASE)
			botwaypoint((int)cl.et.ents[i]->o.x, (int)cl.et.ents[i]->o.y, (int)cl.et.ents[i]->o.z, true);
	}
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# generated %d botwaypoint(s) without nodes from %d ent(s)", botwaypoints.length(), cl.et.ents.length());
	#endif
}

void botwaynodeadd(int n, int m, bool force)
{
	#ifdef BOTDEBUG
	if (botdebug() >= 1) conoutf("# attempting to connect node %d with %d", n, m);
	#endif
	
	if (!force || (botwaypoints.inrange(n) && botwaypoints.inrange(m)))
	{
		vec target;

		if (n != m && !botwayjoined(n, m))
		{
			if (inlos (botwaypoints[n]->pos, botwaypoints[m]->pos, target))
			{
				botwaypoints[n]->nodes.add(m);
				//botwaypoints[m]->nodes.add(n);
				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# botwaypoint node %d connected with %d", n, m);
				#endif
			}
			else if (force)
			{
				// no line of sight, try connecting with different nodes
				int w = -1;
				
				vec t(0, 0, 0), v(0, 0, 0), r(0, 0, 0);
	
				#ifdef BOTDEBUG
				if (botdebug() >= 1) conoutf("# unable to find a line of sight node, trying to find a close node");
				#endif
					
				t.add(botwaypoints[m]->pos);
				t.sub(botwaypoints[n]->pos);
	
				v.add(t);
				v.mul(0.5);
	
				r.add(botwaypoints[n]->pos);
				r.add(v);
				
				loopv(botwaypoints)
				{
					if (i != n && i != m && !botwayjoined(n, m) && botwaypoints[i]->pos.dist(r) <= BOTWPDIST && (!botwaypoints.inrange(w) || botwaypoints[i]->pos.dist(r) <= botwaypoints[w]->pos.dist(r)))
					{
						if (inlos (botwaypoints[n]->pos, botwaypoints[i]->pos, target) && inlos (botwaypoints[m]->pos, botwaypoints[i]->pos, target))
						{
							w = i;
						}
					}
				}
				if (botwaypoints.inrange(w))
				{
					botwaynodeadd(n, w, false);
					botwaynodeadd(w, m, false);
				}
				else
				{
					// gee, that sucks, can we make a node to connect them both?
					#ifdef BOTDEBUG
					if (botdebug() >= 1) conoutf("# can't even get a node, making one then.");
					#endif
	
					loopi(6)
					{
						v.sub(v);
						v.add(t);
						
						if (i == 1 || i == 2 || i == 5)
							v.x = 0.0;
						if (i == 0 || i == 2 || i == 4)
							v.y = 0.0;
						if (i == 0 || i == 1 || i == 3)
							v.x = 0.0;
						
						r.sub(r);
						r.add(botwaypoints[n]->pos);
						r.add(v);
	
						if (inlos (botwaypoints[n]->pos, r, target) && inlos (botwaypoints[m]->pos, r, target))
						{
							w = botwaypoint((int)r.x, (int)r.y, (int)r.z, true);
							
							if (botwaypoints.inrange(w))
							{
								botwaynodeadd(n, w, false);
								botwaynodeadd(w, m, false);
							}
							break;
						}
					}
				}
			}
		}
	}
}

int botgetint(gzFile f)
{
	int t;
    gzread(f, &t, sizeof(int));
    endianswap(&t, sizeof(int), 1);
    return t;
}

void botputint(gzFile f, int x)
{
	int t = (int)x;
   	endianswap(&t, sizeof(int), 1);
   	gzwrite(f, &t, sizeof(int));
}

bool botwayload()
{
	conoutf("loading botway: %s", botwayname);
    gzFile f = gzopen(botwayname, "rb9");
    if(f)
	{
		bool ans = false;

		char head[4];
		int version;

	    gzread(f, &head, 4);
	    version = botgetint(f);
	    			
		#ifdef BOTDEBUG
		if (botdebug() >= 1) conoutf("# version: %d", version);
		#endif

		if (!strncmp(head, "WAYP", 4))
		{
			if (version == BOTWPVERSION)
			{
				extern void show_out_of_renderloop_progress(float bar1, const char *text1, float bar2 = 0, const char *text2 = NULL);

				int botways, x, y, z;
				float bar1;
				
				botways = botgetint(f); // number of botwaypoints
				
				loopi(botways) // load botwaypoint positions
				{
					bar1 = float(i) / float(botways);
					show_out_of_renderloop_progress(bar1, "loading waypoints...");
					x = botgetint(f);
					y = botgetint(f);
					z = botgetint(f);
					botwaypoint(x, y, z, true);
				}					
				
				loopi(botways) // load botwaypoint node connections, this is done after because of validity checks
				{
					x = botgetint(f); // number of nodes
					
					loopj(x)
					{
						bar1 = float(j) / float(x);
						show_out_of_renderloop_progress(bar1, "loading waypoint nodes...");
						y = botgetint(f); // node botwaypoint number
	
						//botwaypoints[i]->nodes.add(y);
						botwaynodeadd(i, y, true);
					}
				}
				ans = true;
				conoutf("loaded %d botwaypoint(s) from %s", botwaypoints.length(), botwayname);
			}
			else
				conoutf("botwaypoint file %s made with a %s version", botwayname, (version > BOTWPVERSION ? "newer" : "older"));
		}
		else
			conoutf("botwaypoint file %s is corrupt", botwayname);
	
		gzclose(f);
		return ans;
	}
	conoutf("could not load botwaypoint file %s", botwayname);
	
	return false;
}

bool botwaysave()
{
	execute("botdrop 0");
	conoutf("saving botway: %s", botwayname);
    gzFile f = gzopen(botwayname, "wb9");
    if(f)
	{
		char head[4];
		int version;

	    strncpy(head, "WAYP", 4);
		gzwrite(f, &head, 4);
		botputint(f, BOTWPVERSION);
					
		botputint(f, botwaypoints.length());

		loopv(botwaypoints)
		{
			botputint(f, (int)botwaypoints[i]->pos.x);
			botputint(f, (int)botwaypoints[i]->pos.y);
			botputint(f, (int)botwaypoints[i]->pos.z);
		}
		loopv(botwaypoints)
		{
			botputint(f, botwaypoints[i]->nodes.length());
			
			loopvj(botwaypoints[i]->nodes)
			{
				botputint(f, botwaypoints[i]->nodes[j]);
			}
		}
		
		conoutf("saved %d botwaypoint(s) to %s", botwaypoints.length(), botwayname);

		gzclose(f);
		return true;
	}
	conoutf("could not save botwaypoint file %s", botwayname);
	return false;
}
