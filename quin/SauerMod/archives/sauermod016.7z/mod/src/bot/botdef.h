// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// These are the defitions and constants for the bots.

#define BOTVERSION		1 								// bot version
#define BOTWPVERSION	1								// botwaypoint file format
#define BOTWPDIST		64.0f							// minimum distance between wapoints
#define BOTISNEAR		16.0f							// near a waypoint if this close
#define BOTDEBUG		1

#define BOTJUMPDIST		3.2f							// height of point before bot decides to jump
#define BOTJUMPMAX		18.0f							// points higher than this are considered too high
#define BOTRADIALDIST	48.0f							// TODO: avoind projectiles/radials
#define BOTLOSDIST(x)	(514.0f - (x * 2.0))			// line of sight distance = 512 MAX
#define BOTFOVX(x)		(96.5f - (x * 0.5))				// line of sight fov x angle = 96 MAX
#define BOTFOVY(x)		(128.5f - (x * 0.5))			// line of sight fov y angle = 128 MAX

#define BOTGAMEMODE(x)	(x>=0 && x<=12)					// available game modes

struct botway
{
	vec pos;
	vector<int> nodes;
};

