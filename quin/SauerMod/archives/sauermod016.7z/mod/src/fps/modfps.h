// SauerMod - MODGAME - Game Extensions by Quinton Reeves
// This is mostly stuff we need to hijack from the engine.

#define FONTH 64									// necessary emulation
#define MODHUDMAX ((h*3/FONTH)*FONTH)-(FONTH*5)		// max hud length

void gameplayhud(int w, int h)
{
    glLoadIdentity();
    glOrtho(0, w*900/h, 900, 0, -1, 1);
    if(player1->state!=CS_SPECTATOR)
    {
        draw_textf("%d",  90, 822, player1->state==CS_DEAD ? 0 : player1->health);
        if(player1->state!=CS_DEAD)
        {
            if(player1->armour) draw_textf("%d", 390, 822, player1->armour);
            draw_textf("%d", 690, 822, player1->ammo[player1->gunselect]);        
        };

        glLoadIdentity();
        glOrtho(0, w*1800/h, 1800, 0, -1, 1);

        glDisable(GL_BLEND);

        drawicon(192, 0, 20, 1650);
        if(player1->state!=CS_DEAD)
        {
            if(player1->armour) drawicon((float)(player1->armourtype*64), 0, 620, 1650);
            int g = player1->gunselect;
            int r = 64;
            if(g==GUN_PISTOL) { g = 4; r = 0; };
            drawicon((float)(g*64), (float)r, 1220, 1650);
        };
	}	
    if(m_capture) cpc.capturehud(w, h);
    md.modhud(w, h); // SauerMod
};

void fixcamerarange(physent *d)
{
    const float MAXPITCH = 90.0f;
    if(d->pitch>MAXPITCH) d->pitch = MAXPITCH;
    if(d->pitch<-MAXPITCH) d->pitch = -MAXPITCH;
    while(d->yaw<0.0f) d->yaw += 360.0f;
    while(d->yaw>=360.0f) d->yaw -= 360.0f;
};

void mousemove(int dx, int dy)
{
	if (player1->state != CS_DEAD)
	{
	    const float SENSF = 33.0f;     // try match quake sens
	    extern int sensitivity, sensitivityscale, invmouse;
	    
	    player1->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
	    player1->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
	    fixcamerarange(player1);
	}
};

physent fpscamera;

void recomputecamera()
{
	extern bool deathcam;
	extern int curtime, thirdperson, thirdpersondistance;
	extern physent *camera1;
	fpsent *target;
	int secs = time(NULL);

	camera1 = &fpscamera;
	
	if (camera1->type != ENT_CAMERA)
	{
		camera1->reset();
		camera1->type = ENT_CAMERA;
	}
	
	if (player1->state == CS_SPECTATOR)
	{
		if (md.cameracycle() > 0 && secs-md.cameracycled > md.cameracycle())
		{
			md.modcameradir(1); md.cameracycled = secs;
		}
		while (md.cameranum != player1->clientnum && !players.inrange(md.cameranum) && !players[md.cameranum]) md.modcameradir(1);
	
		if (players.inrange(md.cameranum) && md.cameranum != player1->clientnum)
		{
			target = players[md.cameranum];
		}
		else
		{
			target = player1;
		}
	}
	else
	{
		target = player1;
	}
	
	//if (target == player1)
	//{
		camera1->o = target->o;
		camera1->yaw = target->yaw;
		camera1->pitch = target->pitch;
	/*}
	else
	{ // lag compensation
		float bk = curtime * 0.25f;

		#define camloop(a,b,c) \
			if (a != b) { \
				if (a>b) { b += c; if (a<b) { b = a; } } \
				else if (a<b) { b -= c; if (a>b) { b = a; } } \
			}
			
		camera1->o = target->o;
	    //camloop(target->o.x,camera1->o.x,bk);
	    //camloop(target->o.y,camera1->o.y,bk);
	    //camloop(target->o.z,camera1->o.z,bk);
	    camloop(target->yaw,camera1->yaw,bk);
	    camloop(target->pitch,camera1->pitch,bk);
	}*/
	
	if (!editmode && (thirdperson || target != player1 || target->state == CS_DEAD))
	{
		// independant view rotation
		if (target != player1)
		{
			camera1->yaw += player1->yaw;
			camera1->pitch = player1->pitch;
		}
	    camera1->eyeheight = 2;
		camera1->move = -1;
	
	    fixcamerarange(camera1);
	    
	    loopi(10)
	    {
	        if(!moveplayer(camera1, 10, false, thirdpersondistance)) break;
	    };
	}
	else
	{
		camera1->move = 0;
		camera1->eyeheight = target->eyeheight;
		
	    fixcamerarange(camera1);
	}
};

void doquit()
{
	md.modwritecfg();
	md.bs.botwritecfg();
};

bool wantcrosshair() { return (md.crosshair() != 0); };

char *gamestartmap() { return "metl4"; }
