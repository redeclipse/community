// SauerMod - MODGAME - Game Extensions by Quinton Reeves
// Utility functions called from other locations and code insertions.

int cameranum, cameracycled;

void modrender()
{
	bs.botrender();
}

void modstart(const char *map)
{
	cameranum = -1;
	bs.botclear();
	bs.botstart(map);
}

void modwritecfg()
{
	FILE *f = fopen("mod/data/mod.cfg", "w");
	if(!f) return;
	fprintf(f, "// mod settings are saved here\n\n");
	fprintf(f, "scoreshud %d\n", scoreshud());
	fprintf(f, "crosshair %d\n", crosshair());
	fclose(f);
}

void modcameradir(int dir)
{
	loopi (256)
	{
		cameranum += dir;
		if (cameranum > cl.players.length()) cameranum = 0;
		else if (cameranum < 0) cameranum = cl.players.length();
		if (cameranum == cl.player1->clientnum || (cl.players.inrange(cameranum) && cl.players[cameranum])) return;
	}
	cameranum = -1;
}

struct sline { string s; };

struct teamscore
{
    char *team;
    int score;
    teamscore() {};
    teamscore(char *s, int n) : team(s), score(n) {};
};

static int mteamscorecmp(const teamscore *x, const teamscore *y)
{
    if(x->score > y->score) return -1;
    if(x->score < y->score) return 1;
    return 0;
};

static int mplayersort(const fpsent **a, const fpsent **b)
{
    return (int)((*a)->frags<(*b)->frags)*2-1;
};

void modhud(int w, int h)
{
	extern bool fullconsole;
	int gamemode = cl.gamemode;
	int x = FONTH/2, y = h*3-110-(FONTH*3), top = (fullconsole ? ((h*3/3/FONTH)*FONTH) : (5*FONTH)) + FONTH;

    glLoadIdentity();
    glOrtho(0, w*3, h*3, 0, -1, 1);
    glEnable(GL_BLEND);

	vector<fpsent *> shplayers;
	vector<teamscore> teamscores;
	
	loopi(cl.numdynents()) 
	{
	    fpsent *o = (fpsent *)cl.iterdynents(i);
	    if(o && o->type!=ENT_AI) shplayers.add(o);
	};
	
	shplayers.sort(mplayersort);

	if(m_teammode)
	{
	    if(m_capture)
	    {
	        loopv(cl.cpc.scores) if(cl.cpc.scores[i].total)
	            teamscores.add(teamscore(cl.cpc.scores[i].team, cl.cpc.scores[i].total));
	    }
	    else loopi(cl.numdynents()) 
	    {
	        fpsent *o = (fpsent *)cl.iterdynents(i);
	        if(o && o->type!=ENT_AI && o->frags)
	        {
	            teamscore *ts = NULL;
	            loopv(teamscores) if(!strcmp(teamscores[i].team, o->team)) { ts = &teamscores[i]; break; };
	            if(!ts) teamscores.add(teamscore(o->team, o->frags));
	            else ts->score += o->frags;
	        };
	    };
	    teamscores.sort(mteamscorecmp);
	};

	if (!editmode && scoreshud() && m_mp(gamemode))
	{
	    if(teamscores.length() && y > top)
	    {
	        loopvj(teamscores)
	        {
				const char *myteam = !strcmp(teamscores[j].team, cl.player1->team) ? "\f1" : "\f3";
				int score = j > 0 ? teamscores[j].score-teamscores[0].score : (teamscores.length() > j+1 ? teamscores[j].score-teamscores[j+1].score : 0);
		        draw_textf("%d\t%d\t%s%d%s\ff\t%s%s\ff", x, y, j+1, teamscores[j].score, score >= 0 ? "\f0[\f2+\ff" : "\f3[\ff", score, score >= 0 ? "\f0]\ff" : "\f3]\ff", myteam, teamscores[j].team); y -= FONTH;
		        if (y < top) break;
	        };
			if (y > top) y -= FONTH;
	    };
	    if(shplayers.length() && y > top)
	    {
			loopv(shplayers) 
			{
			    fpsent *o = shplayers[i];
				const char *myteam = (m_teammode ? !strcmp(o->team, cl.player1->team) : !strcmp(o->name, cl.player1->name)) ? "\f1" : "\f3";
				int score = i > 0 ? o->frags-shplayers[0]->frags : (shplayers.length() > i+1 ? o->frags-shplayers[i+1]->frags : 0);
		        draw_textf("%d\t%d\t%s%d%s\ff\t%s%s\ff\t%s%s\ff", x, y, i+1, m_capture ? cl.cpc.findscore(o->team).total : o->frags, score >= 0 ? "\f0[\f2+\ff" : "\f3[\ff", score, score >= 0 ? "\f0]\ff" : "\f3]\ff", myteam, o->team, cl.cc.currentmaster>= 0 && (cl.cc.currentmaster==o->clientnum) ? "\f0" : "\ff", o->name); y -= FONTH;
			    if (y < top) break;
			};
		}
	}
	x = FONTH/2;
	y = h*3-100-FONTH;
	
	if (cl.player1->state == CS_SPECTATOR)
	{
		fpsent *d;
		if (cameranum != cl.player1->clientnum && cl.players.inrange(cameranum) && (d = cl.players[cameranum]))
		{
			const char *myteam = (m_teammode ? !strcmp(d->team, cl.player1->team) : !strcmp(d->name, cl.player1->name)) ? "\f1" : "\f3";
			int score = m_capture ? (teamscores.length() ? cl.cpc.findscore(d->team).total-cl.cpc.findscore(teamscores[0].team).total : 0) : (shplayers.length() ? (d == shplayers[0] && shplayers.length() > 1 ? shplayers[0]->frags-shplayers[1]->frags : d->frags-shplayers[0]->frags) : 0);
			draw_textf("CAMERA %d", x, y, cameranum); y += FONTH;
	        draw_textf("%d\t%d\t%s%d%s\ff\t%s%s\ff\t%s%s\ff", x, y, d->clientnum, d->frags, score >= 0 ? "\f0[\f2+\ff" : "\f3[\ff", score, score >= 0 ? "\f0]\ff" : "\f3]\ff", myteam, d->team, cl.cc.currentmaster>= 0 && (cl.cc.currentmaster==d->clientnum) ? "\f0" : "\ff", d->name); y += FONTH;
		}
		else
		{
			y += FONTH;
			draw_textf("SPECTATOR MODE", x, y); y += FONTH;
		}
	}
}

