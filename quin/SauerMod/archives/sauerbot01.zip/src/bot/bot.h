// bot.h - Offline test and practice AI for the Sauerbraten Engine by Quinton Reeves.

struct botset
{
    fpsclient &cl;
    vector<extentity *> &ents;

	#define WAYPOINTVER		1 // bump if format changes
	#define WAYPOINTDIST	24.0f
	
	#define BOTJUMPDIST		3.0f
	#define BOTBACKDIST		64.0f

	#define BOTALLOWED		(m_mp(cl.gamemode) && !cl.cc.remote ? true : false)

	struct botway
	{
		vec pos;
		vector<int> nodes;
	};
	vector<botway *> waypoints;

    int bottotal, waylast;
    string wayname;
	
    botset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents), bottotal(0), waylast(-1)
	{
        CCOMMAND(botset, botadd, "ii", { int num = (args[0][0] ? atoi(args[0]) : -1); int ar = (args[1][0] ? atoi(args[1]) : -1); self->botadd(num, ar); });
        CCOMMAND(botset, botdel, "i", { int num = (args[0][0] ? atoi(args[0]) : -1); self->botdel(num); });
        CCOMMAND(botset, botload, "", { self->botwayload(); });
        CCOMMAND(botset, botsave, "", { self->botwaysave(); });
	};
    
    IVAR(botrate, 1, 10, 100);	// rate of action updates and judgement errors
    IVAR(botauto, 0, 1, 1);		// autmically load bots on start of map
    IVAR(botnum, 0, 0, 15);		// set to force a number of bots when automatically loading
    IVAR(botdrop, 0, 0, 1);		// drop waypoints during play (auto-set but toggleable)
    IVAR(botshow, 0, 0, 1);		// show bot debugging like waypoints

	void botnames(char *fname)
	{
	    string mapname;
	    if(strpbrk(fname, "/\\")) s_strcpy(mapname, fname);
	    else s_sprintf(mapname)("base/%s", fname);
	
	    s_sprintf(wayname)("packages/%s.wpz", mapname);
	    path(wayname);
	}

	void botadd(int num, int ar)
	{
        if (BOTALLOWED)
        {
			int n = (num >= 0 ? num : botnum()), s = (ar >= 0 ? ar : botrate());
			
			if (n == 0)
			{
				int r = 0;
				loopv(ents) if (ents[i]->type == PLAYERSTART)
				{
					r++;
				}
				n = max(r >= 8 ? r - (r / 3) : r - 2, 2);
				
			}
			
			if (n <= 0)
				return;

	        while (n > 0 && bottotal < 16)
            {
               	fpsent *bot = cl.getclient(bottotal);
           		bottotal++;

		        s_sprintf(bot->name)("bot_%02d", bottotal);
		        if (bottotal%2)
		        {
		        	s_sprintf(bot->team)("red");
				}
				else
				{
		        	s_sprintf(bot->team)("blue");
				}
		        bot->move = bot->strafe = 0;
			
              	cl.spawnstate(bot);

				bot->botrate = (s < 1 ? 1 : (s > 100 ? 100 : s));

				bottrans(bot, M_SLEEP, 0, bottotal);

		        conoutf("connected: %s (team: %s, rate: %d)", bot->name, bot->team, bot->botrate);

               	n--;
			}
		}
		else
			conoutf("addbot is only available in offline multiplayer games");
	}

	void botdel(int num)
	{
        if (BOTALLOWED)
        {
			if (cl.players.length() <= 0) return;

			int n = (num >= 0 ? num : 1);
			
			if (n == 0 || n > cl.players.length())
			{
				n = cl.players.length();
			}	
			
			int x = cl.players.length()-1;
	        while (x >= 0 && n > 0 && cl.players.length() > 0) 
			{
				if (cl.players[x]->botstate != M_NONE)
            	{
					fpsent *bot = cl.players[x];

            		conoutf("bot %s disconnected", bot->name);

            		cl.players.remove(x);
            		DELETEP(bot);
	                cleardynentcache();
					n--;
            		bottotal--;
				}
				x--;
			}
		}
		else
			conoutf("delbot is only available in offline multiplayer games");
	}

    void botthink(fpsent *bot, int curtime, int gamemode)
    {
        if(cl.intermission) return;

		if(bot->state==CS_SPECTATOR || bot->state==CS_EDITING)
		{
			bot->state = CS_DEAD;
			bottrans(bot, M_SLEEP, 0, 10);
		}
        
       	botaction(bot, curtime);

        if(bot->state==CS_ALIVE)
        {
			float bk = curtime * (1.01f - (bot->botrate * 0.01f));
			
			if (bot->botstate!=M_SEARCH)
				botvector(bot); // recalc bot vector

		    if(bot->botrot.y>bot->yaw)             // slowly turn bot towards his target
            {
                bot->yaw += bk;
                if(bot->botrot.y<bot->yaw) bot->yaw = bot->botrot.y;
            }
            else
            {
                bot->yaw -= bk;
                if(bot->botrot.y>bot->yaw) bot->yaw = bot->botrot.y;
            }

	        cl.et.checkquad(bot, curtime);
        	cl.et.checkitems(bot);

			botmove(bot, 2, true); // main update
        }
        else
        {
            bot->move = bot->strafe = 0;

            if(cl.lastmillis-bot->lastaction<2000)
            {
				botmove(bot, 2, false);
            }
        }
		bot->lastupdate = cl.lastmillis;
    };

    bool inlos(vec &o, vec &q, vec &v)
    {
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
        return distance >= mag; 
    };
    
    void hitvec(vec &o, vec &q, vec &v)
    {
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
    };

    void bottrans(fpsent *bot, int st, int mv, int n)
    {
        bot->move = mv;
		int q = rnd(n * bot->botrate), v = n + q;
    	bot->botstate = st;
    	bot->botms = cl.lastmillis + v;
    	//conoutf ("%s transition to %d (%d)", bot->name, bot->botstate, v);
    };

	void botvector(fpsent *bot)
	{
		bot->botrot.y = -(float)atan2(bot->botvec.x - bot->o.x, bot->botvec.y - bot->o.y)/PI*180+180;
        if(bot->yaw<bot->botrot.y-180.0f) bot->yaw += 360.0f;
        if(bot->yaw>bot->botrot.y+180.0f) bot->yaw -= 360.0f;
	    float dist = bot->botvec.dist(bot->o);
		bot->botrot.x = bot->pitch = asin((bot->botvec.z - bot->o.z) / dist) / RAD; 
	}

	void bothome(fpsent *bot, vec &v, bool trans)
	{
		//conoutf ("%s homing vector %f,%f,%f", bot->name, v.x, v.y, v.z);
		bot->botvec = vec (v.x, v.y, v.z);
		
		botvector(bot);
		
		if (trans)
		{
			bot->botstart = cl.lastmillis;
			bottrans(bot, M_HOME, 1, 5);
		}
	}
	
	bool botenemy(fpsent *bot, fpsent *p)
	{
		if ((p) && (bot!=p) && (p->state==CS_ALIVE))
		{
			vec target;

			//conoutf ("%s making enemy of %s", bot->name, p->name);

			if (inlos(bot->o, p->o, target))
			{
				bothome(bot, target, false);
				bottrans(bot, M_AIMING, (target.dist(bot->o) > BOTBACKDIST ? 1 : -1), 20);

				//conoutf ("%s aiming at %s", bot->name, p->name);
				
				return true;
			}
		}
		return false;
	}

	bool bottarget(fpsent *bot)
	{
		vec target;
		float dist[3], c;
		int a = -1, b, lvl = -1, targ[3], amt[3];

		//conoutf ("%s looking for target", bot->name);
		
		#define inittarg(n) \
					lvl++; \
					dist[lvl] = 99999.f; \
					targ[lvl] = -1; \
					amt[lvl] = n; \
					conoutf("%s target level %d amt %d", bot->name, lvl, n);

		#define disttarg(q,r) \
					if (inlos(bot->o, q, target) && q.dist(bot->o) < dist[lvl] && q.dist(bot->o) > bot->radius*2) \
					{ \
						dist[lvl] = q.dist(bot->o); \
						targ[lvl] = r; \
					}

		inittarg(1); // 0
		if (cl.player1->state==CS_ALIVE && bot!=cl.player1)
		{
			disttarg(cl.player1->o,0);
		}

		inittarg(cl.players.length()); // 1
		loopv(cl.players)
		{
			if (cl.players[i]->state==CS_ALIVE && bot!=cl.players[i])
			{
				disttarg(cl.players[i]->o,i);
			}
		}

		inittarg(cl.ms.monsters.length()); // 2
		loopv(cl.ms.monsters)
		{
			if (cl.ms.monsters[i]->state==CS_ALIVE)
			{
				disttarg(cl.ms.monsters[i]->o,i);
			}
		}
		
		for (lvl = 0, c = 99999.f; lvl <= 2; lvl++)
		{
			if ((targ[lvl] >= 0) && (targ[lvl] < amt[lvl]) && (dist[lvl] > bot->radius*2) && (dist[lvl] < c))
			{
				a = lvl;
				c = dist[lvl];
			}
		}

		if ((a >= 0) && (a <= 2))
		{
			b = targ[a];
			
			//conoutf ("%s target %d (%d/%d) selected [%f].", bot->name, a, b, amt[a], dist[a]);
			
			switch (a)
			{
				case 0:
					{
						return botenemy(bot, cl.player1);
						break;
					}
				case 1:
					{
						return botenemy(bot, cl.players[b]);
						break;
					}
				case 2:
					{
						return botenemy(bot, cl.ms.monsters[b]);
						break;
					}
				default:
					break;
			}
		}
		else
		{
			//conoutf ("%s got no target", bot->name);
		}
		return false;
	}

	void botspawn(fpsent *bot)
	{
		if (bot->state!=CS_ALIVE)
		{
	        bot->botvec = vec(0, 0, 0);
	        bot->botcurnode = bot->botlastnode = -1;
			//conoutf ("%s is now spawning", bot->name);
			cl.spawnplayer(bot);
		}
	    bottrans(bot, M_SEARCH, 1, 100);
	}


	void botaim(fpsent *bot)
	{
		if (bot->yaw == bot->botrot.y)
		{
			//conoutf ("%s aimed at %f,%f,%f", bot->name, bot->botvec.x, bot->botvec.y, bot->botvec.z);
        	bottrans(bot, M_ATTACKING, (bot->botvec.dist(bot->o) > BOTBACKDIST ? 1 : -1), 5); // that's it, we're committed
		}
	}

	void botattack(fpsent *bot)
	{
		vec target;
		//conoutf ("%s is attacking %f,%f,%f", bot->name, bot->botvec.x, bot->botvec.y, bot->botvec.z);
		hitvec(bot->o, bot->botvec, target);
        bot->lastaction = 0;
        bot->attacking = true;
        cl.ws.shoot(bot, target);
        bot->attacking = false;
		bothome(bot, target, false);
	    bottrans(bot, M_SEARCH, (target.dist(bot->o) > BOTBACKDIST ? 1 : -1), 20);
	    bot->botms = bot->botms + bot->gunwait;
	}

	void botmove(fpsent *bot, int n, bool d)
	{
		if(bot->move || bot->strafe)
		{
			//bot->type = ENT_AI; // fool the physics routines
			moveplayer(bot, n, d); // using physics to move and detect
			//bot->type = ENT_PLAYER; // so we're normal again
		}
	}

	void botwaypoint(int x, int y, int z, bool node)
	{
		botway *e = new botway;

		e->pos = vec(x, y, z);
		e->nodes.setsize(0);
		
		waypoints.add(e);

		if (node)
		{
			int n = waypoints.length()-1;
			
			if (waypoints.inrange(n))
			{
				if (waypoints.inrange(waylast))
					botwaynodeadd(waylast, n);
				waylast = n;
			}
		}

		//conoutf ("waypoint placed at %f,%f,%f", e->pos.x, e->pos.y, e->pos.z);
	}

	bool botwayconnect (int a, int b)
	{
		if (a != b && waypoints.inrange(a) && waypoints.inrange(b))
		{
			loopv(waypoints[a]->nodes)
			{
				if (waypoints[a]->nodes[i] == b)
					return true;
			};
		}
		return false;
	}
	
	void botwaynodes()
	{
		execute("botdrop 1");
		
    	loopv(cl.et.ents)
    	{
			int t = cl.et.ents[i]->type;
			
			if ((t >= I_SHELLS && t <= TELEPORT) || t == JUMPPAD || t == BASE)
				botwaypoint((int)cl.et.ents[i]->o.x, (int)cl.et.ents[i]->o.y, (int)cl.et.ents[i]->o.z, false);
		}
		conoutf ("generated %d waypoint(s) without nodes from %d ent(s)", waypoints.length(), cl.et.ents.length());
	}

	void botwayclear()
	{
		loopv(waypoints)
		{
			loopvj(waypoints[i]->nodes)
			{
				waypoints[i]->nodes.remove(j);
			}
			waypoints[i]->nodes.setsize(0);
			DELETEP(waypoints[i]);
		}
		waypoints.setsize(0);
	}

	int botwaycurnode(fpsent *bot, bool any)
	{
		int lowest = -1;
		loopv(waypoints)
		{
			if ((any || waypoints[i]->pos.dist(bot->o) < WAYPOINTDIST) && (!waypoints.inrange(lowest) || waypoints[i]->pos.dist(bot->o) < waypoints[lowest]->pos.dist(bot->o)))
			{
				lowest = i;
			}
		}
		return lowest;
	}

	int botwaynodeadd(int n, int m)
	{
		if (waypoints.inrange(n) && waypoints.inrange(m))
		{
			vec target;
			if (n != m && !botwayconnect(n, m) && inlos (waypoints[n]->pos, waypoints[m]->pos, target))
			{
				waypoints[n]->nodes.add(m);
				//conoutf("waypoint node %d connected with %d", n, m);
			}
		}
	}

	int botgetint(gzFile f)
	{
		int t;
	    gzread(f, &t, sizeof(int));
        endianswap(&t, sizeof(int), 1);
        return t;
	}
	
	void botputint(gzFile f, int x)
	{
		int t = (int)x;
       	endianswap(&t, sizeof(int), 1);
	   	gzwrite(f, &t, sizeof(int));
	}

	bool botwayload()
	{
	    gzFile f = gzopen(wayname, "rb9");
	    if(f)
		{
			bool ans = false;
	
			char head[4];
			int version;
	
		    gzread(f, &head, 4);
		    version = botgetint(f);
		    			
			if (!strncmp(head, "WAYP", 4) && version <= WAYPOINTVER)
			{
				int ways, x, y, z;
				
				ways = botgetint(f); // number of waypoints
				
				loopi(ways) // load waypoint positions
				{
					x = botgetint(f);
					y = botgetint(f);
					z = botgetint(f);
					botwaypoint(x, y, z, false);
				}					
				
				loopi(ways) // load waypoint node connections
				{
					x = botgetint(f); // number of nodes
					
					loopj(x)
					{
						y = botgetint(f); // node waypoint number

						waypoints[i]->nodes.add(y);
					}
				}
				ans = true;
				conoutf("loaded %d waypoint(s) from %s", waypoints.length(), wayname);
			}
			gzclose(f);
			return ans;
		}
		conoutf("could not load waypoint file %s", wayname);
		
		return false;
	}

	bool botwaysave()
	{
	    gzFile f = gzopen(wayname, "wb9");
	    if(f)
		{
			char head[4];
			int version;
	
		    strncpy(head, "WAYP", 4);
			gzwrite(f, &head, 4);
			botputint(f, WAYPOINTVER);
						
			botputint(f, waypoints.length());

			loopv(waypoints)
			{
				botputint(f, waypoints[i]->pos.x);
				botputint(f, waypoints[i]->pos.y);
				botputint(f, waypoints[i]->pos.z);
			}
			loopv(waypoints)
			{
				botputint(f, waypoints[i]->nodes.length());
				
				loopvj(waypoints[i]->nodes)
				{
					botputint(f, waypoints[i]->nodes[j]);
				}
			}
			
			conoutf("saved %d waypoint(s) to %s", waypoints.length(), wayname);

			gzclose(f);
			return true;
		}
		conoutf("could not save waypoint file %s", wayname);
		return false;
	}

	bool botcoord(fpsent *bot, int retry)
	{
		int c = botwaycurnode(bot, retry), r = -1;
		
		//conoutf("%s looking for waypoint", bot->name);
		
		if (waypoints.inrange(c))
		{
			//conoutf("%s is in node %d", bot->name, c);

			if (waypoints[c]->nodes.length() > 1)
			{
				int n = rnd(waypoints[c]->nodes.length());
		
				if (waypoints[c]->nodes.inrange(n) && n != bot->botcurnode && n != bot->botlastnode)
					r = waypoints[c]->nodes[n];
				else
					r = waypoints[c]->nodes[0];
			}
			else if (waypoints[c]->nodes.length() > 0)
			{
				r = waypoints[c]->nodes[0];
			}
		}

		if (waypoints.inrange(r))
		{
			bot->botlastnode = bot->botcurnode;
			bot->botcurnode = r;
			//conoutf("%s attempting home on %d", bot->name, r);
			bothome(bot, waypoints[r]->pos, true);
			return true;
		}
		else if (!retry)
			return botcoord(bot, true);

		return false;
	}

    void botaction(fpsent *bot, int curtime)           // main AI thinking routine, called every frame for every ai
    {
		if(bot->botms<cl.lastmillis)
        {
			//conoutf ("%s doing action %d", bot->name, bot->botstate);

    		switch(bot->botstate)
    		{
				case M_SLEEP:
            		{
						botspawn(bot);
					}
					break;

        		case M_SEARCH:
					{
       		        	if (bot->state==CS_ALIVE)
							if (!bottarget(bot))
								if (!botcoord(bot, false))
								    bottrans(bot, M_SEARCH, 1, 20);
					}
					break;

				case M_HOME:
					{
       		        	if (bot->state==CS_ALIVE)
       		        	{
							if (!bottarget(bot))
							{
								if (bot->botvec.dist(bot->o) < WAYPOINTDIST)
								{
								    bottrans(bot, M_SEARCH, 1, 1);
								}
								else if (cl.lastmillis-bot->botstart > bot->botrate*100)
								{
								    bottrans(bot, M_SEARCH, 1, 10);
								}
								else
								{
									if (bot->botvec.z-bot->o.z > BOTJUMPDIST)
										bot->jumpnext = true;

									bottrans(bot, M_HOME, 1, 5);
								}
							}
						}
					}
					break;

        		case M_AIMING:
					{
      		        	if (bot->state==CS_ALIVE)
							botaim(bot);
					}
					break;
        
                case M_ATTACKING:
					{
       		        	if (bot->state==CS_ALIVE)
							botattack(bot);
					}
					break;
				default:
					break;
            };
		}
    };

	void botwaypos()
	{
        if (BOTALLOWED)
        {
			if (cl.player1->state == CS_ALIVE)
			{
				if (botdrop())
				{
					bool inode = false;
					
					loopv(waypoints)
					{
						if (waypoints[i]->pos.dist(cl.player1->o) < WAYPOINTDIST)
						{
							if (i != waylast)
							{
								if (waypoints.inrange(waylast))
									botwaynodeadd(waylast, i);
									
								waylast = i;
							}
							inode = true;
						}
					}
					if (!inode)
						botwaypoint((int)cl.player1->o.x, (int)cl.player1->o.y, (int)cl.player1->o.z, true);
				}
			}
			else
				waylast = -1;
		}
	};

	void botclear()
	{
        if (BOTALLOWED)
        {
			loopv(cl.players)
	      		DELETEP(cl.players[i]);
	
			cl.players.setsize(0);
			cleardynentcache();
	
	        bottotal = 0;
	        
			botwayclear();
	
			execute("botdrop 0");
		}
	}

	void botstart(char *map, int gamemode)
	{
        if (BOTALLOWED)
        {
	        if (*map) // otherwise we may be editing..
	        {
				botnames(map);
				
				if (!botwayload())
					botwaynodes();

				if (botauto())
    	    		botadd(-1, -1);
			}
		}
	}

	void bottime()
	{
		// um..
	}

	void botrender()
	{
		if (cl.player1->state == CS_EDITING || botshow())
		{
			loopv(waypoints)
			{
				vec target;
				
				if (inlos (cl.player1->o, waypoints[i]->pos, target))
				{
					string wp;
			        
		    	    particle_splash(0, 2, 50, waypoints[i]->pos);
	
					s_sprintf(wp)("@waypoint (%d)", i);
	    	        particle_text(waypoints[i]->pos, wp, 14, 1);
	
					loopvj(waypoints[i]->nodes)
					{
						int y = waypoints[i]->nodes[j];
						
						if (waypoints.inrange(y))
							particle_flare(waypoints[i]->pos, waypoints[y]->pos, 1);
					}
				}
			}
		}
	}
};

