These files were originally made for SauerMod by John "geartrooper" Siar.
They are free to use as you wish so long as you give credit to the author.
