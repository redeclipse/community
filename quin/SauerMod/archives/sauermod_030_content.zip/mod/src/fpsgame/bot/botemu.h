// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// This is msotly parts of the engine that need emulating, hijacked from the engine.

/*
// entities
void botteleport(int n, fpsent *d)	 // also used by monsters
{
	if (isbot(d))
	{
		int e = -1, tag = cl.et.ents[n]->attr1, beenhere = -1;
		for(;;)
		{
			e = findentity(TELEDEST, e+1);
			if(e==beenhere || e<0) { conoutf("no teleport destination for tag %d", tag); return; }
			if(beenhere<0) beenhere = e;
			if(cl.et.ents[e]->attr2==tag)
			{
				d->o = cl.et.ents[e]->o;
				d->yaw = cl.et.ents[e]->attr1;
				d->pitch = 0;
				d->vel = vec(0, 0, 0);//vec(cosf(RAD*(d->yaw-90)), sinf(RAD*(d->yaw-90)), 0);
				entinmap(d);
				playsound(S_TELEPORT, &d->o);
				botstop(d);
				break;
			}
		}
	}
}

// these functions are called when the client touches the item
void botpickup(int n, fpsent *d)
{
	if (isbot(d))
	{
		switch(cl.et.ents[n]->type)
		{
			default:
			{
				if(d->canpickup(ents[n]->type))
				{
					cl.et.pickupeffects(n, d, true);

					if (cl.md.cs->sents.inrange(n))
					{
						cl.md.cs->sents[n].spawned = false;
						cl.md.cs->sents[n].spawntime = cl.md.cs->spawntime(cl.md.cs->sents[n].type);
					}
				}
				break;
			}

			case TELEPORT:
			{
				botteleport(n, d);
				break;
			}
	
			case JUMPPAD:
			{
				vec v((int)(char)cl.et.ents[n]->attr3*10.0f, (int)(char)cl.et.ents[n]->attr2*10.0f, cl.et.ents[n]->attr1*12.5f);
				d->timeinair = 0;
				d->gravity = vec(0, 0, 0);
				d->vel = v;
				playsound(S_JUMPPAD, &d->o);
				break;
			}
		}
	}
}

void botitems(fpsent *d)
{
	if (isbot(d))
	{
		itemstats[I_HEALTH-I_SHELLS].max = d->maxhealth;
		vec o = d->o;
		o.z -= d->eyeheight;
		loopv(cl.et.ents)
		{
			extentity &e = *cl.et.ents[i];
			if(e.type==NOTUSED) continue;
			if(!e.spawned && e.type!=TELEPORT && e.type!=JUMPPAD && e.type!=RESPAWNPOINT) continue;
			float dist = e.o.dist(o);
			if(dist<(e.type==TELEPORT ? 16 : 12)) botpickup(i, d);
		}
	}
}

void botquad(fpsent *d)
{
	if (isbot(d))
	{
		extern int curtime;
		if (d->quadmillis && (d->quadmillis -= curtime) <= 0)
		{
			d->quadmillis = 0;
			playsound(S_PUPOUT, &d->o);
		}
	}
}
*/
