// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// These are hooks for the console/script commands to manage the bots and their waypoints.

void botstart()
{
	setvar("botnum", 0);
	setvar("botdrop", 0);
	botavoid.setsize(0);
	botwaypoints = 0;

	loopv(cl.et.ents) if (cl.et.ents[i]->type == WAYPOINT) botwaypoints++;

	if (!botwaypoints)
	{
		conoutf("WARNING: map has no waypoints, generating them, save with /entsave");
		setvar("botdrop", 1);
		botwayspawn();
	}
	botadd(-1, -1); // auto add or delete
}

bool botplayers(int time)
{ 
	if (!cl.intermission)
	{
		botavoid.setsize(0);
	
		botwayposition(cl.player1);
	
		loopv(cl.players)
		{ 
			if (cl.players[i]) botwayposition(cl.players[i]);
		}
	
		loopv(cl.ms.monsters)
		{ 
			if (cl.ms.monsters[i]) botwayposition(cl.ms.monsters[i]);
		}

#ifdef BOTPLAYER
		if (botplayer)
		{
			if (!isbot(cl.player1))
			{
				botreset(cl.player1);
				cl.player1->botstate = M_SLEEP;
				cl.player1->botflags = BOT_PLAYER|BOT_CONTROL;
				cl.player1->botupdate = cl.player1->botrate = botrate;
			}
			botthink(time, cl.player1);
		}
		else if (isbot(cl.player1))
		{
			botreset(cl.player1);
			cl.player1->botstate = M_NONE;
			cl.player1->botflags = 0;
		}
#endif
	
		loopv(cl.players) // state of other 'clients'
		{ 
			if (cl.players[i] && isbot(cl.players[i])) botthink(time, cl.players[i]);
		}
	
		if (botmonster)
		{ 
			loopv(cl.ms.monsters) // state of other 'clients'
			{ 
				if (cl.ms.monsters[i] && isbot(cl.ms.monsters[i])) botthink(time, cl.ms.monsters[i]);
			}
		}
	}
	else if (!botwaypoints && botdrop) // make sure our new waypoints are saved!
	{
		cl.ex.extentsave();
		botwaypoints++; // hacky, i know
	}
	return !multiplayer(false);
}

void botadd(int num, int ar)
{ 
	if (!multiplayer(false))
	{
		int gamemode = cl.gamemode;

		if (BOTGAMEMODE(gamemode) && (num > 0 || botauto))
		{
			int n = (num > 0 ? num : botnum), s = (ar >= 0 ? ar : botrate);
			
			if (m_classicsp) n = 1;
			else if (n <= 0)
			{
				int r = 1;
				loopv(ents) if (ents[i]->type == PLAYERSTART) r++;
				n = (r / 5) * 2;
			}
			
			if (m_teammode && num <= 0 && (n + botcount) % 2 == 0) n++;
			if (num <= 0) n -= botcount;
			if (n > 0)
			{
				while (n > 0 && botcount < BOTMAX)
				{
					botcount++; // doubles as clientnum, just treat bots as a stack
					fpsent *d = cl.newclient(botcount);
	
					if (d)
					{
						string botname;
	
						d->move = d->strafe = 0;
						//cl.spawnstate(d);
	
						botreset(d);
						d->botflags = BOT_PLAYER;
						d->state = CS_DEAD;
						d->botrate = (s < 1 ? 1 : (s > 100 ? 100 : s));
	
						s_sprintf(botname)("bot_%02d", d->clientnum);
						s_strcpy(d->name, botname);
						s_sprintf(botname)("%s", (d->clientnum % 2 ? "evil" : "good"));
						s_strcpy(d->team, botname);
	
						extern void localconnectn();
						localconnectn();
						if (cl.md.cs->clients.inrange(d->clientnum))
						{
							fpsserver::clientinfo *c = cl.md.cs->clients[d->clientnum];
							s_strncpy(c->name, d->name, MAXNAMELEN + 1);
							s_strncpy(c->team, d->team, MAXTEAMLEN + 1);
							c->state.frags = 0;
							c->clientnum = d->clientnum;
							c->local = true;
						}
						//if(m_capture) cl.md.cs->cps.changeteam(d->team, d->team, d->o);
	
						conoutf("connected: %s", &d->name);
	
						bottrans(d, M_PAIN, 0, 0, true, botcount*300);
						n--;
					}
					else
						fatal("cannot get bot entity");
				}
				cleardynentcache();
			}
			else if (n < 0 && num <= 0)
			{
				botdel(-n);
			}
		}
		else if (num <= 0) botdel(0);
		else conoutf("ERROR: bots are not available in this game mode");
	}
	else if (num <= 0) botdel(0);
	else conoutf("ERROR: bots are only available in active offline games");
}

void botaimonster(fpsent *d, int rate, int state, int health)
{
	botreset(d);

	d->botrate = rate;

	while (d->botrate > 100) d->botrate = d->botrate / 10;
	if (d->botrate < 1) d->botrate = 1;

	d->health = d->maxhealth = health;
	d->botflags = BOT_MONSTER;
	d->botstate = state;
	s_strcpy(d->team, "monster");
}

void bottrancemonster(fpsent *d, fpsent *e)
{ 
	botreset(d);
	d->botflags |= BOT_TRANCE;
	d->botstate = M_SLEEP;
	d->botupdate = d->botrate;
	cl.ms.monsterkilled();
}

void botdel(int num)
{ 
	if (cl.players.length() <= 1)
		return ;

	//int gamemode = cl.gamemode;
	int n = (num >= 0 ? num : 1);

	if (n == 0 || !cl.players.inrange(n))
	{
		n = cl.players.length() - 1;
	}

	int x = cl.players.length() - 1;

	while (x >= 0 && n > 0 && cl.players.length() > 1)
	{
		if (cl.players.inrange(x) && isbot(cl.players[x]))
		{
			fpsent *d = cl.players[x];

			//if(m_capture && d->state==CS_ALIVE) cl.md.cs->cps.leavebases(d->team, d->o);

			if (cl.md.cs->clients.inrange(d->clientnum))
			{
				fpsserver::clientinfo *c = cl.md.cs->clients[d->clientnum];
				if (c)
				{
					extern void localdisconnectn(int i);
					localdisconnectn(d->clientnum);
					cl.md.cs->clients.removeobj(c);
				}
			}

			conoutf("player %s disconnected", &d->name);

			DELETEP(cl.players[x]);
			cleardynentcache();
			n--;
			botcount--;
		}
		x--;
	}
}
