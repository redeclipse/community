// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/fps.cpp
// This is the primary bot hook for fpsgame called by modgame.

struct botset
{
	fpsclient &cl;
	vector<extentity *> &ents;
	
	vector<int> botavoid;
	
	#include "botutl.h"							// utilities
	#include "botmgr.h"							// management
	#include "botway.h"							// botwaypoints and nodes
	#include "botai.h"							// artificial intelligence
	
	botset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents)
	{
		CCOMMAND(botset, botadd, "ss",
				 {
					 int num = (args[0][0] ? atoi(args[0]) : -1);
					 int ar = (args[1][0] ? atoi(args[1]) : -1);
					 self->botadd(num, ar);
				 }
				);
		CCOMMAND(botset, botdel, "s",
				 {
					 int num = (args[0][0] ? atoi(args[0]) : -1);
					 self->botdel(num);
				 }
				);
	}
};

botset bs;

