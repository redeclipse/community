// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/game.h
// These are the extra fpsent variables the bots use.
// TODO: Transfer bot specific stuff to fpsent subclass `botent'.

int botrate, botupdate, botcheck, bottrance, botjump;
int botflags, botstate, bottarg, botnode;
vec botpos, botrot, botvec;
fpsent *botenemy;
vector<int> botroute;//, bothist;
