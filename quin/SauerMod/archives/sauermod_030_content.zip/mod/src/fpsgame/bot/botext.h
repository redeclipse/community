// SauerMod - BOT - Offline test and practice AI by Quinton Reeves
// Included by: fpsgame/bot/bot.h
// These are the definitions and constants for the bots.

#define BOTVERSION		1 								// bot version
#define BOTMAX			MAXCLIENTS-1					// max bots
#define BOTPLAYER

#define BOTLOSDIST(x)	(514.0f - (x * 2.0))			// line of sight distance = 512 MAX
#define BOTFOVX(x)		(96.5f - (x * 0.5))				// line of sight fov x angle = 96 MAX
#define BOTFOVY(x)		(128.5f - (x * 0.5))			// line of sight fov y angle = 128 MAX

#define BOTGAMEMODE(x)	(x >= -2 && x <= 11)			// available game modes

#define PATH_ABS		0x0001
#define PATH_AVOID		0x0002
#define PATH_GTONE		0x0004

#define BOT_PLAYER		0x0001
#define BOT_MONSTER		0x0002

#define BOT_CONTROL		0x0004
#define BOT_TRANCE		0x0008

#define BOTISNEAR		8					// is near
#define BOTISFAR		96					// too far
#define BOTJUMPDIST		6					// decides to jump
#define BOTJUMPWEAP		24					// weapon to jump
#define BOTJUMPMAX		32					// too high
#define BOTRADIALDIST	48					// radial distance
#define BOTMELEEDIST	12					// use melee
#define BOTCHECKKILL	7500				// check this interval for suicide
#define BOTCHECKCOORD	5000				// check this interval for coordindates
#define BOTJUMPTIME		100					// don't jump too soon
#define BOTJUMPWAIT		1000				// don't jump stupidly
#define BOTTRANCETIME	30000				// sp 'trance' spell
#define BOTSCOUTDIST	20					// scout this many nodes randomly

int botcount = 0, botwaypoints = 0;

VARP(botrate, 1, 10, 100);					// rate of action updates and judgement errors
VARP(botauto, 0, 0, 1);						// automically load bots on start of map
VARP(botmonster, 0, 1, 1);					// monsters use bot logic

#ifdef BOTPLAYER
VAR(botplayer, 0, 0, 1);					// player uses bot logic
#endif

VAR(botdrop, 0, 0, 1);						// drop botwaypoints during play
VAR(botnum, 0, 0, MAXCLIENTS-1);			// set to force a number of bots in botauto
VAR(botwaydist, 0, BOTJUMPMAX, BOTISFAR);	// drop botwaypoints this far apart
VAR(botwaynear, 0, BOTISNEAR, BOTISFAR);	// waypoints join when this close to them
