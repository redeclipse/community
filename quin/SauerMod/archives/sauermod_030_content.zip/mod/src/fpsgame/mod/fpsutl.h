// SauerMod - FPSMODGAME - Game Extensions by Quinton Reeves
// Utility functions called from other locations and code insertions.

struct sline
{
	string s;
};
struct teamscore
{
	char *team;
	int score;
	teamscore()
	{}
	teamscore(char *s, int n) : team(s), score(n)
	{}
}
;

void render()
{
	cl.ex.extentrender();
	bs.botrender();
}

void names(const char *fname)
{
	string mapname;
	if(strpbrk(fname, "/\\"))
		s_strcpy(mapname, fname);
	else
		s_sprintf(mapname)("%s/%s", cl.gamepakdir(), fname);
		
	s_sprintf(cfgname)("packages/%s.fmc", mapname);
	path(cfgname);
}

void start(const char *map)
{
	cameranum = 0;
	starttime = cl.lastmillis;
	
	if (*map)
	{
		names(map);
		execfile(cfgname);
	}
	else
	{
		cfgname[0] = 0;
	}

  	bs.botstart();
}

void cameradir(int dir, bool quiet = false)
{
	int cams = 0, cam_lo = 0, cam_hi = 0;
	
	cam_lo = cl.players.length();
	
	loopv(cl.et.ents) if (cl.et.ents[i]->type == CAMERA) cam_hi++;
	
	cams = cam_lo + cam_hi;
	
	while (true)
	{
		cameranum += dir;

		while (cameranum < -cam_lo) cameranum += cams;
		while (cameranum > cam_hi) cameranum -= cams;
		
		if (cameranum > 0 || cl.player1->clientnum == -cameranum ||
			(cl.players.inrange(-cameranum) && cl.players[-cameranum])) break;
	}
	if (!quiet)
	{
		if (cameranum > 0) console("camera %d selected", CON_LEFT|CON_CENTER, cameranum);
		else if (cl.player1->clientnum == -cameranum) console("spectator camera selected", CON_LEFT|CON_CENTER);
		else console("chasecam %s selected", CON_LEFT|CON_CENTER, cl.players[-cameranum]->name);
	}
}

void setcamera(int idx)
{
	if (idx>=0)
	{
		if ((cl.player1->state == CS_SPECTATOR) || (cl.player1->state == CS_EDITING))
		{
			int foo_delta; // we will ignore the delta attribute (it's for AwayCAM (still to come))
			cl.ex.gotocamera(idx, cl.player1, foo_delta);
			lastcam = idx;
		}
		else
		{
			conoutf ("need to be editing or spectator");
		}
	}
	else
	{
		lastcam = -1;
	}
}

static int mteamscorecmp(const teamscore *x, const teamscore *y)
{
	if(x->score > y->score)
		return -1;
	if(x->score < y->score)
		return 1;
	return 0;
}

static int mplayersort(const fpsent **a, const fpsent **b)
{
	return (int)((*a)->frags<(*b)->frags)*2-1;
}

void calcranks()
{
	bool hold = false;
	int gamemode = cl.gamemode;
	
	if(shplayers.length())
		shplayers.setsize(0);
	loopi(cl.numdynents())
	{
		fpsent *o = (fpsent *)cl.iterdynents(i);
		if(o && (!multiplayer(false) || o->type!=ENT_AI))
			shplayers.add(o);
	}
	
	shplayers.sort(mplayersort);
	
	if(teamscores.length())
		teamscores.setsize(0);
		
	if(m_teammode)
	{
		if(m_capture)
		{
			loopv(cl.cpc.scores) if(cl.cpc.scores[i].total)
				teamscores.add(teamscore(cl.cpc.scores[i].team, cl.cpc.scores[i].total));
		}
		else
			loopi(cl.numdynents())
		{
			fpsent *o = (fpsent *)cl.iterdynents(i);
			if(o && o->type!=ENT_AI && o->frags)
			{
				teamscore *ts = NULL;
				loopv(teamscores) if(!strcmp(teamscores[i].team, o->team))
				{
					ts = &teamscores[i];
					break;
				}
				if(!ts)
					teamscores.add(teamscore(o->team, o->frags));
				else
					ts->score += o->frags;
			}
		}
		teamscores.sort(mteamscorecmp);
	}
	
	string rinfo;
	rinfo[0] = 0;
	
	loopv(shplayers)
	{
		if (shplayers[i]->clientnum == cl.player1->clientnum)
		{
			if (i != myrankv)
			{
				if (i==0)
				{
					if (cl.player1->state != CS_SPECTATOR)
					{
						hold = true;
						s_sprintf(rinfo)("You've taken %s", myrankv!=-1?"\f1the lead":"\f3first blood");
					}
				}
				else
				{
					if (myrankv==0)
					{
						hold = true;
						s_sprintf(rinfo)("\f2%s \fftakes \f2the lead", cl.colorname(shplayers[0]));
					}
					int df = shplayers[0]->frags - shplayers[i]->frags;
					string cmbN;
					if (cl.player1->state == CS_SPECTATOR)
					{
						df = shplayers[0]->frags - shplayers[i==1?2:1]->frags;
						string dfs;
						if (df)
							s_sprintf(dfs)("+%d frags", df);
						else
							s_sprintf(dfs)("%s","tied for the lead");
						s_sprintf(cmbN)("%s%s%s \f3VS\ff %s\n%s", rinfo[0]?rinfo:"", rinfo[0]?"\n":"", cl.colorname(shplayers[0]), cl.colorname(shplayers[i==1?2:1]), dfs);
					}
					else
					{
						if(df)
							s_sprintf(cmbN)("%s%s\f%d%d\ff %s", rinfo[0]?rinfo:"", rinfo[0]?"\n":"", df>0?3:1, abs(df), cl.colorname(shplayers[0]));
						else
							s_sprintf(cmbN)("%s%s%s \f3VS\ff %s", rinfo[0]?rinfo:"", rinfo[0]?"\n":"", cl.colorname(shplayers[i]), cl.colorname(shplayers[i?0:1]));
					}
					s_sprintf(rinfo)("%s", cmbN);
				}
				myrankv = i;
			}
			else if (myranks)
			{
				if (cl.player1->state == CS_SPECTATOR)
				{
					if (cl.lastmillis > myranks + ranktime())
					{
						if (shplayers.length()>2)
						{
							int df = shplayers[0]->frags - shplayers[i==1?2:1]->frags;
							string dfs;
							if (df)
								s_sprintf(dfs)("+%d frags", df);
							else
								s_sprintf(dfs)("%s","tied for the lead");
							s_sprintf(rinfo)("%s \f3VS\ff %s\n%s", cl.colorname(shplayers[0]), cl.colorname(shplayers[i==1?2:1]), dfs);
						}
					}
				}
				else
				{
					if (cl.lastmillis > myranks + ranktime())
					{
						int df;
						if (shplayers.length()>1)
						{
							if(i)
								df= shplayers[0]->frags - shplayers[i]->frags;
							else
								df = shplayers[1]->frags - shplayers[0]->frags;
							if(df)
								s_sprintf(rinfo)("\f%d%d\ff %s", df>0?3:1, abs(df), cl.colorname(shplayers[df>0?0:1]));
							else
								s_sprintf(rinfo)("%s \f3VS\ff %s", cl.colorname(shplayers[i]), cl.colorname(shplayers[i?0:1]));
						}
					}
				}
				
			}
			myranks = cl.lastmillis;
		}
	}
	if (rankhud() && rinfo[0]) { console("%s", CON_CENTER, rinfo); }
}

void setcrank()
{
	console("\f2%d%s place", CON_LEFT|CON_CENTER, myrankv+1, myrankv ? myrankv == 1 ? "nd" : myrankv == 2 ? "rd" : "th" : "st");
}

void drawicon(float tx, float ty, int x, int y, int s = 64)
{
	rendericon("packages/icons/overlay.png", x, y, s, s);
	
	settexture("data/items.png");
	
	glBegin(GL_QUADS);
	
	int t = s-(s/8)-2, rx = x+(s/16)+1, ry = y+(s/16)+1;
	
	tx /= 384;
	ty /= 128;
	
	glTexCoord2f(tx,		ty);
	glVertex2i(rx,	ry);
	glTexCoord2f(tx+1/6.0f, ty);
	glVertex2i(rx+t, ry);
	glTexCoord2f(tx+1/6.0f, ty+1/2.0f);
	glVertex2i(rx+t, ry+t);
	glTexCoord2f(tx,		ty+1/2.0f);
	glVertex2i(rx,	ry+t);
	
	glEnd();
}

void gameplayhud(int w, int h)
{
	int gamemode = cl.gamemode, ox = w*900/h, oy = 900;
	
	glLoadIdentity();
	glOrtho(0, ox, oy, 0, -1, 1);
	
	glEnable(GL_BLEND);
	
	if (!titlecard(ox, oy, cl.lastmillis-starttime))
	{
		extern int hudblend;
		float fade = 1.f, amt = hudblend*0.01f;
		fpsent *d = cl.player1;
		
		if (cl.lastmillis-starttime <= CARDTIME+CARDFADE+CARDFADE)
			fade = amt*(float(cl.lastmillis-starttime-CARDTIME-CARDFADE)/float(CARDFADE));
		else
			fade *= amt;
			
		if (cl.player1->state == CS_SPECTATOR)
		{
			if (cl.player1->clientnum == -cameranum)
				d = cl.player1;
			else if (cl.players.inrange(-cameranum) && cl.players[-cameranum])
				d = cl.players[-cameranum];
		}
		
		glColor4f(1.f, 1.f, 1.f, amt);
		rendericon("packages/icons/sauer.jpg", 20, oy-75, 64, 64);
		
		if (d != NULL)
		{
			if (d->health > 0 && d->state == CS_ALIVE)
			{
				glColor4f(1.f, 1.f, 1.f, fade);
				drawicon(192.f, 0.f, ox-80, oy-75);
				draw_textx("%d", ox-96, oy-75, 255, d->health<=50 ? (d->health<=25 ? 0 : 128) : 255, d->health<=50 ? 0 : 255, int(255.f*fade), AL_RIGHT, d->health);
				
				glColor4f(1.f, 1.f, 1.f, fade);
				drawicon((float)(d->armourtype*64), 0.f, ox-80, oy-145);
				draw_textx("%d", ox-96, oy-145, 255, d->armour<=50 ? (d->armour<=25 ? 0 : 128) : 255, d->armour<=50 ? 0 : 255, int(255.f*fade), AL_RIGHT, d->armour);
				
				glColor4f(1.f, 1.f, 1.f, fade);
				
				int g = d->gunselect;
				int r = 64;
				if(g==GUN_PISTOL)
				{
					g = 4;
					r = 0;
				}
				else if (g == GUN_TRANCE)
				{
					g = GUN_FIST;
					glColor4f(0.2f, 1.f, 0.1f, fade); // hack
				}
				int mx[NUMGUNS] =
					{
						0, 30, 60, 15, 15, 30, 120, 0, 0, 0, 0, INT_MAX-1
					};
					
				drawicon((float)(g*64), (float)r, ox-80, oy-215);
				
				glColor4f(1.f, 1.f, 1.f, fade);
				draw_textx("%d", ox-96, oy-215, 255, d->ammo[d->gunselect]<=mx[d->gunselect]/2 ? (d->ammo[d->gunselect]<=mx[d->gunselect]/4 ? 0 : 128) : 255, mx[d->gunselect]/2 ? 0 : 255, int(255.f*fade), AL_RIGHT, d->ammo[d->gunselect]);
				
				if (d->quadmillis)
				{
					string qs;
					s_sprintf(qs)("%d", d->quadmillis/1000);
					float c = d->quadmillis <= CARDTIME+CARDFADE+CARDFADE ? 1.f-float(d->quadmillis)/float(CARDTIME+CARDFADE+CARDFADE) : 0.f;
					float f = d->quadmillis <= CARDFADE ? fade*(float(d->quadmillis)/float(CARDFADE)) : fade;
					
					glColor4f(1.f, 1.f, 1.f, f);
					rendericon("packages/icons/blank.jpg", ox-80, oy-285, 64, 64);
					draw_textx("%s", ox-48, oy-285, 255-int(255.f*c), int(255.f*c), 0, int(255.f*f), AL_CENTER, qs);
				}
			}
			else if (d->state == CS_DEAD)
			{
				int action = cl.lastmillis-d->lastpain;
				
				if (m_capture && action < cl.cpc.RESPAWNSECS*1000)
				{
					float c = float((cl.cpc.RESPAWNSECS*1000)-action)/1000.f;
					draw_textx("Fragged! Down for %.2fs", 100, oy-75, 255, 255, 255, int(255.f*fade), AL_LEFT, c);
				}
				else
					draw_textx("Fragged! Press attack to respawn", 100, oy-75, 255, 255, 255, int(255.f*fade), AL_LEFT);
			}
		}
		if (!editmode)
		{
			glLoadIdentity();
			glOrtho(0, w*1800/h, 1800, 0, -1, 1);
			
			glDisable(GL_BLEND);
			
			if(m_capture) cl.cpc.capturehud(w, h);
		}
	}
}

void getmsg(char *text) // messages from the server to intercept, borrowed from executeret()
{
	//bool result = false;
	if (*text)
	{
		const int MAXWORDS = 25;
		char *w[MAXWORDS], *p = text;
		extern char *parseword(char *&p, bool isserver);
		
		int numargs = MAXWORDS;
		loopi(MAXWORDS)
		{
			w[i] = "";
			if(i>numargs)
				continue;
			char *s = parseword(p, true);
			if(s)
				w[i] = s;
			else
				numargs = i;
		}
		
		p += strcspn(p, "\0");
		
		if(*w[0] && !strcmp(w[0], "#MOD#") && *w[1])
		{
			string buf;
			buf[0] = 0;
			
			if (!strcmp(w[1], "version"))
			{
				s_sprintf(buf)("!version SauerMod %d", MODVERSION);
			}
			
			if (buf[0])
			{
				cl.cc.toserver(buf);
			}
		}
	}
}

void checkrespawn()
{
	if(!cl.intermission && cl.player1->state == CS_DEAD)
	{
		int gamemode = cl.gamemode, last = cl.lastmillis-cl.player1->lastpain;
		
		if(m_capture && capturespawn() &&
				last >= cl.cpc.RESPAWNSECS*1000)
		{
			cl.respawnself();
		}
	}
}

void damage(int damage, fpsent *d, fpsent *actor, bool local)
{
	if(bs.isbot(d)) bs.botdamaged(damage, d, actor);

	if (actor == cl.player1) playsound(S_DAMAGED);
}

void frag(fpsent *d, fpsent *actor)
{
	int gamemode = cl.gamemode;

	if(bs.isbot(d)) bs.botkilled(d);

	if (d == cl.player1)
		playsound(cl.lastmillis-d->lastspawn < 10000 ? S_V_OWNED : S_V_FRAGGED);
		
	actor->spree++;
	
	switch (actor->spree)
	{
		case 5:  playsound(S_V_SPREE1, actor != cl.player1 ? &actor->o : NULL); break;
		case 10: playsound(S_V_SPREE2, actor != cl.player1 ? &actor->o : NULL); break;
		case 25: playsound(S_V_SPREE3, actor != cl.player1 ? &actor->o : NULL); break;
		case 50: playsound(S_V_SPREE4, actor != cl.player1 ? &actor->o : NULL); break;
		default: if (actor == cl.player1 && d != cl.player1) playsound(S_KILLED); break;
	}

	if (!multiplayer(false))
		bs.botfrags(actor, d==actor || isteam(actor->team, d->team) ? -1 : 1);
}

void intermission()
{
	int gamemode = cl.gamemode;
	
	if (m_mp(gamemode))
	{
		calcranks();

		if ((m_teammode && teamscores.length() && isteam(cl.player1->team, teamscores[0].team)) ||
			(!m_teammode && shplayers.length() && shplayers[0] == cl.player1))
		{
			conoutf("\f2intermission: you win!");
			playsound(S_V_YOUWIN);
		}
		else
		{
			conoutf("\f2intermission: you lose!");
			playsound(S_V_YOULOSE);
		}
	}
	else
	{
		conoutf("\f2intermission: the game has ended!");
	}
}

void arenaround(fpsent *d)
{
	bool win = false;

	if(d)
	{
		int gamemode = cl.gamemode;
		
		if(m_teammode && isteam(cl.player1->team, d->team)) win = true;
		else if(d == cl.player1) win = true;
	}
	
	playsound(win ? S_V_YOUWIN : S_V_YOULOSE);
}
