// SauerMod - FPSMODGAME - Game Extensions by Quinton Reeves
// Definitions and addons for fpsmod.

#define FPSMODHUDMAX		((h*3/FONTH)*FONTH)-(FONTH*5)		// max hud length
#define FONTH				64									// necessary emulation
	
#define ENTPART				4.f

#define MODALLOWED			!cc.remote
#define ISPLAYER(p)			(p == player1)
#define SFXVEC(p) 			(!ISPLAYER(p) ? &p->o : NULL)

enum {
	WT_WATER = 0,
	WT_HURT,
	WT_KILL,
	WT_MAX
};

