// SauerMod - FPSMODGAME - Game Extensions by Quinton Reeves
// This is the primary mod hook into fpsgame.

#include "fpsdef.h"
#include "fpsent.h"
#include "fpsext.h"

struct fpsmod
{
	fpsclient &cl;
	fpsserver *cs;
	
	#include "botdef.h"
	#include "fpsutl.h"
	
	string cfgname, cptext;
	int cameranum, cameracycled, lastcam, cpmillis, starttime;
	int myrankv, myranks;
	
	vector<fpsent *> shplayers;
	vector<teamscore> teamscores;
	
	IVARP(capturespawn, 0, 0, 1);			// auto respawn in capture games
	IVARP(crosshair, 0, 1, 1);				// show the crosshair
	IVARP(rankhud, 0, 0, 1);				// show ranks on the hud
	IVARP(ranktime, 0, 15000, 600000);		// display unchanged rank no earlier than every N ms
	
	IVAR(cameracycle, 0, 0, 600);			// cycle camera every N secs
	
	fpsmod(fpsclient &_cl) : cl(_cl), bs(_cl), cameranum(0), cameracycled(0), lastcam(-1), myrankv(0), myranks(0)
	{
		CCOMMAND(fpsmod, cameradir, "ii",
				 {
					 self->cameradir(atoi(args[0]), atoi(args[1]) ? true : false);
				 }
				);
		CCOMMAND(fpsmod, centerrank, "",
				 {
					 self->setcrank();
				 }
				);
		CCOMMAND(fpsmod, gotocamera, "i",
				 {
					 self->setcamera(atoi(args[0]));
				 }
				);
				
		CVAR(fpsmod, gravity,		1,			200,		1024);		// gravity
		CVAR(fpsmod, jumpvel,		0,			200,		1024);		// extra velocity to add when jumping
		CVAR(fpsmod, watertype,		WT_WATER,	WT_WATER,	WT_MAX-1);	// water type (0: water, 1: slime, 2: lava)
		CVAR(fpsmod, watervel,		0,			200,		1024);		// extra water velocity
		
		extern igameserver *sv;
		cs = ((fpsserver *)sv);
	}
};
