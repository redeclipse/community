// SauerMod - FPSMODGAME - Game Extensions by Quinton Reeves
// This is mostly stuff we need to hijack from the engine.

void gameplayhud(int w, int h)
{
	extern int hidehud;
	
	if (!hidehud)
	{
		md.gameplayhud(w, h);
	}
}

bool gethudcolour(vec &colour, int fogmat)
{
	extern int curtime, dblend, damageblendfactor;
	
	if (lastmillis-md.starttime <= CARDTIME)
	{
		float fade = (float(lastmillis-md.starttime)/float(CARDTIME));
		
		colour = vec(fade, fade, fade);
		
		return true;
	}
	else if (dblend)
	{
		colour = vec(1.0f, 0.1f, 0.1f);
		
		dblend -= curtime*100/damageblendfactor;
		if(dblend<0)
			dblend = 0;
			
		return true;
	}
	else if (fogmat==MT_WATER || fogmat==MT_LAVA)
	{
		uchar col[3];
		if(fogmat==MT_WATER)
			getwatercolour(col);
		else
			getlavacolour(col);
			
		float maxc = max(col[0], max(col[1], col[2]));
		float blend[3];
		
		loopi(3) blend[i] = col[i] / min(32 + maxc*7/8, 255);
		
		colour = vec(blend[0], blend[1], blend[2]);
		
		return true;
	}
	return false;
}

void fixcamerarange(physent *d)
{
	const float MAXPITCH = 90.0f;
	if(d->pitch>MAXPITCH)
		d->pitch = MAXPITCH;
	if(d->pitch<-MAXPITCH)
		d->pitch = -MAXPITCH;
	while(d->yaw<0.0f)
		d->yaw += 360.0f;
	while(d->yaw>=360.0f)
		d->yaw -= 360.0f;
}

void fixcamerarange()
{
	extern physent *camera1;
	physent *d = isthirdperson() && thirdpersonstick ? camera1 : player1;
	fixcamerarange(d);
}

void mousemove(int dx, int dy)
{
	const float SENSF = 33.0f;	 // try match quake sens
	extern int sensitivity, sensitivityscale, invmouse;
	extern physent *camera1;
	
	physent *d = isthirdperson() && thirdpersonstick ? camera1 : player1;
	
	d->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
	d->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
	
	fixcamerarange(d);
}

physent fpscamera;

void findorientation()
{
	extern physent *camera1;
	physent *d = camera1;
	if (isthirdperson() && !thirdpersonstick && (player1->state != CS_SPECTATOR || player1->clientnum == md.cameranum))
		d = player1;
		
	vec dir;
	vecfromyawpitch(d->yaw, d->pitch, 1, 0, dir);
	vecfromyawpitch(d->yaw, 0, 0, -1, camright);
	vecfromyawpitch(d->yaw, d->pitch+90, 1, 0, camup);
	
	if(raycubepos(d->o, dir, worldpos, 0, RAY_CLIPMAT|RAY_SKIPFIRST) == -1)
		worldpos = dir.mul(10).add(d->o); //otherwise 3dgui won't work when outside of map
}

void recomputecamera()
{
	extern physent *camera1;
	int secs = time(NULL);
	int state, cameratype = 0;
	
	camera1 = &fpscamera;
	
	if (camera1->type != ENT_CAMERA)
	{
		camera1->reset();
		camera1->type = ENT_CAMERA;
	}
	
	if (player1->state == CS_SPECTATOR)
	{
		if (md.cameracycle() > 0 && secs-md.cameracycled > md.cameracycle())
		{
			md.cameradir(1, true);
			md.cameracycled = secs;
		}
		
		if (players.inrange(-md.cameranum) && players[-md.cameranum])
		{
			camera1->o = players[-md.cameranum]->o;
			if (!isthirdperson() || !thirdpersonstick)
			{
				camera1->yaw = players[-md.cameranum]->yaw;
				camera1->pitch = players[-md.cameranum]->pitch;
			}
			state = players[-md.cameranum]->state;
			cameratype = 1;
		}
		else if (player1->clientnum != -md.cameranum)
		{
			int cameras = 1;
			
			loopv (et.ents)
			{
				if (et.ents[i]->type == CAMERA)
				{
					if (cameras == md.cameranum)
					{
						camera1->o = et.ents[i]->o;
						camera1->yaw = et.ents[i]->attr1;
						camera1->pitch = et.ents[i]->attr2;
						state = CS_ALIVE;
						cameratype = 2;
						break;
					}
					cameras++;
				}
			}
		}
	}
	
	if (cameratype <= 0)
	{
		camera1->o = player1->o;
		if (!isthirdperson() || !thirdpersonstick)
		{
			camera1->yaw = player1->yaw;
			camera1->pitch = player1->pitch;
		}
		state = player1->state;
		cameratype = 0;
	}
	else
	{
		camera1->pitch = player1->pitch;
	}
	camera1->eyeheight = 0;
	
	if (isthirdperson() || cameratype > 0)
	{
		if (cameratype != 2)
		{
			if (isthirdperson())
			{
				vec old(camera1->o);
				
				camera1->move = -1;
				camera1->o.z += thirdpersonheight;
				
				if (!thirdpersonstick && !cameratype && thirdpersonscale)
					camera1->pitch = (0.f-fabs(camera1->pitch))*(thirdpersonscale/100.f);
					
				fixcamerarange(camera1);
				
				loopi(10)
				{
					if(!moveplayer(camera1, 10, false, thirdpersondistance))
						break;
				}
				
				if (!thirdpersonstick)
				{
					vec v(cameratype > 0 ? old : worldpos);
					v.sub(camera1->o);
					v.normalize();
					vectoyawpitch(v, camera1->yaw, camera1->pitch);
				}
			}
		}
		
		if (cameratype > 0)
		{
			player1->o = camera1->o;
			player1->yaw = camera1->yaw;
		}
	}
	
	fixcamerarange(camera1);
}

#define ILLUMINATE 32.f

void lighteffects(dynent *e, vec &color, vec &dir)
{
	fpsent *d = (fpsent *)e;
	if ((d->type == ENT_PLAYER || d->type == ENT_AI) && d->state == CS_ALIVE)
	{
		int offset = (lastmillis%1000)+1;
	
		if (d->type == ENT_PLAYER && d->quadmillis)
		{
			offset = (d->quadmillis%1000)+1;
			if (offset > 500) offset = 1000 - offset;
			color.x = max(color.x, 1.f-(float(offset)*0.001f));
		}
		else if (d->type == ENT_AI && d->botflags & BOT_MONSTER && d->botflags & BOT_TRANCE)
		{
			if (offset > 500) offset = 1000 - offset;
			color.y = max(color.y, 1.f-(float(offset)*0.001f));
		}
	}
}

void adddynlights()
{
	loopi(numdynents())
	{
		fpsent *d = (fpsent *)iterdynents(i);
		
		if (d && d->state == CS_ALIVE)
		{
			int offset = (lastmillis%1000)+1;
			vec color(0, 0, 0);

			if (d->type == ENT_PLAYER && d->quadmillis)
			{
				offset = (d->quadmillis%1000)+1;
				if (offset > 500) offset = 1000 - offset;
				color = vec(1, 0, 0);
			}
			else if (d->type == ENT_AI && d->botflags & BOT_MONSTER && d->botflags & BOT_TRANCE)
			{
				if (offset > 500) offset = 1000 - offset;
				color = vec(0, 1, 0);
			}
			
			if (color != vec(0, 0, 0))
			{
				adddynlight(vec(d->o).sub(vec(0, 0, d->eyeheight/2)), ILLUMINATE-(ILLUMINATE*(float(offset)*0.001f)), color, 0, 0);
			}
		}
	}
}


bool wantcrosshair()
{
	extern physent *player;
	extern int hidehud;
	extern bool menuactive();
	return (md.crosshair() && !(hidehud || player->state == CS_SPECTATOR)) || menuactive();
}
bool gamethirdperson()
{
	extern int thirdperson;
	return !editmode && (thirdperson || player1->state == CS_DEAD);
}

char *gametitle()
{
	static char *gname[] = {
								"",							// <
								"Demo Playback",			// -3
								"Singleplayer Classic",		// -2
								"Singleplayer Deathmatch",	// -1
								"Free for All Deathmatch",	// 0
								"Cooperative Edit",			// 1
								"Free for All / Duel",		// 2
								"Team Deathmatch",			// 3
								"Instagib",					// 4
								"Team Instagib",			// 5
								"Efficiency",				// 6
								"Team Efficiency",			// 7
								"Instagib Arena",			// 8
								"Team Instagib Arena",		// 9
								"Tactics Arena",			// 10
								"Team Tactics Arena",		// 11
								"Capture",					// 12
								"Instagib Capture"			// 13
							};
	return gname[gamemode >= -3 && gamemode <= 13 ? gamemode+4 : 0];
}

char *gamepakdir()
{
	return "base";
}

char *defaultmap()
{
	return "douze";
}
char *savedconfig()
{
	return "config.cfg";
}
char *defaultconfig()
{
	return "defaults.cfg";
}
char *autoexec()
{
	return "autoexec.cfg";
}
char *savedservers()
{
	return "servers.cfg";
}

void loadworld(const char *name)
{
	ex.extentfiles(name);
	ex.extentload();
}

void saveworld(const char *name)
{
	ex.extentfiles(name);
	ex.extentsave();
}

float stairheight(physent *d)
{
	return 4.1f;
}
float floorz(physent *d)
{
	return 0.867f;
}
float slopez(physent *d)
{
	return 0.5f;
}
float wallz(physent *d)
{
	return 0.2f;
}
float jumpvel(physent *d)
{
	return MODALLOWED ? (d->inwater ? float(CVGET(watervel)) : float(CVGET(jumpvel))) : 125.f;
}
float gravity(physent *d)
{
	return MODALLOWED ? float(CVGET(gravity)) : 200.f;
}
float stepspeed(physent *d)
{
	return 1.0f;
}
float watergravscale(physent *d)
{
	return 4.0f;
}
float waterdampen(physent *d)
{
	return 8.f;
}
float waterfric(physent *d)
{
	return 20.f;
}
float floorfric(physent *d)
{
	return 6.f;
}
float airfric(physent *d)
{
	return 30.f;
}

vec feetpos(physent *d)
{
	/*if (MODALLOWED)
	{
		if (d->type == ENT_PLAYER || d->type == ENT_AI)
			return vec(d->o).sub(vec(0, 0, d->eyeheight-1));
	}*/
	return vec(d->o);
}

void updatewater (fpsent *d, int waterlevel)
{
	vec v(feetpos(d));
	int mat = modgetmat(v.x, v.y, v.z);
	
	if (waterlevel && (mat != MT_WATER || mat != MT_LAVA))
		mat = modgetmat(v.x, v.y, v.z-2.f);
		
	if (waterlevel || mat == MT_WATER || mat == MT_LAVA)
	{
		if (waterlevel)
		{
			uchar col[3] =
				{
					255, 255, 255
				};
				
			if (mat == MT_WATER)
				getwatercolour(col);
			else if (mat == MT_LAVA)
				getlavacolour(col);
				
			int wcol = (col[2] + (col[1] << 8) + (col[0] << 16));
			
			part_spawn(v, vec(d->xradius, d->yradius, ENTPART), 0, 19, 100, 200, wcol);
		}
		
		if (waterlevel || d->inwater)
		{
			int water = CVGET(watertype);
			
			if (waterlevel < 0 && (mat == MT_WATER && water == WT_WATER))
			{
				playsound(S_SPLASH1, SFXVEC(d));
			}
			else if (waterlevel > 0 && (mat == MT_WATER && water == WT_WATER))
			{
				playsound(S_SPLASH2, SFXVEC(d));
			}
			else if ((waterlevel < 0 || d->inwater) && (mat == MT_WATER && water == WT_HURT))
			{
				part_spawn(v, vec(d->xradius, d->yradius, ENTPART), 0, 5, 200, 500, COL_WHITE);
				if ((ISPLAYER(d) || md.bs.isbot(d)) && lastmillis-d->lastpain > 3000)
					damaged(10, d, d, true);
			}
			else if (waterlevel < 0 && ((mat == MT_WATER && water == WT_KILL) || mat == MT_LAVA))
			{
				part_spawn(v, vec(d->xradius, d->yradius, ENTPART), 0, 5, 200, 500, COL_WHITE);
				if (mat != MT_LAVA && (ISPLAYER(d) || md.bs.isbot(d)))
					suicide(d);
			}
		}
	}
}

void physicstrigger(physent *d, bool local, int floorlevel, int waterlevel)
{
	if (waterlevel)
		updatewater((fpsent *)d, waterlevel);
		
	if (floorlevel > 0)
	{
		playsound(S_JUMP, SFXVEC(d));
	}
	else if (floorlevel < 0)
	{
		playsound(S_LAND, SFXVEC(d));
	}
}

	
void menuevent(int event)
{
	int s = -1;
	switch (event)
	{
		case MN_BACK: s = S_MENUBACK; break;
		case MN_INPUT: s = S_MENUPRESS; break;
		default: break;
	}
	if (s >= 0) playsound(s);
}
