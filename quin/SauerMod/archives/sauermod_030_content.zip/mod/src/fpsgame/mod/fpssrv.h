// SauerMod - FPSMODSRV - Server Extensions by Quinton Reeves
// This is the primary mod hook into fpsserver.

struct fpsmodsrv
{
	fpsserver &cs;
	
	enum
	{
		CM_ANY = 0,
		CM_ALL,
		CM_MASTER
	};
	
	static const char SRVCMDCHR = '!';
	
	#define SRVCMD(n, v, g, b) SCOMMAND(fpsmodsrv, n, v, g, { \
				if (self->cmdcontext) \
				{ \
					if (self->hasmode(self->cmdcontext, v)) { b; } \
					else { s_sprintf(self->scresult)("insufficient access"); } \
					result(self->scresult); \
				} \
			});
	
	#define SRVVAR(n, p, v, m, x, b) SRVCMD(n, v, "i", self->servvar(self->cmdcontext, #n, p, m, x, args[0]); b)
	
	#define POWERUPS I_QUAD-I_SHELLS+1
	
	clientinfo *cmdcontext;
	
	int timelimit, _timelimit, fraglimit, instakill, teamdamage;
	bool powerup[POWERUPS];
	string scresult, motd;
	
	fpsmodsrv(fpsserver &_cs) : cs(_cs), _timelimit(10)
	{
		SRVCMD(version, CM_ANY, "si", self->setversion(self->cmdcontext, args[0], atoi(args[1])));
		
		SRVVAR(timelimit, &self->timelimit, CM_ALL, 0, INT_MAX-1, self->settime());
		SRVVAR(fraglimit, &self->fraglimit, CM_ALL, 0, INT_MAX-1, );
		
		SRVVAR(instakill, &self->instakill, CM_ALL, 0, 1, );
		SRVVAR(teamdamage, &self->teamdamage, CM_ALL, 0, 1, );
		
		SRVCMD(powerup, CM_ALL, "si", self->setpowerup(self->cmdcontext, args[0], args[1]));
		
		motd[0] = 0;
		resetvars();
	}
	~fpsmodsrv()
	{}
	
	void resetvars()
	{
		cmdcontext = NULL;
		
		timelimit = 10;
		fraglimit = 0;
		
		instakill = 0;
		teamdamage = 1;
		
		loopi(POWERUPS) powerup[i] = true;
	}
	
	void startgame()
	{
		// start of map
	}
	
	bool hasmode(clientinfo *ci, int m)
	{
		if (ci != NULL)
		{
			switch (m)
			{
				case CM_ALL:
				case CM_MASTER:
				{
					if (ci->privilege)
						return true;
					else if (m == CM_MASTER)
						return false;
					loopv(cs.clients) if (cs.clients[i]->privilege && ci->clientnum != cs.clients[i]->clientnum)
						return false;
					return true;
					break;
				}
				case CM_ANY:
				default:
				{
					return true;
					break;
				}
			}
			return true;
		}
		return false;
	}
	
	void servvar(clientinfo *ci, const char *name, int *var, int m, int x, char *val)
	{
		if (*val)
		{
			int a = atoi(val);
			if (a < m || a > x)
			{
				s_sprintf(scresult)("valid range for %s is %d..%d", name, m, x);
			}
			else
			{
				*var = a;
				servsend(-1, "%s set %s = %d", cs.colorname(ci), name, *var);
			}
		}
		else
			s_sprintf(scresult)("%s = %d", name, *var);
	}
	
	void setversion(clientinfo *ci, char *mod, int version)
	{
		if (version > 0) ci->modver = version;
		s_sprintf(scresult)("\f2SauerMod support enabled");
	}
	
	void initclient(clientinfo *ci)
	{
		servsend(ci->clientnum, "#MOD# version SauerMod %d", MODVERSION);
	}
	
	void initc2s(clientinfo *ci)
	{
		if (motd[0]) servsend(ci->clientnum, "%s", motd);
	}

	#define Q_INT(c,n) { if(!c->local) { ucharbuf buf = c->messages.reserve(5); putint(buf, n); c->messages.addbuf(buf); } }
	#define Q_STR(c,text) { if(!c->local) { ucharbuf buf = c->messages.reserve(2*strlen(text)+1); sendstring(text, buf); c->messages.addbuf(buf); } }
	
	void settime()
	{
		int diff = _timelimit-timelimit;
		
		cs.minremain -= diff;
		if (cs.minremain < 0)
			cs.minremain = 0;
			
		cs.gamelimit = timelimit*60000;
		
		if(cs.gamemode>1 || (cs.gamemode==0 && hasnonlocalclients()))
			sendf(-1, 1, "ri2", SV_TIMEUP, cs.minremain);
			
		_timelimit = timelimit;
	}
	
	void setpowerup(clientinfo *ci, char *pup, char *type)
	{
		if (*pup)
		{
			char *pups[POWERUPS] = {
				"shells", "bullets", "rockets", "riflerounds", "grenades", "cartridges",
				"health", "healthboost", "greenarmour", "yellowarmour", "quaddamage"
			};
									
			int x = -1;
			loopi(POWERUPS) if (!strcasecmp(pups[i], pup))
			{
				x = i;
				break;
			}
			
			if (x >= 0)
			{
				if (*type)
				{
					bool ret = atoi(type) ? true : false;
					
					if (ret != powerup[x])
					{
						powerup[x] = ret;
						
						// this is all a nasty hack to stay compatible with pure clients and
						// provide an instantaneous (no map change) result during gameplay
						// the side effect being that the issuer of the command will not see
						// the items unspawn, but they also will not be able to pick them up
						
						loopv(cs.sents)
						{
							server_entity &e = cs.sents[i];
							if (e.type == I_SHELLS+x)
							{
								if (e.spawned)
								{
									Q_INT(ci, SV_ITEMPICKUP);
									Q_INT(ci, i);
								}
								
								e.spawned = false;
								e.spawntime = cs.spawntime(e.type);
							}
						}
						servsend(-1, "%s %s the %s", cs.colorname(ci), powerup[x] ? "enabled" : "disabled", pups[x]);
					}
				}
				else
				{
					s_sprintf(scresult)("powerup %s is currently: %s", pups[x], powerup[x] ? "enabled" : "disabled");
				}
			}
			else
				s_sprintf(scresult)("invalid powerup: %s", pup);
		}
		else
			s_sprintf(scresult)("insufficient parameters");
	}
	
	bool checkpowerup(int type)
	{
		if (type >= I_SHELLS && type <= I_QUAD)
			return powerup[type-I_SHELLS];
		return true;
	}
	
	void servsend(int cn, const char *s, ...)
	{
		s_sprintfdlv(str, s, s);
		sendf(cn, 1, "ris", SV_SERVMSG, str);
	}
	
	bool servtext(clientinfo *ci, char *text)
	{
		if (ci && *text && text[0] == SRVCMDCHR)
		{
			string t;
			s_strcpy(t, text);
			
			cmdcontext = ci;
			t[0] = '/';
			
			scresult[0] = 0;
			char *ret = executeret(t, true);
			if (ret) // our reply is the result()
			{
				servsend(ci->clientnum, "%s", ret);
				delete[] ret;
			}
			
			cmdcontext = NULL;
			
			return true;
		}
		return false;
	}
	
	struct scr
	{
		char *name;
		int val;
		
		scr(char *_n, int _v) : name(_n), val(_v) {}
		~scr() {}
	}
	;
	
	static int scrsort(const scr **a, const scr **b)
	{
		if((*a)->val > (*b)->val) return -1;
		if((*a)->val < (*b)->val) return 1;
		return strcmp((*a)->name, (*b)->name);
	}
	
	void scradd(vector<scr *> &dest, char *name, int amt)
	{
		loopvk(dest)
		{
			if (!strcmp(dest[k]->name, name))
			{
				dest[k]->val += amt;
				return;
			}
		}
		dest.add(new scr(name, amt));
	}
	
	void updatescores()
	{
		int gamemode = cs.gamemode;
		
		if (!m_capture && fraglimit > 0 && cs.minremain > 0)
		{
			vector<scr *> scrs;
			
			loopv(cs.clients)
			{
				clientinfo *ci = cs.clients[i];
				if (m_teammode)
				{
					scradd(scrs, ci->team, ci->state.frags);
				}
				else
				{
					scradd(scrs, ci->name, ci->state.frags);
				}
			}
			
			if (scrs.length() > 0)
			{
				scrs.sort(scrsort);
				if (scrs[0]->val >= fraglimit)
					cs.startintermission();
			}
			
			loopv(scrs) DELETEP(scrs[i]);
		}
	}
}
mds;
