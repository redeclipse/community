// SauerMod - FPSMODGAME - Game Extensions by Quinton Reeves
// Extended entity definitions.

#define EXTENT		100
#define EXTENTVER	3

enum {
	CAMERA = EXTENT,		// attr1 = yaw, attr2 = pitch, attr3 = pan (+:horiz/-:vert), attr4 = idx
	WAYPOINT,				// none?
	MAXEXTENT
};

struct extent : fpsentity
{
	vector<int> links;		// link list
	
	extent()
	{}
	~extent()
	{}
}
;

struct extents
{
	fpsclient &cl;
	string extentfile;
	
	struct extentitem
	{
		char *name;							// item name
		bool touch, pickup, render, pure;	// item is touchable / collectable / renderable / pure sauer compat.
		float dist, yaw, zoff;				// item pickup distance / yaw, z offset (-1 for bobbing)
	}
	*extentitems;
	
	IVARP(showallwp, 0, 0, 1);
	
	extents(fpsclient &_cl) : cl(_cl)
	{
		static extentitem _extentitems[] = {
			{ "camera",		false,	false,	false,	true,	0.f,	0.f,	0.f },
			{ "waypoint",	false,	false,	false,	true,	0.f,	0.f,	0.f },
		};
		extentitems = _extentitems;
		
		CCOMMAND(extents, entdelink, "i",
				 {
					 self->extentdelink(atoi(args[0]));
				 }
				);
		CCOMMAND(extents, entlink, "i",
				 {
					 self->extentlink(atoi(args[0]));
				 }
				);
		CCOMMAND(extents, entsave, "",
				 {
					 self->extentsave();
				 }
				);
	}
	~extents()
	{}
	
	const char *extentname(int i)
	{
		bool chk = isextent(i);
		if (i >= MAXENTTYPES && !chk)
			return "reserved"; // so we can add extents
		return chk ? extentitems[i-EXTENT].name : "";
	}
	
	bool isextent(int type, int want = 0)
	{
		return type >= EXTENT && type < MAXEXTENT && (!want || type == want);
	}
	
	bool extentpure(int i)
	{
		return cl.et.ents.inrange(i) && isextent(cl.et.ents[i]->type) ? extentitems[i-EXTENT].pure : false;
	}
	
	void extentdelink(int both)
	{
		if (entgroup.length() > 0)
		{
			int index = entgroup[0];
			
			if (cl.et.ents.inrange(index))
			{
				int type = cl.et.ents[index]->type, last = -1;
				
				if (type != WAYPOINT)
					return; // we only link waypoints so far
					
				loopv(entgroup)
				{
					index = entgroup[i];
					
					if (cl.et.ents.inrange(index) && cl.et.ents[index]->type == type)
					{
						if (cl.et.ents.inrange(last))
						{
							int g;
							
							extent &e = (extent &)*cl.et.ents[index];
							extent &l = (extent &)*cl.et.ents[last];
							
							if ((g = l.links.find(index)) >= 0)
								l.links.remove(g);
							if (both && ((g = e.links.find(last)) >= 0))
								e.links.remove(g);
						}
						last = index;
					}
				}
			}
		}
	}
	
	void extentlink(int both)
	{
		if (entgroup.length() > 0)
		{
			int index = entgroup[0];
			
			if (cl.et.ents.inrange(index))
			{
				int type = cl.et.ents[index]->type, last = -1;
				
				if (type != WAYPOINT)
					return; // we only link waypoints so far
					
				loopv(entgroup)
				{
					index = entgroup[i];
					
					if (cl.et.ents.inrange(index) && cl.et.ents[index]->type == type)
					{
						if (cl.et.ents.inrange(last))
						{
							extent &e = (extent &)*cl.et.ents[index];
							extent &l = (extent &)*cl.et.ents[last];
							
							if (l.links.find(index) < 0)
								l.links.add(index);
							if (both && e.links.find(last) < 0)
								e.links.add(last);
						}
						last = index;
					}
				}
			}
		}
	}
	
	void extentlinks(int n)
	{
		loopv(cl.et.ents)
		{
			if (isextent(cl.et.ents[i]->type))
			{
				extent &e = (extent &)*cl.et.ents[i];
				
				loopvj(e.links)
				{
					if (e.links[j] == n)
					{
						e.links.remove(j);
						break;
					}
				}
			}
		}
	}
	
	void extentfix(extentity &d)
	{
		if (isextent(d.type))
		{
			extent &e = (extent &)d;
			
			e.links.setsize(0);
			
			switch(e.type)
			{
				case CAMERA:	// place with "newent camera idx [pan]"
				e.attr4 = e.attr1;
				e.attr3 = e.attr2;
				e.attr2 = (int)cl.player1->pitch;
				e.attr1 = (int)cl.player1->yaw;
				break;
				case WAYPOINT:
				e.attr1 = e.attr1 >= 0 && e.attr1 <= 1 ? e.attr1 : (e.attr1 > 1 ? 0 : 1);
				e.attr2 = e.attr2 >= 0 ? e.attr2 : 0;
				e.attr3 = e.attr3 >= 0 ? e.attr3 : 0;
				break;
				default:
				break;
			}
		}
	}
	
	void extentedit(int i)
	{
		if (cl.et.ents[i]->type == ET_EMPTY)
			extentlinks(i); // cleanup links
	}
	
	extentity *newent(int type)
	{
		return new extent();
	};
	
	void gotocamera(int n, fpsent *d, int &delta)
	{
		int e = -1, tag = n, beenhere = -1;
		for(;;)
		{
			e = findentity(CAMERA, e+1);
			if(e==beenhere || e<0)
			{
				conoutf("no camera destination for tag %d", tag);
				return;
			};
			if(beenhere<0)
				beenhere = e;
			if(cl.et.ents[e]->attr4==tag)
			{
				d->o = cl.et.ents[e]->o;
				d->yaw = cl.et.ents[e]->attr1;
				d->pitch = cl.et.ents[e]->attr2;
				delta = cl.et.ents[e]->attr3;
				if (cl.player1->state == CS_EDITING)
				{
					vec dirv;
					vecfromyawpitch(d->yaw, d->pitch, 1, 0, dirv);
					vec tinyv = dirv.normalize().mul(10.0f);
					d->vel = tinyv;
				}
				else
				{
					d->vel = vec(0, 0, 0);
				}
				s_sprintfd(camnamalias)("camera_name_%d", cl.et.ents[e]->attr4);
				break;
			}
		}
	}
	
	void extentfiles(const char *fname)
	{
		string mapname;
		if(strpbrk(fname, "/\\"))
			s_strcpy(mapname, fname);
		else
			s_sprintf(mapname)("%s/%s", cl.gamepakdir(), fname);
			
		s_sprintf(extentfile)("packages/%s.etz", mapname);
		path(extentfile);
	}
	
	bool extentload()
	{
		gzFile f = opengzfile(extentfile, "rb9");
		
		if (f)
		{
			bool ans = false;
			
			char head[4];
			int version, regents = cl.et.ents.length();
			
			gzread(f, &head, 4);
			version = modgetint(f);
			
			if (!strncmp(head, "ENTZ", 4))
			{
				if (version <= EXTENTVER)
				{
					extern void show_out_of_renderloop_progress(float bar1, const char *text1, float bar2 = 0, const char *text2 = NULL, GLuint tex = 0);
					
					int numents;
					float bar1;
					
					numents = modgetint(f); // number of extents
					
					loopi(numents)
					{
						bar1 = float(i) / float(numents);
						show_out_of_renderloop_progress(bar1, "loading extended entities...");
						
						extent &e = *(new extent());
						cl.et.ents.add(&e);
						gzread(f, &e, sizeof(entity));
						endianswap(&e.o, sizeof(int), 3);
						endianswap(&e.attr1, sizeof(short), 5);
						e.spawned = false;
						e.inoctanode = false;
						
						e.links.setsize(0);
						if (version >= 2)
						{
							int links = modgetint(f);
							
							loopj(links)
							{
								int link = modgetint(f), id = link + regents;
								e.links.add(id); // realign to entity table
							}
						}
						
						if(!insideworld(e.o))
						{
							conoutf("warning: ent outside of world: enttype[%s] index %d (%f, %f, %f)", cl.et.entname(e.type), i, e.o.x, e.o.y, e.o.z);
						}
					}
					
					conoutf("loaded %d extended entities from %s (v%d)", numents, extentfile, version);
					ans = true;
					
					//if (version <= 2)
					//{
					//	conoutf("WARNING: older etz without entity waypoints, generating them");
					//	cl.md.bs.botwayspawn();
					//}
				}
				else
					conoutf("extended entity file %s made with a newer version, please upgrade", extentfile);
			}
			else
				conoutf("extended entity file %s is corrupt", extentfile);
				
			gzclose(f);
			return ans;
		}
		//conoutf("could not load extended entity file %s", extentfile);
		
		return false;
	}
	
	bool extentsave()
	{
		vector<vector<int> *> links;
		int numents = 0;
		
		loopv(cl.et.ents) links.add(new vector<int>);
		
		loopv(cl.et.ents)
		{
			if (isextent(cl.et.ents[i]->type))
			{
				loopvj(cl.et.ents)
				{
					if (isextent(cl.et.ents[j]->type))
					{
						extent &e = (extent &)*cl.et.ents[j];
						vector<int> &s = *links[j];
						if (e.links.find(i) >= 0)
							s.add(numents); // align to indices
					}
				}
				numents++;
			}
		}
		
		if (numents)
		{
			gzFile f = opengzfile(extentfile, "wb9");
			if(f)
			{
				char head[4];
				
				strncpy(head, "ENTZ", 4);
				gzwrite(f, &head, 4);
				
				modputint(f, EXTENTVER);
				modputint(f, numents);
				
				loopv(cl.et.ents)
				{
					if (isextent(cl.et.ents[i]->type))
					{
						extent tmp = (extent &)*cl.et.ents[i];
						endianswap(&tmp.o, sizeof(int), 3);
						endianswap(&tmp.attr1, sizeof(short), 5);
						gzwrite(f, &tmp, sizeof(entity));
						
						vector<int> &s = *links[i];
						modputint(f, s.length());
						loopvj(s)
						{
							modputint(f, s[j]); // aligned index
						}
					}
				}
				
				loopv(links) DELETEP(links[i]);
				
				gzclose(f);
				conoutf("saved %d extended entities to %s", numents, extentfile);
				return true;
			}
		}
		conoutf("could not save extended entity file %s", extentfile);
		return false;
	}
	
	void extentityrender(extentity &e, const char *mdlname, float z, float yaw, int frame = 0, int anim = ANIM_MAPMODEL|ANIM_LOOP, int basetime = 0, float speed = 10.0f)
	{
		rendermodel(e.color, e.dir, mdlname, anim, 0, 0, vec(e.o).add(vec(0, 0, z)), yaw, 0, speed, basetime, NULL, MDL_SHADOW | MDL_CULL_VFC | MDL_CULL_DIST | MDL_CULL_OCCLUDED);
	}
	
	char *extentmdl(extentity &e)
	{
		char *imdl = NULL;
		
		switch (e.type)
		{
			default:
			break;
		}
		return imdl;
	}
	
	void renderwaypoint(extentity &e)
	{
		extent &d = (extent &)e;
		
		loopv(d.links)
		{
			int index = d.links[i];
			
			if (cl.et.ents.inrange(index))
			{
				extent &f = (extent &)*cl.et.ents[index];
				bool both = false;
				
				loopvj(f.links)
				{
					int g = f.links[j];
					if (cl.et.ents.inrange(g) && isextent(cl.et.ents[g]->type))
					{
						extent &h = (extent &)*cl.et.ents[g];
						if (&h == &e)
						{
							both = true;
							break;
						}
					}
				}
				
				vec fr = d.o, to = f.o;
				
				fr.z += RENDERPUSHZ;
				to.z += RENDERPUSHZ;
				
				vec col(0, 0, 0);
				float jump = f.o.z-d.o.z;
				
				if (d.o.dist(f.o) >= BOTISFAR || d.o.dist(f.o) <= BOTISNEAR)
				{
					col.x = 0.75f;
				}
				else if (jump >= BOTJUMPDIST || (both && jump <= 0-BOTJUMPDIST))
				{
					col.x = 0.75f;
					
					if (jump <= BOTJUMPMAX || (both && jump >= 0-BOTJUMPMAX))
						col.y = 0.5f;
				}
				else
				{
					col.x = both ? 0.5f : 0.0f;
					col.z = 0.75f;
				}
				
				renderline(fr, to, col.x, col.y, col.z);
				
				if (editmode)
				{
					if (entgroup.find(efocus) >= 0 || efocus == enthover)
					{
						vec dr = to;
						float yaw, pitch;
						
						dr.sub(fr);
						dr.normalize();
						
						vectoyawpitch(dr, yaw, pitch);
						
						dr.mul(RENDERPUSHX);
						dr.add(fr);
						
						rendertris(dr, yaw, pitch, 1.f, col.x, col.y, col.z, true);
						
						if (showentradius)
						{
							renderentradius(d.o, BOTISNEAR, BOTISNEAR);
							renderentradius(d.o, BOTISFAR, BOTISFAR);
						}
					}
				}
			}
		}
	}
	
	void renderentforce(extentity &e)
	{
		switch (e.type)
		{
			case WAYPOINT:
			{
				if (showentdir && showallwp())
					renderwaypoint(e);
				break;
			}
			default: break;
		}
	}
	
	void renderentshow(extentity &e)
	{
		if (showentradius)
		{
			if (isextent(e.type))
			{
				extentitem &t = extentitems[e.type-EXTENT];
				renderentradius(e.o, t.dist, t.dist);
			}
			else if (e.type < MAXENTTYPES && e.type >= I_SHELLS &&
				e.type != TELEPORT && e.type != TELEDEST && e.type != MONSTER)
			{
				if (e.type == BASE)
					renderentradius(e.o, cl.cpc.CAPTURERADIUS, cl.cpc.CAPTURERADIUS);
				else
					renderentradius(e.o, 12.f, 12.f);
			}
		}
		
		switch (e.type)
		{
			case ET_PLAYERSTART:
			case ET_MAPMODEL:
			{
				if (showentdir)
				{
					renderentdir(e.o, e.attr1, 0);
				}
				break;
			}
			case CAMERA:
			{
				if (showentdir && e.attr1 >= 0.f && e.attr1 <= 360.f)
				{
					renderentdir(e.o, e.attr1, e.attr2);
				}
				break;
			}
			case WAYPOINT:
			{
				if (showentdir && !showallwp())
					renderwaypoint(e);
				break;
			}
			default: break;
		}
	}
	
	void extentrender()
	{
#define entfocus(i, f) \
			{ int n = efocus = (i); if(n>=0) { extentity &e = *cl.et.ents[n]; f; } }
	
		if (editmode)
		{
			renderprimitive(true);
			loopv(entgroup) entfocus(entgroup[i], renderentshow(e));
			if(enthover>=0) entfocus(enthover, renderentshow(e));
			loopv(cl.et.ents) entfocus(i, renderentforce(e));
			renderprimitive(false);
		}
		else if (showallwp())
		{
			renderprimitive(true);
			loopv(cl.et.ents) entfocus(i, if (e.type == WAYPOINT) renderentforce(e););
			renderprimitive(false);
		}
		
		loopv(cl.et.ents)
		{
			extentity &e = *cl.et.ents[i];
			
			if (isextent(e.type))
			{
				extentitem &t = extentitems[e.type-EXTENT];
				
				if(!t.render)
					continue;
					
				float z = (t.zoff == -1 ? (float)(1+sin(cl.lastmillis/100.0+e.o.x+e.o.y)/20) : t.zoff);
				float yaw = (t.yaw == -1 ? cl.lastmillis/10.0f : t.yaw);
				char *imdl = extentmdl(e);
				
				if (imdl)
					extentityrender(e, imdl, z, yaw);
			}
		}
	}
};
