// SauerMod - MASTERSERVER - Mod-friendly alternative master server.

#ifndef __def_h__
#define __def_h__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>

//#define DBG

#define MAXSIZE		1024
#define MAXVARS		32

#include "dbg.h"
#include "cgi.h"
#include "utl.h"

#endif
