// SauerMod - MODENGINE - Engine Extensions by Quinton Reeves
// This extends igame.h igameserver

virtual void serverinfostrx(char *dhost, char *dgame, const char *name, const char *desc, const char *map, int ping, const vector<int> &attr, int np) { return; }
virtual int getmastertype() { return 0; }
