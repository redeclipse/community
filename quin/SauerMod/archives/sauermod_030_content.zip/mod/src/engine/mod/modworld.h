// SauerMod - MODENGINE - Engine Extensions by Quinton Reeves
// This extends world.cpp for game module entity extensions

void newentity(vec &v, int type, int a1, int a2, int a3, int a4)
{
	extentity *t = newentity(true, v, type, a1, a2, a3, a4);
	et->getents().add(t);
	int i = et->getents().length()-1;
	t->type = ET_EMPTY;
	enttoggle(i);
	makeundoent();
	entedit(i, e.type = type);
}
