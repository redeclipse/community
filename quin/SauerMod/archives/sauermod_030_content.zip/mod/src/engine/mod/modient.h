// SauerMod - MODENGINE - Engine Extensions by Quinton Reeves
// This extends igame.h icliententities

virtual extentity *newent(int type) { return newentity(); };
