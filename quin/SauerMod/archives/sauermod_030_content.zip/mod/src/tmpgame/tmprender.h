// SauerMod - TMPGAME - Kart Racing Simulator by Quinton Reeves
// This is the tmp rendering processes.

void fixcamerarange(physent *d)
{
	const float MAXPITCH = 90.0f;
	if(d->pitch>MAXPITCH) d->pitch = MAXPITCH;
	if(d->pitch<-MAXPITCH) d->pitch = -MAXPITCH;
	while(d->yaw<0.0f) d->yaw += 360.0f;
	while(d->yaw>=360.0f) d->yaw -= 360.0f;
}

void mousemove(int dx, int dy)
{
	const float SENSF = 33.0f;	 // try match quake sens
	physent *d = isthirdperson() ? camera1 : player1;
	
	d->yaw += (dx/SENSF)*(sensitivity/(float)sensitivityscale);
	d->pitch -= (dy/SENSF)*(sensitivity/(float)sensitivityscale)*(invmouse ? -1 : 1);
}

void recomputecamera()
{
	if (player1->state == CS_EDITING || player1->state == CS_SPECTATOR)
	{
		camera1 = player1;
	}
	else
	{
		camera1 = camera;

		camera1->o = player1->o;
		if (!isthirdperson() || !thirdpersonstick)
		{
			camera1->yaw = player1->yaw;
			camera1->pitch = player1->pitch;
		}

		if (isthirdperson())
		{
			vec old(camera1->o);

			camera1->move = -1;
			camera1->o.z += thirdpersonheight;
			
			//if (!thirdpersonstick && thirdpersonscale)
			//	camera1->pitch = (0.f-fabs(camera1->pitch))*(thirdpersonscale/100.f);

			fixcamerarange(camera1);
			
			loopi(10)
			{
				if(!moveplayer(camera1, 10, false, thirdpersondistance)) break;
			}
			
			if (!thirdpersonstick)
			{
				vec v(old);
				v.sub(camera1->o);
				v.normalize();
				vectoyawpitch(v, camera1->yaw, camera1->pitch);
			}
		}
	}
	fixcamerarange(camera1);
}

void rendergame()
{
	//startmodelbatches();
	//endmodelbatches();
}


void drawhudgun() {}

void gameplayhud(int w, int h) {}

void g3d_gamemenus() {}
bool wantcrosshair() { return (!hidehud && !isthirdperson()) || menuactive(); }
bool gamethirdperson() { return player1->state != CS_EDITING && player1->state != CS_SPECTATOR; }

bool gethudcolour(vec &colour, int fogmat)
{
	return false;
}
