// SauerMod - TMPGAME - Kart Racing Simulator by Quinton Reeves
// This is the primary tmp definitions.

extern int curtime, gamespeed, lastmillis, dblend, damageblendfactor;
extern int hidehud, fov, hudgunfov, invmouse, sensitivity, sensitivityscale;
extern int musicvol, soundvol, entselradius;

extern physent *player, *camera1, *hitplayer;

extern bool menuactive();
extern void show_out_of_renderloop_progress(float bar1, const char *text1, float bar2 = 0, const char *text2 = NULL);

struct cament : physent
{
	cament()
	{
		type = ENT_CAMERA;
	}
	~cament() {}
	
};

struct tmpent : dynent
{
	int null;
};

struct tmpentity : extentity
{
	tmpentity() {}
	~tmpentity() {}
};

// dummy
struct tmpdummycom : iclientcom
{
    tmpdummycom()
    {
        CCOMMAND(tmpdummycom, map, "s", self->changemap(args[0]));
    }
	~tmpdummycom() { }

	void gamedisconnect() {}
	void parsepacketclient(int chan, ucharbuf &p) {}
	int sendpacketclient(ucharbuf &p, bool &reliable, dynent *d) { return -1; }
	void gameconnect(bool _remote) {}
	bool allowedittoggle() { return true; }
	void writeclientinfo(FILE *f) {}
	void toserver(char *text) {}
	void changemap(const char *name) { load_world(name); }
};

struct tmpdummyserver : igameserver
{
	~tmpdummyserver() { }

	void *newinfo() { return NULL; }
	void resetinfo(void *ci) {}
	void serverinit(char *sdesc, char *adminpass, bool pubserv) {}
	void clientdisconnect(int n) {}
	int clientconnect(int n, uint ip) { return DISC_NONE; }
	void localdisconnect(int n) {}
	void localconnect(int n) {}
	char *servername() { return "none"; }
	void parsepacket(int sender, int chan, bool reliable, ucharbuf &p) {}
	bool sendpackets() { return false; }
	int welcomepacket(ucharbuf &p, int n) { return -1; }
	void serverinforeply(ucharbuf &p) {}
	void serverupdate(int seconds) {}
	bool servercompatible(char *name, char *sdec, char *map, int ping, const vector<int> &attr, int np) { return false; }
	void serverinfostr(char *buf, const char *name, const char *desc, const char *map, int ping, const vector<int> &attr, int np) {}
	int serverinfoport() { return 0; }
	int serverport() { return 0; }
	char *getdefaultmaster() { return "none"; }
	void sendservmsg(const char *s) {}
};
