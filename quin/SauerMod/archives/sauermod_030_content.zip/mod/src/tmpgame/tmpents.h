// SauerMod - TMPGAME - Kart Racing Simulator by Quinton Reeves
// This is the tmp entities.

struct tmpentities : icliententities
{
	tmpclient &cl;
	vector<tmpentity *> ents;

	struct tmpitem
	{
		char *name;								// name
		bool touch, pickup, proj;						// touchable / collectable / by projectile
		int render, wait;						// render type (0: don't, 1: bobbing/rotating, 2: static) / wait time
		float yaw, zoff, height, radius, elast;	// yaw / z offset / height / radius / bounciness
	} *tmpitems;

	tmpentities(tmpclient &_cl) : cl(_cl)
	{
		//	n					t		p		j		r	w	y		z		h		r		e
		static tmpitem _tmpitems[] = {
			{ "none?",			false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "light",			false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "mapmodel",		false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "playerstart",	false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "envmap",			false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "particles",		false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "sound",			false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f },
			{ "spotlight",		false,	false,	false,	0,	0, 	0.f,	0.f,	0.f,	0.f,	0.0f }
		};
		tmpitems = _tmpitems;
	}
	~tmpentities() { }

	vector<extentity *> &getents() { return (vector<extentity *> &)ents; }

	void fixentity(extentity &d) {}
	void editent(int i) {}
	const char *entnameinfo(entity &e) { return ""; }
	const char *entname(int i) { return i >= 0 && i < ET_GAMESPECIFIC ? tmpitems[i].name : ""; }

	int extraentinfosize() { return 0; }
	void writeent(entity &e, char *buf) {}
	void readent (entity &e, char *buf) {}
	float dropheight(entity &e) { return 0.f; }

	void rumble(const extentity &e) {}
	void trigger(extentity &e) {}

	extentity *newentity() { return new tmpentity; }
};
