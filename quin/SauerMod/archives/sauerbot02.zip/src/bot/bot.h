// bot.h - Offline test and practice AI for the Sauerbraten Engine by Quinton Reeves.

struct botset
{
    fpsclient &cl;
    vector<extentity *> &ents;

	#define WAYPOINTVER		1 // bump if format changes
	#define WAYPOINTDIST	24.0f
	
	#define BOTJUMPDIST		3.6f
	#define BOTBACKDIST		64.0f
	#define BOTLOSDIST(x)	(514.0f - (x * 2.0))	// = 512 MAX
	#define BOTFOVX(x)		(96.5f - (x * 0.5))		// = 96 MAX
	#define BOTFOVY(x)		(128.5f - (x * 0.5))	// = 128 MAX
	#define BOTRNDMOVE(x)	(rnd(x) == 0 ? rnd(3)-1 : 0)    // -1, 0, 1

	#define BOTALLOWED		(m_mp(cl.gamemode) && !cl.cc.remote ? true : false)

	struct botway
	{
		vec pos;
		vector<int> nodes;
	};
	vector<botway *> waypoints;

    int bottotal, waylast;
    string wayname;
	
    botset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents), bottotal(0), waylast(-1)
	{
        CCOMMAND(botset, botadd, "ii", { int num = (args[0][0] ? atoi(args[0]) : -1); int ar = (args[1][0] ? atoi(args[1]) : -1); self->botadd(num, ar); });
        CCOMMAND(botset, botdel, "i", { int num = (args[0][0] ? atoi(args[0]) : -1); self->botdel(num); });
        CCOMMAND(botset, botload, "", { self->botwayload(); });
        CCOMMAND(botset, botsave, "", { self->botwaysave(); });
	}
    
    IVAR(botrate, 1, 10, 100);	// rate of action updates and judgement errors
    IVAR(botauto, 0, 1, 1);		// autmically load bots on start of map
    IVAR(botnum, 0, 0, 15);		// set to force a number of bots when automatically loading
    IVAR(botdrop, 0, 0, 1);		// drop waypoints during play (auto-set but toggleable)
    IVAR(botshow, 0, 0, 1);		// show bot debugging like waypoints

	void botnames(char *fname)
	{
	    string mapname;
	    if(strpbrk(fname, "/\\")) s_strcpy(mapname, fname);
	    else s_sprintf(mapname)("base/%s", fname);
	
	    s_sprintf(wayname)("packages/%s.wpz", mapname);
	    path(wayname);
	}

	void botadd(int num, int ar)
	{
        if (BOTALLOWED)
        {
			int n = (num >= 0 ? num : botnum()), s = (ar >= 0 ? ar : botrate());
			
			if (n == 0)
			{
				int r = 0;
				loopv(ents) if (ents[i]->type == PLAYERSTART)
				{
					r++;
				}
				n = max(r >= 8 ? r - (r / 3) : r - 2, 2);
				
			}
			
			if (n <= 0)
				return;

	        while (n > 0 && bottotal < 16)
            {
               	fpsent *bot = cl.getclient(bottotal);
           		bottotal++;

		        s_sprintf(bot->name)("bot_%02d", bottotal);
		        if (bottotal%2)
		        {
		        	s_sprintf(bot->team)("red");
				}
				else
				{
		        	s_sprintf(bot->team)("blue");
				}
		        bot->move = bot->strafe = 0;
			
              	cl.spawnstate(bot);
				
				bot->state = CS_DEAD;
				bot->botrate = (s < 1 ? 1 : (s > 100 ? 100 : s));

				bottrans(bot, M_PAIN, 0, 0, true, bottotal*10);

		        conoutf("connected: %s (team: %s, rate: %d)", bot->name, bot->team, bot->botrate);

               	n--;
			}
		}
		else
			conoutf("addbot is only available in offline multiplayer games");
	}

	void botdel(int num)
	{
        if (BOTALLOWED)
        {
			if (cl.players.length() <= 0) return;

			int n = (num >= 0 ? num : 1);
			
			if (n == 0 || n > cl.players.length())
			{
				n = cl.players.length();
			}	
			
			int x = cl.players.length()-1;
	        while (x >= 0 && n > 0 && cl.players.length() > 0) 
			{
				if (cl.players[x]->botstate != M_NONE)
            	{
					fpsent *bot = cl.players[x];

            		conoutf("bot %s disconnected", bot->name);

            		cl.players.remove(x);
            		DELETEP(bot);
	                cleardynentcache();
					n--;
            		bottotal--;
				}
				x--;
			}
		}
		else
			conoutf("delbot is only available in offline multiplayer games");
	}

    void botthink(fpsent *bot, int curtime, int gamemode)
    {
        if(cl.intermission) return;

		if(bot->state == CS_SPECTATOR || bot->state == CS_EDITING)
		{
			bot->state = CS_DEAD;
			bottrans(bot, M_PAIN, 0, 0, false, 2500);
		}

       	botaction(bot, curtime);

        if(bot->state==CS_ALIVE)
        {
			float bk = curtime * (1.01f - (bot->botrate * 0.01f));

			if (bot->botstate != M_SLEEP && bot->botstate != M_PAIN)
				botvector(bot); // recalc bot vector

		    if(bot->botrot.y>bot->yaw)             // slowly turn bot towards his target
            {
                bot->yaw += bk;
                if(bot->botrot.y<bot->yaw) bot->yaw = bot->botrot.y;
            }
            else
            {
                bot->yaw -= bk;
                if(bot->botrot.y>bot->yaw) bot->yaw = bot->botrot.y;
            }

	        cl.et.checkquad(bot, curtime);
        	cl.et.checkitems(bot);

			botmove(bot, 2, true); // main update

			if (bot->botstate == M_HOME)
			{
				if (bot->o.dist(bot->botvec) <= bot->radius*3)
				{
				    bottrans(bot, M_SEARCH, 0, 0, false, 1);
				}
				else if (bot->botvec.x-bot->o.x <= bot->radius*2 && bot->botvec.y-bot->o.y <= bot->radius*2 && bot->botvec.z-bot->o.z >= BOTJUMPDIST)
				{
					bot->jumpnext = true;
				}
			}
        }
        else
        {
            bot->move = bot->strafe = 0;

            if(cl.lastmillis-bot->lastaction<2000)
            {
				botmove(bot, 2, false);
            }
        }
		bot->lastupdate = cl.lastmillis;
    }

	void botkilled(fpsent *d, fpsent *f)
	{
		if (d != f)
			f->frags++;
		else
			d->frags--;

		bottrans(d, M_PAIN, 0, 0, false, 2500);
	}

    bool inlos(vec &o, vec &q, vec &v)
    {
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
        return distance >= mag; 
    }

	bool insight(fpsent *bot, vec &q, vec &v, float mdist)
	{
		vec see(bot->o.x, bot->o.y, bot->o.z);
		float dist = see.dist(q);
		
		if (dist <= mdist)
		{
			float x = fabs((asin((q.z - bot->o.z) / dist) / RAD) - bot->botrot.x);
			float y = fabs((-(float)atan2(q.x - bot->o.x, q.y - bot->o.y)/PI*180+180) - bot->botrot.y);

			if (x <= BOTFOVX(bot->botrate) && y <= BOTFOVY(bot->botrate))
				return inlos(bot->o, q, v);
		}
		
		return false;
	}
    
    void hitvec(vec &o, vec &q, vec &v)
    {
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
    }

    void bottrans(fpsent *bot, int stat, int mv, int st, bool dev, int n)
    {
        bot->move = mv;
        bot->strafe = st;
		int q = (dev ? rnd(n * bot->botrate) : rnd(n)), v = n + q;
    	bot->botstate = stat;
    	bot->botms = cl.lastmillis + v;
    	//conoutf ("%s transition to %d (%d)", bot->name, bot->botstate, v);
    }

	void botvector(fpsent *bot)
	{
		bot->botrot.y = -(float)atan2(bot->botvec.x - bot->o.x, bot->botvec.y - bot->o.y)/PI*180+180;
        if(bot->yaw<bot->botrot.y-180.0f) bot->yaw += 360.0f;
        if(bot->yaw>bot->botrot.y+180.0f) bot->yaw -= 360.0f;
	    float dist = bot->o.dist(bot->botvec);
		bot->botrot.x = bot->pitch = asin((bot->botvec.z - bot->o.z) / dist) / RAD; 
	}

	void bothome(fpsent *bot, vec &v, int trans, int wp)
	{
		//conoutf ("%s homing vector %f,%f,%f", bot->name, v.x, v.y, v.z);

		bot->botlastnode = bot->botcurnode;
		bot->botcurnode = wp;

		bot->botvec.sub(bot->botvec);
		bot->botvec.add(v);

		botvector(bot);
		
		if (trans)
		{
			bot->botstart = cl.lastmillis;
			bottrans(bot, M_HOME, 1, 0, true, trans);
		}
	}
	
	bool botenemy(fpsent *bot, fpsent *p, bool attacked)
	{
		if ((p) && (bot!=p) && (p->state==CS_ALIVE))
		{
			vec target;

			//conoutf ("%s making enemy of %s", bot->name, p->name);

			if (insight(bot, p->o, target, BOTLOSDIST(bot->botrate)))
			{
				bothome(bot, target, 0, -1);
				bottrans(bot, M_AIMING, (bot->o.dist(p->o) > BOTBACKDIST ? 1 : -1), BOTRNDMOVE(bot->botrate), true, (attacked ? 50 : 100));

				//conoutf ("%s aiming at %s", bot->name, p->name);
				
				return true;
			}
			else if (attacked)
			{
				bothome(bot, target, 250, -1);
			}
		}
		return false;
	}

	bool bottarget(fpsent *bot)
	{
		vec target;
		float dist[3], c;
		int a = -1, b, lvl = -1, targ[3], amt[3];

		//conoutf ("%s looking for target", bot->name);
		
		#define inittarg(n) \
					lvl++; \
					dist[lvl] = 99999.f; \
					targ[lvl] = -1; \
					amt[lvl] = n;

		#define disttarg(q,r) \
					if (insight(bot, q, target, BOTLOSDIST(bot->botrate)) && q.dist(bot->o) < dist[lvl] && q.dist(bot->o) > bot->radius*2) \
					{ \
						dist[lvl] = q.dist(bot->o); \
						targ[lvl] = r; \
					}

		inittarg(1); // 0
		if (cl.player1->state==CS_ALIVE && bot!=cl.player1)
		{
			disttarg(cl.player1->o,0);
		}

		inittarg(cl.players.length()); // 1
		loopv(cl.players)
		{
			if (cl.players[i]->state==CS_ALIVE && bot!=cl.players[i])
			{
				disttarg(cl.players[i]->o,i);
			}
		}

		inittarg(cl.ms.monsters.length()); // 2
		loopv(cl.ms.monsters)
		{
			if (cl.ms.monsters[i]->state==CS_ALIVE)
			{
				disttarg(cl.ms.monsters[i]->o,i);
			}
		}
		
		for (lvl = 0, c = 99999.f; lvl <= 2; lvl++)
		{
			if ((targ[lvl] >= 0) && (targ[lvl] < amt[lvl]) && (dist[lvl] > bot->radius*2) && (dist[lvl] < c))
			{
				a = lvl;
				c = dist[lvl];
			}
		}

		if ((a >= 0) && (a <= 2))
		{
			b = targ[a];
			
			//conoutf ("%s target %d (%d/%d) selected [%f].", bot->name, a, b, amt[a], dist[a]);
			
			switch (a)
			{
				case 0:
					{
						return botenemy(bot, cl.player1, false);
						break;
					}
				case 1:
					{
						return botenemy(bot, cl.players[b], false);
						break;
					}
				case 2:
					{
						return botenemy(bot, cl.ms.monsters[b], false);
						break;
					}
				default:
					break;
			}
		}
		else
		{
			//conoutf ("%s got no target", bot->name);
		}
		return false;
	}

	void botspawn(fpsent *bot)
	{
		if (bot->state!=CS_ALIVE)
		{
	        bot->botvec.sub(bot->botvec);
	        bot->botcurnode = bot->botlastnode = -1;
			//conoutf ("%s is now spawning", bot->name);
			cl.spawnplayer(bot);
			entinmap(bot);
		}
	    bottrans(bot, M_SLEEP, 0, 0, true, 250);
	}


	void botaim(fpsent *bot)
	{
		if (bot->yaw == bot->botrot.y)
		{
			//conoutf ("%s aimed at %f,%f,%f", bot->name, bot->botvec.x, bot->botvec.y, bot->botvec.z);
        	bottrans(bot, M_ATTACKING, (bot->o.dist(bot->botvec) > BOTBACKDIST ? 1 : -1), BOTRNDMOVE(bot->botrate), true, 25); // that's it, we're committed
		}
	}

	void botattack(fpsent *bot)
	{
		vec target;
		//conoutf ("%s is attacking %f,%f,%f", bot->name, bot->botvec.x, bot->botvec.y, bot->botvec.z);
		hitvec(bot->o, bot->botvec, target);
        bot->lastaction = 0;
        bot->attacking = true;
        cl.ws.shoot(bot, target);
        bot->attacking = false;
		bothome(bot, target, 0, -1);
	    bottrans(bot, M_SLEEP, (bot->o.dist(bot->botvec) > BOTBACKDIST ? 1 : -1), BOTRNDMOVE(bot->botrate), true, bot->gunwait);
	}

	void botmove(fpsent *bot, int n, bool d)
	{
		//if(bot->move || bot->strafe || bot->state==CS_DEAD)
		//{
			//bot->type = ENT_AI; // fool the physics routines
			moveplayer(bot, n, d); // using physics to move and detect
			//bot->type = ENT_PLAYER; // so we're normal again
		//}
	}

	int botwaypoint(int x, int y, int z, bool node)
	{
		int n = waypoints.length();
		botway *e = new botway;
		vec p(x, y, z);

		e->pos.sub(e->pos);
		e->pos.add(p);
		e->nodes.setsize(0);
		
		waypoints.add(e);

		if (node)
		{
			if (waypoints.inrange(n))
			{
				if (waypoints.inrange(waylast))
					botwaynodeadd(waylast, n);
				waylast = n;
			}
		}

		//conoutf ("waypoint placed at %f,%f,%f", e->pos.x, e->pos.y, e->pos.z);
						
		return n;
	}

	bool botwayconnect (int a, int b)
	{
		if (a != b && waypoints.inrange(a) && waypoints.inrange(b))
		{
			loopv(waypoints[a]->nodes)
			{
				if (waypoints[a]->nodes[i] == b)
					return true;
			}
		}
		return false;
	}
	
	void botwaynodes()
	{
		execute("botshow 1; botdrop 1");
		
    	loopv(cl.et.ents)
    	{
			int t = cl.et.ents[i]->type;
			
			if ((t >= I_SHELLS && t <= TELEPORT) || t == JUMPPAD || t == BASE)
				botwaypoint((int)cl.et.ents[i]->o.x, (int)cl.et.ents[i]->o.y, (int)cl.et.ents[i]->o.z, false);
		}
		conoutf ("generated %d waypoint(s) without nodes from %d ent(s)", waypoints.length(), cl.et.ents.length());
	}

	void botwayclear()
	{
		loopv(waypoints)
		{
			loopvj(waypoints[i]->nodes)
			{
				waypoints[i]->nodes.remove(j);
			}
			waypoints[i]->nodes.setsize(0);
			DELETEP(waypoints[i]);
		}
		waypoints.setsize(0);
	}

	int botwaycurnode(fpsent *bot, bool any)
	{
		int w = -1;
		vec target;
		
		loopv(waypoints)
		{
			if ((any || (waypoints[i]->pos.dist(bot->o) < WAYPOINTDIST && inlos (bot->o, waypoints[i]->pos, target))) && (!waypoints.inrange(w) || waypoints[i]->pos.dist(bot->o) < waypoints[w]->pos.dist(bot->o)))
			{
				w = i;
			}
		}
		return w;
	}

	int botwaynodeadd(int n, int m)
	{
		if (waypoints.inrange(n) && waypoints.inrange(m))
		{
			vec target;
			if (n != m && !botwayconnect(n, m))
			{
				if (inlos (waypoints[n]->pos, waypoints[m]->pos, target))
				{
					waypoints[n]->nodes.add(m);
					//waypoints[m]->nodes.add(n);
					//conoutf("waypoint node %d connected with %d", n, m);
				}
				else
				{
					// no line of sight, try connecting with different nodes
					int w = -1;
					
					vec t(0, 0, 0), v(0, 0, 0), r(0, 0, 0);
						
					t.add(waypoints[m]->pos);
					t.sub(waypoints[n]->pos);

					v.add(t);
					v.mul(0.5);

					r.add(waypoints[n]->pos);
					r.add(v);
					
					loopv(waypoints)
					{
						if (i != n && i != m && !botwayconnect(n, m) && waypoints[i]->pos.dist(r) < WAYPOINTDIST*2 && (!waypoints.inrange(w) || waypoints[i]->pos.dist(r) < waypoints[w]->pos.dist(r)))
						{
							if (inlos (waypoints[n]->pos, waypoints[i]->pos, target) && inlos (waypoints[m]->pos, waypoints[i]->pos, target))
							{
								w = i;
							}
						}
					}
					if (waypoints.inrange(w))
					{
						botwaynodeadd(n, w);
						botwaynodeadd(w, m);
					}
					else
					{
						// gee, that sucks, can we make a node to connect them both?
						loopi(6)
						{
							v.sub(v);
							v.add(t);
							
							if (i == 1 || i == 2 || i == 5)
								v.x = 0.0;
							if (i == 0 || i == 2 || i == 4)
								v.y = 0.0;
							if (i == 0 || i == 1 || i == 3)
								v.x = 0.0;
							
							r.sub(r);
							r.add(waypoints[n]->pos);
							r.add(v);

							if (inlos (waypoints[n]->pos, r, target) && inlos (waypoints[m]->pos, r, target))
							{
								w = botwaypoint((int)r.x, (int)r.y, (int)r.z, false);
								
								if (waypoints.inrange(w))
								{
									botwaynodeadd(n, w);
									botwaynodeadd(w, m);
								}
								break;
							}
						}
					}
				}
			}
		}
	}

	int botgetint(gzFile f)
	{
		int t;
	    gzread(f, &t, sizeof(int));
        endianswap(&t, sizeof(int), 1);
        return t;
	}
	
	void botputint(gzFile f, int x)
	{
		int t = (int)x;
       	endianswap(&t, sizeof(int), 1);
	   	gzwrite(f, &t, sizeof(int));
	}

	bool botwayload()
	{
	    gzFile f = gzopen(wayname, "rb9");
	    if(f)
		{
			bool ans = false;
	
			char head[4];
			int version;
	
		    gzread(f, &head, 4);
		    version = botgetint(f);
		    			
			if (!strncmp(head, "WAYP", 4) && version <= WAYPOINTVER)
			{
				int ways, x, y, z;
				
				ways = botgetint(f); // number of waypoints
				
				loopi(ways) // load waypoint positions
				{
					x = botgetint(f);
					y = botgetint(f);
					z = botgetint(f);
					botwaypoint(x, y, z, false);
				}					
				
				loopi(ways) // load waypoint node connections
				{
					x = botgetint(f); // number of nodes
					
					loopj(x)
					{
						y = botgetint(f); // node waypoint number

						waypoints[i]->nodes.add(y);
					}
				}
				ans = true;
				conoutf("loaded %d waypoint(s) from %s", waypoints.length(), wayname);
			}
			gzclose(f);
			return ans;
		}
		conoutf("could not load waypoint file %s", wayname);
		
		return false;
	}

	bool botwaysave()
	{
	    gzFile f = gzopen(wayname, "wb9");
	    if(f)
		{
			char head[4];
			int version;
	
		    strncpy(head, "WAYP", 4);
			gzwrite(f, &head, 4);
			botputint(f, WAYPOINTVER);
						
			botputint(f, waypoints.length());

			loopv(waypoints)
			{
				botputint(f, waypoints[i]->pos.x);
				botputint(f, waypoints[i]->pos.y);
				botputint(f, waypoints[i]->pos.z);
			}
			loopv(waypoints)
			{
				botputint(f, waypoints[i]->nodes.length());
				
				loopvj(waypoints[i]->nodes)
				{
					botputint(f, waypoints[i]->nodes[j]);
				}
			}
			
			conoutf("saved %d waypoint(s) to %s", waypoints.length(), wayname);

			gzclose(f);
			return true;
		}
		conoutf("could not save waypoint file %s", wayname);
		return false;
	}

	bool botcoord(fpsent *bot, int retry)
	{
		int c = (retry == 0 && waypoints.inrange(bot->botcurnode) ? bot->botcurnode : botwaycurnode(bot, retry > 1)), r = -1;
		
		//conoutf("%s looking for waypoint (retries: %d)", bot->name, retry);
		
		if (waypoints.inrange(c))
		{
			int q = waypoints[c]->nodes.length();

			//conoutf("%s is in node %d", bot->name, c);

			if (q > 1)
			{
				int n = rnd(q);
				
				//conoutf("%s is trying a random node", bot->name);
	
				// try a random node
				if (waypoints[c]->nodes.inrange(n) && waypoints[c]->nodes[n] != bot->botcurnode && waypoints[c]->nodes[n] != bot->botlastnode)
				{
					r = waypoints[c]->nodes[n];
				}
				else
				{
					// resort to a loop and find one
					for (n = 0; n < q; n++)
					{
						if (waypoints[c]->nodes.inrange(n) && waypoints[c]->nodes[n] != bot->botcurnode && waypoints[c]->nodes[n] != bot->botlastnode)
						{
							r = waypoints[c]->nodes[n];
							break;
						}
					}
				}
			}
			else if (q > 0)
			{
				r = waypoints[c]->nodes[0]; // looks like there's only one choice
			}
		}

		if (waypoints.inrange(r))
		{
			//conoutf("%s attempting home on %d", bot->name, r);
			bothome(bot, waypoints[r]->pos, 500, r);
			
			return true;
		}
		else if (retry > 2)
		{
			//conoutf("%s attempting to backtrack to %d", bot->name, bot->botlastnode);
			if (waypoints.inrange(bot->botlastnode))
				bothome(bot, waypoints[bot->botlastnode]->pos, 500, bot->botlastnode); // backtrack
			
			return true;
		}
		else
		{
			//conoutf("%s attempting to get coordinates another way", bot->name);
			return botcoord(bot, retry+1);
		}

		return false;
	}

    void botaction(fpsent *bot, int curtime)
    {
		if(bot->botms<cl.lastmillis)
        {
			//conoutf ("%s doing action %d", bot->name, bot->botstate);

    		switch(bot->botstate)
    		{
				case M_PAIN:
            		{
						botspawn(bot);
					}
					break;

        		case M_SLEEP:
					{
						if (!bottarget(bot))
						    bottrans(bot, M_SEARCH, 1, 0, true, 100);
					}

        		case M_SEARCH:
					{
						if (!bottarget(bot))
						{
							if (!botcoord(bot, 0))
							    bottrans(bot, M_SEARCH, BOTRNDMOVE(bot->botrate), BOTRNDMOVE(bot->botrate), true, 250);
						}
					}
					break;

				case M_HOME:
					{
						bot->botlastnode = bot->botcurnode;
						bot->botcurnode = -1;
						
						if (!bottarget(bot))
						    bottrans(bot, M_SEARCH, BOTRNDMOVE(bot->botrate), BOTRNDMOVE(bot->botrate), true, 250);
					}
					break;

        		case M_AIMING:
					{
						botaim(bot);
					}
					break;
        
                case M_ATTACKING:
					{
						botattack(bot);
					}
					break;

				default:
					break;
            }
		}
    }

	void botwaypos()
	{
        if (BOTALLOWED)
        {
			if (cl.player1->state == CS_ALIVE)
			{
				if (botdrop())
				{
					bool inode = false;
					
					loopv(waypoints)
					{
						if (waypoints[i]->pos.dist(cl.player1->o) < WAYPOINTDIST)
						{
							if (i != waylast)
							{
								if (waypoints.inrange(waylast))
									botwaynodeadd(waylast, i);
									
								waylast = i;
							}
							inode = true;
						}
					}
					if (!inode)
						botwaypoint((int)cl.player1->o.x, (int)cl.player1->o.y, (int)cl.player1->o.z, true);
				}
			}
			else
				waylast = -1;
		}
	}

	void botclear()
	{
        if (BOTALLOWED)
        {
			loopv(cl.players)
	      		DELETEP(cl.players[i]);
	
			cl.players.setsize(0);
			cleardynentcache();
	
	        bottotal = 0;
	        
			botwayclear();
	
			execute("botshow 0; botdrop 0");
		}
	}

	void botstart(char *map, int gamemode)
	{
        if (BOTALLOWED)
        {
	        if (*map) // otherwise we may be editing..
	        {
				botnames(map);
				
				if (!botwayload())
					botwaynodes();

				if (botauto())
    	    		botadd(-1, -1);
			}
		}
	}

	void bottime()
	{
		// um..
	}

	void botrender()
	{
		if (cl.player1->state == CS_EDITING || botshow())
		{
			loopv(waypoints) // purrty waypoints
			{
				vec target, ;
		
				if (inlos (cl.player1->o, waypoints[i]->pos, target))
				{
					int red = 0, blue = 0;
					string wp;
		
					loopvj(cl.players)
					{
						if (cl.players[j]->state == CS_ALIVE && cl.players[j]->botstate != M_NONE)
						{
							if (i == cl.players[j]->botcurnode)
							{
								blue++;
							}
							else if (i == cl.players[j]->botlastnode)
							{
								red++;
							}
						}
					}
					
  					s_sprintf(wp)("@waypoint (%d)", i);
	    	        particle_text(waypoints[i]->pos, wp, (red || blue ? (red > blue ? 13 : 16) : 14), 1);
		    	    particle_splash((red || blue ? (red > blue ? 3 : 2) : 0), 2, 50, waypoints[i]->pos);

					loopvj(waypoints[i]->nodes)
					{
						int y = waypoints[i]->nodes[j];
						
						if (waypoints.inrange(y))
							particle_flare(waypoints[i]->pos, waypoints[y]->pos, 1);
					}
				}
			}
		}
	}
};

