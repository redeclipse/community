// ai.h - training or test players for tesseract

struct aiset
{
    fpsclient &cl;
    vector<extentity *> &ents;
    
    aiset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents)
	{
        CCOMMAND(aiset, aiadd, "ii", { int num = (args[0][0] ? atoi(args[0]) : -1); int ar = (args[1][0] ? atoi(args[1]) : -1); self->aiadd(num, ar); });
        CCOMMAND(aiset, aidel, "i", { int num = (args[0][0] ? atoi(args[0]) : -1); self->aidel(num); });
	};
    
    int aitotal;

    IVAR(airate, 0, 50, 100);
    IVAR(ainum, 0, 0, 256); // arbitrary limit
    IVAR(aiload, 0, 0, 1); // load on start of map

	void aiadd(int num, int ar)
	{ dbg;
		if (m_mp(cl.gamemode) && !cl.cc.remote)
		{ dbg;
			int n = (num >= 0 ? num : ainum()), s = (ar >= 0 ? ar : airate());
			
			if (n == 0)
			{ dbg;
				int r = 0;
				loopv(ents) if (ents[i]->type == PLAYERSTART)
				{ dbg;
					r++;
				}
				n = max(r / 3,1);
				
			}
			
			if (n <= 0)
				return;

	        while (n > 0)
            { dbg;
               	fpsent *ai = new fpsent();

           		aitotal++;

		        s_sprintf(ai->name)("ai_%02d", aitotal);
		        if (num%2)
		        { dbg;
		        	s_sprintf(ai->team)("red");
				}
				else
				{ dbg;
		        	s_sprintf(ai->team)("blue");
				}
				ai->state = CS_DEAD;
		        ai->aistate = M_SLEEP;
		        ai->move = ai->strafe = 0;
				ai->airate = (s < 0 ? 0 : (s > 100 ? 100 : s));
				ai->aims = cl.lastmillis+(1000*aitotal);
				
              	cl.players.add(ai);

		        conoutf("connected: %s (team: %s, rate: %d)", ai->name, ai->team, ai->airate);

               	n--;
			}
		}
		else
			conoutf("addai is only available in offline multiplayer games");
	}

	void aidel(int num)
	{ dbg;
		if (m_mp(cl.gamemode) && !cl.cc.remote)
		{ dbg;
			if (aitotal <= 0) return;

			int n = (num >= 0 ? num : 1);
			
			if (n == 0 || n > aitotal)
			{ dbg;
				n = aitotal;
			}	
			
	        loopv (cl.players) if (cl.players[i]->aistate != M_NONE)
            { dbg;
            	aitotal--;
            	conoutf("ai %s disconnected", cl.players[i]->name);
            	DELETEP(cl.players[i]);
				n--;
				if (n <= 0 || aitotal <= 0)
					break;
			}
		}
		else
			conoutf("delai is only available in offline multiplayer games");
	}

    void aithink(fpsent *ai, int curtime, int gamemode)
    { dbg;
        if(cl.intermission || editmode) return;
        
        if(ai->state==CS_ALIVE)
        { dbg;
	        cl.et.checkquad(ai, curtime);
        	cl.et.checkitems (ai);
            if (tessmap) cl.et.checkregions (ai);
        }
        else
        { dbg;
            ai->move = ai->strafe = 0;

            if(cl.lastmillis-ai->lastaction<2000)
            { dbg;
                moveplayer(ai, 2, false);
            }

            if (ai->aistate!=M_SLEEP)
                aitrans(ai, M_SLEEP, 1, 400, 800);
        }
       	aiaction(ai, curtime);
		ai->lastupdate = cl.lastmillis;
    };

    bool inlos(vec &o, vec &q, vec &v)
    { dbg;
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
        return distance >= mag; 
    };

    void hitvec(vec &o, vec &q, vec &v)
    { dbg;
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
    };

    void aitrans(fpsent *ai, int st, int mv, int n, int r)
    { dbg;
        ai->move = mv;
    	if (ai->aistate != st)
    	{ dbg;
			int v = n + (r > n ? rnd((r-n)+(ai->airate*10)) : (ai->airate > 0 ? rnd(ai->airate*10) : 0));
        	ai->aistate = st;
        	ai->aims = cl.lastmillis + v;
        	//conoutf ("%s [%f,%f,%f] transition to %d [%d] (%d[%d]:%d:%d)", ai->name, ai->o.x, ai->o.y, ai->o.z, ai->aistate, ai->move, n, r, v, ai->aims);
		}
    };

	void aivector(fpsent *ai, vec &v)
	{ dbg;
		ai->aivec = vec (v.x, v.y, v.z);
		ai->airot.y = -(float)atan2(ai->aivec.x - ai->o.x, ai->aivec.y - ai->o.y)/PI*180+180;
        while(ai->rot.y<ai->airot.y-180.0f) ai->rot.y += 360.0f;
        while(ai->rot.y>ai->airot.y+180.0f) ai->rot.y -= 360.0f;
	    float dist = ai->aivec.dist(ai->o);
		ai->airot.x = ai->rot.x = asin((ai->aivec.z - ai->o.z) / dist) / RAD; 
		//conoutf ("%s [%f,%f,%f] ai %f targetvec %f,%f,%f", ai->name, ai->o.x, ai->o.y, ai->o.z, ai->airot.y, ai->aivec.x, ai->aivec.y, ai->aivec.z);
	}

	void aihome(fpsent *ai, vec &v)
	{ dbg;
		//conoutf ("%s [%f,%f,%f] vector %f,%f,%f", ai->name, ai->o.x, ai->o.y, ai->o.z, v.x, v.y, v.z);
		aivector(ai, v);
		ai->aistart = cl.lastmillis;
		aitrans(ai, M_HOME, 1, 100, 250);
	}
	
	void aicoord(fpsent *ai)
	{ dbg;
		vec m(ai->o.x, ai->o.y, ai->o.z), v, t, targ, old(ai->o.x, ai->o.y, ai->o.z);
		int myaw, mdist;

		//conoutf ("%s [%f,%f,%f] obtaining coordinates", ai->name, ai->o.x, ai->o.y, ai->o.z);

		for (myaw = 0; myaw < 8; myaw++)
		{ dbg;
			float zx = ((myaw >= 1 && myaw <= 3) ? 1.0f : ((myaw >= 5 && myaw <= 7) ? -1.0f : 0.0f));
			float zy = ((myaw >= 0 && myaw <= 1) || (myaw >= 6 && myaw <= 7) ? 1.0f : ((myaw >= 3 && myaw <= 6) ? -1.0f : 0.0f));
			float zz;
			bool done = false;
		    v.x = zx;
			v.y = zy;

			for (mdist = 0, zz = 0.0f; !done && mdist < 128; )
			{ dbg;
				mdist++;
    			for (; !done && zz <= 10.0f; zz += 1.0f)
				{ dbg;
					ai->o = vec(old.x + (v.x * mdist), old.y + (v.y * mdist), old.z + zz);
					
					extern bool inside;
					if (!collide(ai) || inside || ai->blocked)
					{ dbg;
						done = true;
					}
					ai->blocked = false;
				}
			}
			v.mul(mdist);

			t = vec(old.x + v.x, old.y + v.y, old.z + zz);
			
			if (old.dist(t) >= old.dist(m))
			{ dbg;
				m = vec(t.x, t.y, t.z);
			}
		}
		ai->o = vec(old.x, old.y, old.z);
		
		aihome(ai, m);
	}

	void aisearch(fpsent *ai)
	{ dbg;
		//conoutf ("%s [%f,%f,%f] blocked", ai->name, ai->o.x, ai->o.y, ai->o.z);

		vec dir;
		vec old(ai->o.x, ai->o.y, ai->o.z);
		
		vecfromyawpitch (ai->rot.y, ai->rot.x, ai->move, ai->strafe, dir, false);
		dir.mul(10.0f);
		ai->o.z += 6.0f;
		ai->o.add(dir);
		
		extern bool inside;
	    if((ai->aivec.z-ai->o.z >= 10.0f) || (collide(ai) && !inside && !ai->blocked))
	    { dbg;
			//conoutf ("%s [%f,%f,%f] jump (%s,%s)", ai->name, ai->o.x, ai->o.y, ai->o.z, (inside ? "inside" : "outside"), (ai->blocked ? "blocked" : "look"));

			ai->o = vec(old.x, old.y, old.z);
			ai->jumpnext = true;
			return;
		}
		ai->o = vec(old.x, old.y, old.z);
		ai->blocked = false;
   		aicoord (ai);
	}

	void aienemy(fpsent *ai, fpsent *p)
	{ dbg;
		if ((p) && (ai!=p) && (p->state==CS_ALIVE))
		{ dbg;
			vec target;
			if (inlos(ai->o, p->o, target))
			{ dbg;
				aivector (ai, target);
				aitrans(ai, M_AIMING, (ai->o.dist(target) > 8 ? 1 : -1), 25, 50);

				//conoutf ("%s [%f,%f,%f] aiming at %s", ai->name, ai->o.x, ai->o.y, ai->o.z, p->name);
			}
			else
			{ dbg;
				aihome(ai, p->o);
			}
		}
		else
		{ dbg;
			aitarget(ai, true);
		}
	}

	void aitarget(fpsent *ai, bool all)
	{ dbg;
		vec target;
		float dist[5], c;
		int a = -1, b, lvl = -1, targ[5], amt[5];

		//conoutf ("%s [%f,%f,%f] looking for target", ai->name);
		
		#define inittarg(n) dbg; \
					lvl++; \
					dist[lvl] = 99999.9f; \
					targ[lvl] = -1; \
					amt[lvl] = n;

		#define disttarg(q,r) dbg; \
					if (inlos(ai->o, q, target)) \
					{ \
						if (ai->o.dist(q) < dist[lvl] && ai->o.dist(q) > ai->radius) \
						{ \
							dist[lvl] = ai->o.dist(q); \
							targ[lvl] = r; \
						} \
					}

		inittarg(1); // 0
		if (cl.player1->state==CS_ALIVE && ai!=cl.player1)
		{ dbg;
			disttarg(cl.player1->o,0)
			dist[lvl] = (ai->airate == 0 ? dist[lvl]*(0.25f*0.02f) : dist[lvl]*(ai->airate*0.02f));
		}

		inittarg(cl.players.length()); // 1
		loopv(cl.players)
		{ dbg;
			if (cl.players[i]->state==CS_ALIVE && ai!=cl.players[i])
			{ dbg;
				disttarg(cl.players[i]->o,i);
			}
		}

		inittarg(cl.ms.monsters.length()); // 2
		loopv(cl.ms.monsters)
		{ dbg;
			if (cl.ms.monsters[i]->state==CS_ALIVE)
			{ dbg;
				disttarg(cl.ms.monsters[i]->o,i);
			}
		}

		inittarg(cl.et.ents.length()); // 3
		if (all)
		{ dbg;
			loopv(cl.et.ents)
			{ dbg;
				if (cl.et.ents[i]->spawned)
				{ dbg;
					int etype = cl.et.ents[i]->type;
					if ((etype == TELEPORT) || (etype == JUMPPAD) || (etype == I_BOOST) || (etype == I_QUAD) || (ai->health < ai->maxhealth && etype == I_HEALTH))
					{ dbg;
						disttarg(cl.et.ents[i]->o,i);
					}
				}
			}
			dist[lvl] *= 0.9f; // increase fondness a little
		}
		inittarg(0);
		
		for (lvl = 0, c = 99999.9f; lvl <= (all ? 3 : 2); lvl++)
		{ dbg;
			if ((targ[lvl] >= 0) && (targ[lvl] < amt[lvl]) && (dist[lvl] < c))
			{ dbg;
				a = lvl;
				c = dist[lvl];
			}
		}

		if ((a >= 0) && (a <= (all ? 3 : 2)))
		{ dbg;
			b = targ[a];
			
			//conoutf ("%s [%f,%f,%f] target %d (%d/%d) selected [%f].", ai->name, ai->o.x, ai->o.y, ai->o.z, a, b, amt[a], dist[4]);
			
			dbg;
			switch (a)
			{
				case 0:
					{
						dbg aienemy(ai, cl.player1); return;
						break;
					}
				case 1:
					{
						dbg aienemy(ai, cl.players[b]); return;
						break;
					}
				case 2:
					{
						dbg aienemy(ai, cl.ms.monsters[b]); return;
						break;
					}
				case 3:
					{
						dbg aihome(ai, ents[b]->o); return;
						break;
					}
				default:
					break;
			}
		}
		if (all)
		{ dbg;
			//conoutf ("%s [%f,%f,%f] target %d was invalid, searching.", ai->name, ai->o.x, ai->o.y, ai->o.z, a);
			aicoord(ai);
		}
	}

	void aispawn(fpsent *ai)
	{ dbg;
		if (ai->state!=CS_ALIVE)
		{ dbg;
			//conoutf ("%s [%f,%f,%f] is now spawning", ai->name);
			cl.spawnplayer(ai);
			ai->state = CS_ALIVE;
            ai->aivec = vec(0, 0, 0);
			//conoutf ("%s spawned at %f,%f,%f [%f,%f,%f]", ai->name, ai->o.x, ai->o.y, ai->o.z, cl.player1->o.x, cl.player1->o.y, cl.player1->o.z);
		}
	    aitarget(ai, true);
	}


	void aiaim(fpsent *ai)
	{ dbg;
		if (ai->rot.y == ai->airot.y)
		{ dbg;
			//conoutf ("%s [%f,%f,%f] aimed at %f,%f,%f", ai->name, ai->o.x, ai->o.y, ai->o.z, ai->aivec.x, ai->aivec.y, ai->aivec.z);
        	aitrans(ai, M_ATTACKING, (ai->o.dist(ai->aivec) > 4 ? 1 : -1), 25, 50); // that's it, we're committed
		}
	}

	void aiattack(fpsent *ai)
	{ dbg;
		vec target;
		//conoutf ("%s [%f,%f,%f] is attacking %f,%f,%f", ai->name, ai->o.x, ai->o.y, ai->o.z, ai->aivec.x, ai->aivec.y, ai->aivec.z);
		hitvec(ai->o, ai->aivec, target);
        ai->lastaction = 0;
        ai->attacking = true;
        cl.ws.shoot(ai, target);
        ai->attacking = false;
		aivector(ai, target);
	    aitrans(ai, M_SEARCH, -1, ai->gunwait, ai->gunwait+50); //backpedal
	}

    void aiaction(fpsent *ai, int curtime)           // main AI thinking routine, called every frame for every ai
    { dbg;
    	if (ai->state==CS_ALIVE)
    	{ dbg;
			float bk = (ai->airate == 0 ? 1.0f : 1.0f + (ai->airate/100.0f));
			
		    if(ai->airot.y>ai->rot.y)             // slowly turn ai towards his target
            { dbg;
                ai->rot.y += (curtime*0.25f)/bk;
                if(ai->airot.y<ai->rot.y) ai->rot.y = ai->airot.y;
            }
            else
            { dbg;
                ai->rot.y -= (curtime*0.25f)*bk;
                if(ai->airot.y>ai->rot.y) ai->rot.y = ai->airot.y;
            };

            if(ai->blocked)                                                              // special case: if we run into scenery
            { dbg;
                if ((ai->aistate == M_AIMING) || (ai->aistate == M_ATTACKING))
                { dbg;
					ai->move = -ai->move; // go the other way then
				}
				else
				{ dbg;
					aisearch(ai);
				}
                ai->blocked = false;
            };
		}
        if(ai->aims<cl.lastmillis)
        { dbg;
			//conoutf ("%s [%f,%f,%f] action: (%d<%d) %d", ai->name, ai->o.x, ai->o.y, ai->o.z, ai->aims, cl.lastmillis, ai->aistate);

    		switch(ai->aistate)
    		{
				case M_SLEEP:
            		{ dbg;
						aispawn(ai);
					}
					break;

				case M_HOME:
					{ dbg;
       		        	if (ai->state==CS_ALIVE)
       		        	{ dbg;
							if (ai->o.dist(ai->aivec) <= 5.0f || cl.lastmillis-ai->aistart > 2500) // either near there or taking too long
							{ dbg;
								aitarget(ai, true);
							}
							else
							{ dbg;
								aitrans(ai, M_HOME, 1, 25, 50);
								aitarget(ai, false);
							}
						}
					}
					break;
        		case M_SEARCH:
					{ dbg;
       		        	if (ai->state==CS_ALIVE)
							aitarget(ai, true);
					}
					break;

        		case M_AIMING:
					{ dbg;
      		        	if (ai->state==CS_ALIVE)
							aiaim(ai);
					}
					break;
        
                case M_ATTACKING:
					{ dbg;
       		        	if (ai->state==CS_ALIVE)
							aiattack(ai);
					}
					break;
				default:
					break;
            };
		}
       	if (ai->state==CS_ALIVE)
       	{ dbg;
			if(ai->move || ai->moving)
			{ dbg;
				moveplayer(ai, 2, true);        // use physics to move ai
			}
		}
    };

    void aipain(fpsent *ai, int damage, fpsent *d)
    { dbg;
        if(d && ai!=d)
        { dbg;
            aienemy(ai, d);
        };

        if((ai->health -= damage)<=0)
        { dbg;
            ai->state = CS_DEAD;
            ai->lastaction = cl.lastmillis;
            playsound(S_DIE1, &ai->o);

            if (d)
			{ dbg;
				d->frags++;
				if (d == cl.player1)
					conoutf("you fragged %s", ai->name);
				else
					conoutf("%s fragged %s", d->name, ai->name);
			}	
            else
			{ dbg;
				conoutf("%s suicided", ai->name);
				ai->frags--;
			}
			ai->deaths++;
        }
        else
        { dbg;
            playsound(S_PAINO, &ai->o);
        };
    };
};

