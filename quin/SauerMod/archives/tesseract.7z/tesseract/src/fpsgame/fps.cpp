// clientgame.cpp: core game related stuff

#include "pch.h"

#include "cube.h"

#include "iengine.h"
#include "igame.h"

#include "game.h"

#include "fpsserver.h"

#ifndef STANDALONE
VARP(weaponcycle, 0, 1, 1);

struct fpsclient : igameclient
{
    // these define classes local to fpsclient
    #include "weapon.h"
    #include "monster.h"
	#include "ai.h"
    #include "ball.h"
    #include "scoreboard.h"
    #include "fpsrender.h"
    #include "entities.h"
    #include "client.h"
    #include "capture.h"

    int nextmode, gamemode;         // nextmode becomes gamemode after next map load
    bool intermission;
    int lastmillis;
    string clientmap;
    int arenarespawnwait, arenadetectwait;
    int spawngun1, spawngun2;
    int maptime;
    int respawnent;

    fpsent *player1;                // our client
    vector<fpsent *> players;       // other clients, including ai
    fpsent lastplayerstate;

    weaponstate ws;
    monsterset  ms;
    aiset      as;
    ballset		bs;
    scoreboard  sb;
    fpsrender   fr;
    entities    et;
    clientcom   cc;
    captureclient cpc;

    fpsclient()
        : nextmode(0), gamemode(0), intermission(false), lastmillis(0),
          arenarespawnwait(0), arenadetectwait(0), maptime(0), respawnent(-1),
          player1(spawnstate(new fpsent())),
          ws(*this), ms(*this), as(*this), bs(*this), et(*this), cc(*this), cpc(*this)
    {
        CCOMMAND(fpsclient, mode, "s", { self->setmode(atoi(args[0])); });
        CCOMMAND(fpsclient, autopilot, "i", { self->autopilot(atoi(args[0])); });
    };

    iclientcom      *getcom()  { return &cc; };
    icliententities *getents() { return &et; };

    void setmode(int mode)
    { dbg;
        if(cc.remote && !m_mp(mode)) { conoutf("mode %d not supported in multiplayer", mode); return; };
        nextmode = mode;
        if(cc.currentmaster==cc.clientnum) cc.addmsg(1, 2, SV_GAMEMODE, nextmode);
    };

	void autopilot(int rate)
	{
		if (player1->aistate != M_NONE)
		{
	        player1->aistate = M_NONE;
	        player1->move = player1->strafe = 0;
			player1->airate = 0;
	        player1->aims = 0;
		}
		else
		{
	        player1->aistate = M_SEARCH;
	        player1->move = player1->strafe = 0;
			player1->airate = (rate < 0 ? 0 : (rate > 100 ? 100 : rate));
	        player1->aims = lastmillis;
		}
		
		conoutf("autopilot has been %s", (player1->aistate != M_NONE ? "enabled" : "disabled"));
	}
    
	char *getclientmap() { return clientmap; };

    void rendergame() { fr.rendergame(*this, gamemode); };

    void resetgamestate()
    { dbg;
        player1->health = player1->maxhealth;
        if(m_classicsp) ms.monsterclear(gamemode);                 // all monsters back at their spawns for editing
        bs.ballclear (gamemode);
        ws.projreset();
    };

    fpsent *spawnstate(fpsent *d)              // reset player state not persistent accross spawns
    { dbg;
        d->respawn();
        if(m_noitems || m_capture)
        { dbg;
            d->gunselect = GUN_RIFLE;
            d->armour = 0;
            if(m_noitemsrail)
            { dbg;
                d->health = 1;
                d->ammo[GUN_RIFLE] = 100;
            }
            else
            { dbg;
                d->health = 100;
                d->armour = 100;
                d->armourtype = A_GREEN;
                if(m_tarena || m_capture)
                { dbg;
                    d->ammo[GUN_PISTOL] = 80;
                    spawngun1 = rnd(5)+1;
                    et.baseammo(d, d->gunselect = spawngun1);
                    do spawngun2 = rnd(5)+1; while(spawngun1==spawngun2);
                    et.baseammo(d, spawngun2);
                    d->ammo[GUN_GL] += 5;
                }
                else if(m_arena)    // insta arena
                { dbg;
                    d->ammo[GUN_RIFLE] = 100;
                }
                else // efficiency
                { dbg;
                    loopi(5) et.baseammo(d, i+1);
                    d->gunselect = GUN_CG;
                };
                d->ammo[GUN_CG] /= 2;
            };
        }
        else
        { dbg;
            d->ammo[GUN_PISTOL] = m_sp ? 80 : 40;
            d->ammo[GUN_GL] = 5;
        };
        return d;
    };

    void respawnself()
    { dbg;
        spawnplayer(player1);
        sb.showscores(false);
    };

    fpsent *pointatplayer()
    { dbg;
        extern vec worldpos;
        loopv(players)
        { dbg;
            fpsent *o = players[i];
            if(!o) continue;
            if(intersect(o, player1->o, worldpos)) return o;
        };
        return NULL;
    };

    void arenacount(fpsent *d, int &alive, int &dead, char *&lastteam, bool &oneteam)
    { dbg;
        if(d->state==CS_SPECTATOR) return;
        if(d->state!=CS_DEAD)
        { dbg;
            alive++;
            if(lastteam && strcmp(lastteam, d->team)) oneteam = false;
            lastteam = d->team;
        }
        else
        { dbg;
            dead++;
        };
    };

    void arenarespawn()
    { dbg;
        if(arenarespawnwait)
        { dbg;
            if(arenarespawnwait<lastmillis)
            { dbg;
                arenarespawnwait = 0;
                conoutf("\f2new round starting... fight!");
                playsound(S_V_FIGHT);
                if(!cc.spectator) respawnself();
            };
        }
        else if(arenadetectwait==0 || arenadetectwait<lastmillis)
        { dbg;
            arenadetectwait = 0;
            int alive = 0, dead = 0;
            char *lastteam = NULL;
            bool oneteam = true;
            arenacount(player1, alive, dead, lastteam, oneteam);
            loopv(players) if(players[i]) arenacount(players[i], alive, dead, lastteam, oneteam);
            if(dead>0 && (alive<=1 || (m_teammode && oneteam)))
            { dbg;
                conoutf("\f2arena round is over! next round in 5 seconds...");
                if(alive) conoutf("\f2team %s is last man standing", lastteam);
                else conoutf("\f2everyone died!");
                arenarespawnwait = lastmillis+5000;
                arenadetectwait  = lastmillis+10000;
                player1->rot.z = 0;
            };
        };
    };

    void otherplayers(int curtime)
    { dbg;
        loopv(players) if(players[i])
        { dbg;
        	if (players[i]->aistate != M_NONE)
        	{
		        as.aithink(players[i], curtime, gamemode);
			}
			else
			{
	            const int lagtime = lastmillis-players[i]->lastupdate;
	            if(lagtime>1000 && players[i]->state==CS_ALIVE)
	            { dbg;
	                players[i]->state = CS_LAGGED;
	                continue;
	            };
	            if(lagtime && players[i]->state==CS_ALIVE && !intermission) moveplayer(players[i], 2, false);   // use physics to extrapolate player position
			}
        };
    };

    void updateworld(vec &pos, int curtime, int lm)        // main game update loop
    { dbg;
        lastmillis = lm;
        maptime += curtime;
        if(!curtime) return;
        physicsframe();
        et.checkquad(player1, curtime);
        if(m_arena) arenarespawn();
        ws.moveprojectiles(curtime);
        ws.bounceupdate(curtime);
        if(cc.clientnum>=0 && player1->state==CS_ALIVE) ws.shoot(player1, pos);     // only shoot when connected to server
        gets2c();           // do this first, so we have most accurate information when our player moves
        otherplayers(curtime);
        ms.monsterthink(curtime, gamemode);
        bs.ballthink(curtime, gamemode);
		if (player1->aistate != M_NONE)
		{
			as.aithink(player1, curtime, gamemode);
		}
		else
		{
	        if(player1->state==CS_DEAD)
	        { dbg;
	            if(lastmillis-player1->lastaction<2000)
	            { dbg;
	                player1->move = player1->strafe = 0;
	                moveplayer(player1, 10, false);
	            };
	        }
	        else if(!intermission)
	        { dbg;
	            moveplayer(player1, 20, true);
	            et.checkitems(player1);
	            if (tessmap) et.checkregions(player1);
	            //if(m_classicsp)
				checktriggers();
	        };
		}
        if(cc.clientnum>=0) c2sinfo(player1);   // do this last, to reduce the effective frame lag
    };

    void spawnplayer(fpsent *d)   // place at random spawn. also used by monsters!
    { dbg;
        findplayerspawn(d, m_capture ? cpc.pickspawn(d->team) : (respawnent>=0 ? respawnent : -1));
        spawnstate(d);
        if (d->aistate != M_NONE && d != player1)
        	d->state = CS_ALIVE;
        else
        	d->state = cc.spectator ? CS_SPECTATOR : (editmode ? CS_EDITING : CS_ALIVE);
    	particle_splash(15, 500, 1000, d->o);
    };

    void respawn()
    { dbg;
        if(player1->state==CS_DEAD)
        { dbg;
            player1->attacking = false;
            if(m_capture && lastmillis-player1->lastaction<cpc.RESPAWNSECS*1000)
            { dbg;
                conoutf("\f2you must wait %d seconds before respawn!", cpc.RESPAWNSECS-(lastmillis-player1->lastaction)/1000);
                return;
            };
            if(m_arena) { conoutf("\f2waiting for new round to start..."); return; };
            if(m_dmsp) { nextmode = gamemode; cc.changemap(clientmap); return; };    // if we die in SP we try the same map again
            if(m_classicsp)
            { dbg;
                respawnself();
                conoutf("\f2You wasted another life! The monsters stole your armour and some ammo...");
                loopi(NUMGUNS) if((player1->ammo[i] = lastplayerstate.ammo[i])>5) player1->ammo[i] = max(player1->ammo[i]/3, 5); 
                player1->ammo[GUN_PISTOL] = 80;
                return;
            }
            respawnself();
        };
    };

    // inputs

    void doattack(bool on)
    { dbg;
        if(intermission) return;
        if(player1->attacking = on) respawn();
    };

    bool camerafixed() { return player1->state==CS_DEAD || intermission; };
    bool canjump() { if(!intermission) respawn(); return !intermission; };
    bool cancrouch() { return !intermission; };

    // damage arriving from the network, monsters, yourself, all ends up here.

    void selfdamage(int damage, int actor, fpsent *act)
    { dbg;
        if(player1->state!=CS_ALIVE || editmode || intermission) return;

        if(player1->aistate!=M_NONE && actor>=0 && act!=player1)
        { dbg;
            as.aienemy(player1, act);
        };


        damageblend(damage);
        playsound(S_HIT);

        int ad = damage*(player1->armourtype+1)*25/100;     // let armour absorb when possible
        if(ad>player1->armour) ad = player1->armour;
        player1->armour -= ad;
        damage -= ad;

        float droll = damage/0.5f;
        player1->rot.z += player1->rot.z>0 ? droll : (player1->rot.z<0 ? -droll : (rnd(2) ? droll : -droll));  // give player a kick depending on amount of damage

        if((player1->health -= damage)<=0)
        { dbg;
            if(actor==-2)
            { dbg;
                conoutf("\f2you got killed by %s!", &act->name);
            }
            else if(actor==-1)
            { dbg;
                actor = cc.clientnum;
                conoutf("\f2you suicided!");
                cc.addmsg(1, 2, SV_FRAGS, --player1->frags);
            }
            else
            { dbg;
                fpsent *a = getclient(actor);
                if(a)
                { dbg;
                    if(isteam(a->team, player1->team))
                    { dbg;
                        conoutf("\f2you got fragged by a teammate (%s)", a->name);
                    }
                    else
                    { dbg;
                        conoutf("\f2you got fragged by %s", a->name);
                    };
                };
            };
            sb.showscores(true);
            cc.addmsg(1, 2, SV_DIED, actor);
            lastplayerstate = *player1;
            player1->lifesequence++;
            player1->attacking = false;
            player1->state = CS_DEAD;
            player1->deaths++;
            player1->rot.x = 0;
            player1->rot.z = 60;
            playsoundc(S_DIE1+rnd(2));
            vec vel = player1->vel;
            spawnstate(player1);
            player1->vel = vel;
            player1->lastaction = lastmillis;
        }
    };

    void timeupdate(int timeremain)
    { dbg;
        if(!timeremain)
        { dbg;
            intermission = true;
            player1->attacking = false;
            conoutf("\f2intermission:");
            conoutf("\f2game has ended!");
            conoutf("\f2player frags: %d, deaths: %d", player1->frags, player1->deaths);
            int accuracy = player1->totaldamage*100/max(player1->totalshots, 1);
            conoutf("\f2player total damage dealt: %d, damage wasted: %d, accuracy(%%): %d", player1->totaldamage, player1->totalshots-player1->totaldamage, accuracy);               
            if(m_sp)
            { dbg;
                conoutf("\f2--- single player time score: ---");
                int pen, score = 0;
                pen = maptime/1000;       score += pen; if(pen) conoutf("\f2time taken: %d seconds", pen); 
                pen = player1->deaths*60; score += pen; if(pen) conoutf("\f2time penalty for %d deaths (1 minute each): %d seconds", player1->deaths, pen);
                pen = ms.remain*10;       score += pen; if(pen) conoutf("\f2time penalty for %d monsters remaining (10 seconds each): %d seconds", ms.remain, pen);
                pen = (10-ms.skill())*20; score += pen; if(pen) conoutf("\f2time penalty for lower skill level (20 seconds each): %d seconds", pen);
                pen = 100-accuracy;       score += pen; if(pen) conoutf("\f2time penalty for missed shots (1 second each %%): %d seconds", pen);
                s_sprintfd(aname)("bestscore_%s", getclientmap());
                char *bestsc = getalias(aname);
                int bestscore = *bestsc ? atoi(bestsc) : score;
                if(score<bestscore) bestscore = score;
                s_sprintfd(nscore)("%d", bestscore);
                alias(aname, nscore);
                conoutf("\f2TOTAL SCORE (time + time penalties): %d seconds (best so far: %d seconds)", score, bestscore);
            }
            sb.showscores(true);
        }
        else if(timeremain > 0)
        { dbg;
            conoutf("\f2time remaining: %d minutes", timeremain);
        };
    };

    fpsent *getclient(int cn)   // ensure valid entity
    { dbg;
        if(cn<0 || cn>=MAXCLIENTS)
        { dbg;
            neterr("clientnum");
            return NULL;
        };
        while(cn>=players.length()) players.add(NULL);
        return players[cn] ? players[cn] : (players[cn] = new fpsent());
    };

    void initclient()
    { dbg;
        clientmap[0] = 0;
        cc.initclientnet();
    };

    void startmap(const char *name)   // called just after a map load
    { dbg;
        respawnent = -1;
        if(netmapstart() && m_sp) { gamemode = 0; conoutf("coop sp not supported yet"); };
        cc.mapstart();
        ms.monsterclear(gamemode);
        bs.ballclear(gamemode);
        ws.projreset();

        // reset perma-state
        player1->frags = 0;
        player1->maxhealth = 100;
        loopv(players) if(players[i])
        { dbg;
            players[i]->frags = 0;
            players[i]->deaths = 0;
            players[i]->totaldamage = 0;
            players[i]->totalshots = 0;
            players[i]->maxhealth = 100;
        };

        spawnplayer(player1);
        et.resetspawns();
        s_strcpy(clientmap, name);
        sb.showscores(false);
        intermission = false;
        maptime = 0;
        if(*name) conoutf("\f2game mode is %s", fpsserver::modestr(gamemode));
        if(m_sp)
        { dbg;
            s_sprintfd(aname)("bestscore_%s", getclientmap());
            char *best = getalias(aname);
            if(*best) conoutf("\f2try to beat your best score so far: %s", best);
        };

        as.aitotal = 0;

        if (as.aiload() && m_mp(gamemode) && !cc.remote) // ai fps match
        	as.aiadd(-1, -1);
    };

    void physicstrigger(physent *d, bool local, int floorlevel, int waterlevel)
    { dbg;
        if     (waterlevel>0) playsound(S_SPLASH1, d==player1 ? NULL : &d->o);
        else if(waterlevel<0) playsound(S_SPLASH2, d==player1 ? NULL : &d->o);
        if     (floorlevel>0) { if(local) playsoundc(S_JUMP); else if(d->aistate != M_NONE) playsound(S_JUMP, &d->o); }
        else if(floorlevel<0) { if(local) playsoundc(S_LAND); else if(d->aistate != M_NONE) playsound(S_LAND, &d->o); };
    };

    void playsoundc(int n) { cc.addmsg(0, 2, SV_SOUND, n); playsound(n); };

    int numdynents() { return 1+players.length()+ms.monsters.length()+bs.balls.length(); };

    dynent *iterdynents(int i)
    { dbg;
        if(!i) return player1;
        i--;
        if(i<players.length()) return players[i];
        i -= players.length();
        if(i<ms.monsters.length()) return ms.monsters[i];
        i -= ms.monsters.length();
        if(i<bs.balls.length()) return bs.balls[i];
        return NULL;
    };

    void worldhurts(physent *d, int damage)
    { dbg;
        if(d==player1) selfdamage(damage, -1, player1);
        else if(d->type==ENT_PLAYER && d->aistate != M_NONE) as.aipain((fpsent *)d, damage, NULL);
        else if(d->type==ENT_AI) ((monsterset::monster *)d)->monsterpain(damage, player1);
        else if ((d->type==ENT_BALL) && (damage>=999)) ((ballset::ball *)d)->balldie(damage, player1);
    };

    IVAR(hudgun, 0, 1, 1);

    void drawhudmodel(int anim, float speed, int base)
    { dbg;
        static char *hudgunnames[] = { "hudguns/fist", "hudguns/shotg", "hudguns/chaing", "hudguns/rocket", "hudguns/rifle", "hudguns/gl", "hudguns/pistol" };
        if(player1->gunselect>(int)(sizeof(hudgunnames)/sizeof(hudgunnames[0]))) return;
        vec color, dir;
        lightreaching(player1->o, color, dir);
        rendermodel(color, dir, hudgunnames[player1->gunselect], anim, 0, 0, player1->o.x, player1->o.y, player1->o.z, player1->rot.y+90, player1->rot.x, false, speed, base, NULL, 0);
    };

    void drawhudgun()
    { dbg;
        if(!hudgun() || editmode || levelshot || player1->state==CS_SPECTATOR) return;

        int rtime = ws.reloadtime(player1->gunselect);
        if(player1->lastattackgun==player1->gunselect && lastmillis-player1->lastaction<rtime)
        { dbg;
            drawhudmodel(ANIM_GUNSHOOT, rtime/17.0f, player1->lastaction);
        }
        else
        { dbg;
            drawhudmodel(ANIM_GUNIDLE|ANIM_LOOP, 100, 0);
        };
    };

    void drawicon(float tx, float ty, int x, int y)
    { dbg;
        settexture("data/items.png");
        glBegin(GL_QUADS);
        tx /= 384;
        ty /= 128;
        int s = 120;
        glTexCoord2f(tx,        ty);        glVertex2i(x,   y);
        glTexCoord2f(tx+1/6.0f, ty);        glVertex2i(x+s, y);
        glTexCoord2f(tx+1/6.0f, ty+1/2.0f); glVertex2i(x+s, y+s);
        glTexCoord2f(tx,        ty+1/2.0f); glVertex2i(x,   y+s);
        glEnd();
    };

    void renderscores() { sb.render(*this, gamemode); };
    
    void gameplayhud(int w, int h)
    { dbg;
        glLoadIdentity();
        glOrtho(0, w*900/h, 900, 0, -1, 1);
        if(player1->state==CS_SPECTATOR)
        { dbg;
            draw_text("SPECTATOR", 10, 827);
            return;
        };
        draw_textf("%d",  90, 822, player1->health);
        if(player1->armour) draw_textf("%d", 390, 822, player1->armour);
        draw_textf("%d", 690, 822, player1->ammo[player1->gunselect]);

        glLoadIdentity();
        glOrtho(0, w*1800/h, 1800, 0, -1, 1);

        glDisable(GL_BLEND);

        drawicon(192, 0, 20, 1650);
        if(player1->armour) drawicon((float)(player1->armourtype*64), 0, 620, 1650);
        int g = player1->gunselect;
        int r = 64;
        if(g==GUN_PISTOL) { g = 4; r = 0; };
        drawicon((float)(g*64), (float)r, 1220, 1650);
        if(m_capture) cpc.capturehud(w, h);
    };

    void edittrigger(const selinfo &sel, int op, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6)
    { dbg;
        switch(op)
        {
            case EDIT_FLIP:
            case EDIT_COPY:
            case EDIT_PASTE:
            { dbg;
                cc.addmsg(1, 14, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner);
                break;
            };
            case EDIT_ROTATE:
            { dbg;
                cc.addmsg(1, 15, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1);
                break;
            };
            case EDIT_MAT:
            { dbg;
                cc.addmsg(1, 20, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2, arg3, arg4, arg5, arg6);
                break;
            };
            case EDIT_RGN:
            { dbg;
                cc.addmsg(1, 16, SV_EDITRG,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2);
                break;
            };
            case EDIT_ELEM:
            { dbg;
                cc.addmsg(1, 18, SV_EDITLM,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2, arg3, arg4);
                break;
            };
            case EDIT_FACE:
            { dbg;
                cc.addmsg(1, 16, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2);
                break;
            };
            case EDIT_TEX:
            case EDIT_REPLACE:
            { dbg;
                cc.addmsg(1, 17, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2, arg3);
                break;
            };
            case EDIT_MOVE:
            { dbg;
                cc.addmsg(1, 17, SV_EDITF + op,
                   sel.o.x, sel.o.y, sel.o.z, sel.s.x, sel.s.y, sel.s.z, sel.grid, sel.orient,
                   sel.cx, sel.cxs, sel.cy, sel.cys, sel.corner,
                   arg1, arg2, arg3);
                break;
            };
        };
    };
    
    void treemenu() {};

    // any data written into this vector will get saved with the map data. Must take care to do own versioning, and endianess if applicable. Will not get called when loading maps from other games, so provide defaults.
    void writegamedata(vector<char> &extras) {};
    void readgamedata(vector<char> &extras) {};

    char *gameident() { return "fps"; };
};

REGISTERGAME(fpsgame, "fps", new fpsclient(), new fpsserver());

#else

REGISTERGAME(fpsgame, "fps", NULL, new fpsserver());

#endif



