// creation of scoreboard pseudo-menu

struct scoreboard
{
    bool scoreson;

    scoreboard() : scoreson(false)
    {
        CCOMMAND(scoreboard, showscores, "D", self->showscores(args!=NULL));
    };

    void showscores(bool on)
    { dbg;
        scoreson = on;
        menuset(((int)on)-1);
    };

    struct sline { string s; };

    void render(fpsclient &cl, int gamemode)
    { dbg;
        if(!scoreson) return;

        vector<sline> scorelines;

        const int maxteams = 4;
        char *teamname[maxteams];
        int teamscore[maxteams], teamsused;
        string teamscores;
        bool showclientnum = cl.cc.currentmaster>=0 && cl.cc.currentmaster==cl.cc.clientnum;

        scorelines.setsize(0);
        loopi(cl.numdynents()) 
        { dbg;
            fpsent *o = (fpsent *)cl.iterdynents(i);
            if(o && (o->type==ENT_PLAYER || o->type==ENT_CAMERA))
            { dbg;
                const char *master = cl.cc.currentmaster>= 0 && (cl.cc.currentmaster==i-1 || (!i && cl.cc.currentmaster==cl.cc.clientnum)) ? "\f0" : "";
                string name;
				if(showclientnum) s_sprintf(name)("%s \f0(%d)", o->name, !i ? cl.cc.clientnum : i-1);
                else s_strcpy(name, o->name);
                if(o->state == CS_SPECTATOR) s_sprintf(scorelines.add().s)("SPECTATOR\t\t\t%s%s", master, name);
                else
                { dbg;
                    s_sprintfd(lag)("%d", o->plag);
                    s_sprintf(scorelines.add().s)("%d\t%s\t%d\t%s\t%s%s", m_capture ? cl.cpc.findscore(o->team).total : o->frags, o->state==CS_LAGGED ? "LAG" : lag, o->ping, o->team, master, name);
                };
                menumanual(0, scorelines.length()-1, scorelines.last().s); 
            }
        };

        sortmenu(0, scorelines.length());
        if(m_teammode)
        { dbg;
            teamsused = 0;
            if(m_capture)
            { dbg;
                loopv(cl.cpc.scores) if(cl.cpc.scores[i].total)
                { dbg;
                    teamname[teamsused] = cl.cpc.scores[i].team;
                    teamscore[teamsused++] = cl.cpc.scores[i].total;
                    if(teamsused>=maxteams) break;
                };
            }
            else loopi(cl.numdynents()) 
            { dbg;
                fpsent *o = (fpsent *)cl.iterdynents(i);
                if(o && (o->type==ENT_PLAYER || o->type==ENT_CAMERA) && o->frags)
                { dbg;
                    loopi(teamsused) if(strcmp(teamname[i], o->team)==0) { teamscore[i] += o->frags; goto out; };
                    if(teamsused<maxteams)
                    { dbg;
                        teamname[teamsused] = o->team;
                        teamscore[teamsused++] = o->frags;
                    };
                    out:;
                };
            };
            if(teamsused)
            { dbg;
                teamscores[0] = 0;
                loopj(teamsused)
                { dbg;
                    s_sprintfd(s)("[ %s: %d ]", teamname[j], teamscore[j]);
                    s_strcat(teamscores, s);
                };
                menumanual(0, scorelines.length(), "");
                menumanual(0, scorelines.length()+1, teamscores);
            };
        };
    };
};
