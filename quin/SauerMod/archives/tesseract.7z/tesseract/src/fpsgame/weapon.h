// weapon.h: all shooting and effects code, projectile management

struct weaponstate
{
    fpsclient &cl;
    fpsent *player1;

    struct guninfo { short num, sound, attackdelay, damage, projspeed, part, kickamount; char *name; };

    static const int MONSTERDAMAGEFACTOR = 4;
    static const int SGRAYS = 20;
    static const int SGSPREAD = 4;
    vec sg[SGRAYS];

    guninfo *guns;
    
    weaponstate(fpsclient &_cl) : cl(_cl), player1(_cl.player1)
    {
        static guninfo _guns[NUMGUNS] =
        {
            { 0, S_PUNCH1,    250,  50, 0,   0,  1, "fist"            },
            { 2, S_SG,       1400,  10, 0,   0, 20, "shotgun"         },  // *SGRAYS
            { 3, S_CG,        100,  30, 0,   0,  7, "chaingun"        },
            { 5, S_RLFIRE,    800, 120, 80,  0, 10, "rocketlauncher"  },
            { 6, S_RIFLE,    1500, 100, 0,   0, 30, "rifle"           },
            { 4, S_FLAUNCH,   500,  75, 80,  0, 10, "grenadelauncher" },
            { 1, S_PISTOL,    500,  25, 0,   0,  7, "pistol"          },
            { -1, S_FLAUNCH,   200,  20, 50,  4,  1, "fireball"        },
            { -1, S_ICEBALL,   200,  40, 30,  6,  1, "iceball"         },
            { -1, S_SLIMEBALL, 200,  30, 160, 7,  1, "slimeball"       },
            { -1, S_PIGR1,     250,  50, 0,   0,  1, "bite"            },
        };
        guns = _guns;
        
        CCOMMAND(weaponstate, weapon, "sss",
        {
            self->weaponswitch(self->cl.player1, args[0][0] ? atoi(args[0]) : weaponcycle ? 0 : -1,
                               args[1][0] ? atoi(args[1]) : weaponcycle ? 0 : -1,
                               args[2][0] ? atoi(args[2]) : -1);

        });
    };

    void weaponswitch(fpsent *d, int a = -1, int b = -1, int c = -1)
    { dbg;
        int *ammo = d->ammo;
        int s = d->gunselect;

		if (weaponcycle) // 0 or number+1, [direction]
    	{ dbg;
			int v, w, z = (a > 0 || b == 0 ? -1 : b);
			for (v = (a > 0 ? a-1 : b == 0 ? 6 : guns[s].num + z), w = 0; w < NUMGUNS; w++)
			{ dbg;
				int x;
				
				if (v > 6) v = 0;
				else if (v < 0) v = 6;
				
				for (x = 0; x < NUMGUNS; x++)
				{ dbg;
					if (guns[x].num == v)
						break;
				}
				if ((x < NUMGUNS) && (x == GUN_FIST || ammo[x]))
				{ dbg;
					s = x;
					break;
				}
				v += z;
			}
		}
		else
		{ dbg;
	        if(a<-1 || b<-1 || c<-1 || a>=NUMGUNS || b>=NUMGUNS || c>=NUMGUNS) return;
	
	        if     (a>=0 && s!=a  && ammo[a])          s = a;
	        else if(b>=0 && s!=b  && ammo[b])          s = b;
	        else if(c>=0 && s!=c  && ammo[c])          s = c;
	        else if(s!=GUN_CG     && ammo[GUN_CG])     s = GUN_CG;
	        else if(s!=GUN_RL     && ammo[GUN_RL])     s = GUN_RL;
	        else if(s!=GUN_SG     && ammo[GUN_SG])     s = GUN_SG;
	        else if(s!=GUN_RIFLE  && ammo[GUN_RIFLE])  s = GUN_RIFLE;
	        else if(s!=GUN_GL     && ammo[GUN_GL])     s = GUN_GL;
	        else if(s!=GUN_PISTOL && ammo[GUN_PISTOL]) s = GUN_PISTOL;
	        else                                       s = GUN_FIST;
	
		}
        if(s!=d->gunselect) cl.playsoundc(S_WEAPLOAD);
        dbg; d->gunselect = s;
    };
    
    int reloadtime(int gun) { return guns[gun].attackdelay; };
    
    void offsetray(vec &from, vec &to, int spread, vec &dest)
    { dbg;
        float f = to.dist(from)*spread/1000;
        for(;;)
        { dbg;
            #define RNDD rnd(101)-50
            vec v(RNDD, RNDD, RNDD);
            if(v.magnitude()>50) continue;
            v.mul(f);
            v.z /= 2;
            dest = to;
            dest.add(v);
            vec dir = dest;
            dir.sub(from);
            raycubepos(from, dir, dest, 0, RAY_CLIPMAT|RAY_POLY);
            return;
        };
    };

    void createrays(vec &from, vec &to)             // create random spread of rays for the shotgun
    { dbg;
        loopi(SGRAYS)
        { dbg;
            offsetray(from, to, SGSPREAD, sg[i]);
        };
    };

    struct bouncent : physent
    {
        int lifetime;
        bool local;
        fpsent *owner;
    };

    vector<bouncent> bouncers;

    void newbouncer(vec &from, vec &to, bool local, fpsent *owner)
    { dbg;
        bouncent &bnc = bouncers.add();
        bnc.reset();
        bnc.type = ENT_BOUNCE;
        bnc.o = from;
        bnc.radius = 2;
        bnc.eyeheight = 2;
        bnc.aboveeye = 2;
        bnc.lifetime = 2000;
        bnc.local = local;
        bnc.owner = owner;

        vec dir(to);
        dir.sub(from).normalize();
        bnc.vel = dir;
        bnc.vel.mul(200.0f);

        avoidcollision(&bnc, dir, owner, 0.1f);
    };

    void bounceupdate(int time)
    { dbg;
        static const int maxtime = 20; // run at least 50 times a second
        loopv(bouncers)
        { dbg;
            bouncent &bnc = bouncers[i];
            particle_splash(12, 1, 1, bnc.o);
            particle_splash(1, 2, 150, bnc.o);
            int rtime = time;
            while(rtime > 0)
            { dbg;
                int qtime = min(maxtime, rtime);
                rtime -= qtime;
                if((bnc.lifetime -= qtime)<0 || bounce(&bnc, qtime/1000.0f, 0.6f))
                { dbg;
                    int qdam = guns[GUN_GL].damage*(bnc.owner->quadmillis ? 4 : 1);
                    explode(bnc.local, bnc.owner, bnc.o, NULL, qdam, GUN_GL);
                    bouncers.remove(i--);
                    break;
                };
            };
        };
    };

    static const int MAXPROJ = 100;
    struct projectile { vec o, from, to; float speed; fpsent *owner; int gun; bool inuse, local; } projs[MAXPROJ];

    void projreset() { loopi(MAXPROJ) projs[i].inuse = false; bouncers.setsize(0); };

    void newprojectile(vec &from, vec &to, float speed, bool local, fpsent *owner, int gun)
    { dbg;
        loopi(MAXPROJ)
        { dbg;
            projectile *p = &projs[i];
            if(p->inuse) continue;
            p->inuse = true;
            p->o = from;
            p->from = from;
            p->to = to;
            p->speed = speed;
            p->local = local;
            p->owner = owner;
            p->gun = gun;
            return;
        };
    };
    
    void damageeffect(const vec &p, int damage, const char *fstr, ...)
    { dbg;
	    s_sprintfdlv(str, fstr, fstr);
        particle_splash(3, damage*10, 1000, p);
        particle_text(p, str, 8, 5000);
    };

    void hit(int target, int damage, fpsent *d, fpsent *at, vec &vel, bool isrl)
    { dbg;
        d->lastpain = cl.lastmillis;
        at->totaldamage += damage;
        vel.mul(80*damage/d->weight);
        if(d==player1)           { if(isrl) vel.mul(5); d->vel.add(vel); cl.selfdamage(damage, at==player1 ? -1 : -2, at); } 
        else if(d->type==ENT_PLAYER && d->aistate!=M_NONE){ if(isrl) vel.mul(3); d->vel.add(vel); cl.as.aipain(d, damage, at); }
        else if(d->type==ENT_AI) { if(isrl) vel.mul(3); d->vel.add(vel); ((monsterset::monster *)d)->monsterpain(damage, at); }
        else if(d->type==ENT_BALL) { if(isrl) vel.mul(3); d->vel.add (vel);}
        else                     { if(isrl) vel.mul(2); cl.cc.addmsg(1, 7, SV_DAMAGE, target, damage, d->lifesequence, (int)(vel.x*DVELF), (int)(vel.y*DVELF), (int)(vel.z*DVELF)); playsound(S_PAIN1+rnd(5), &d->o); };
    };

	int hitreward(int damage, fpsent *d, fpsent *at, vec &from, vec &to)
	{
		int reward = damage;
		bool rewarded = false;
		
		if (tessmap)
		{
		    vec v = to, w = d->o, *p;
		    v.sub(from);
		    w.sub(from);
		    float c1 = w.dot(v);
		
		    if(c1<=0) p = &from;
		    else
		    { dbg;
		        float c2 = v.dot(v);
		        if(c2<=c1) p = &to;
		        else
		        { dbg;
		            float f = c1/c2;
		            v.mul(f);
		            v.add(from);
		            p = &v;
		        };
		    };
	
		    if (p->x <= d->o.x+d->radius
	        && p->x >= d->o.x-d->radius
	        && p->y <= d->o.y+d->radius
	        && p->y >= d->o.y-d->radius
	        && p->z <= d->o.z+d->aboveeye
	        && p->z >= d->o.z-d->eyeheight)
	        { dbg;
	        	// HEADSHOT
				if (p->z <= d->o.z+d->aboveeye && p->z >= d->o.z+(d->aboveeye/2)) // is this correct?
				{
					reward *= 2;
	
					if ((d->health-reward) <= 0)
					{
			        	damageeffect(d->abovehead(), damage, "@[HEADSHOT by %s] (-%d)", at->name, reward);
			        	if (at==player1) playsound(S_R_HEADSHOT);
			        	rewarded = true;
					}
				}
			}
		}
		if (!rewarded)
		{
			damageeffect(d->abovehead(), damage, "@(-%d)", reward);
        	if (at==player1) playsound(S_DAMAGE);
		}
		return reward;
	}

    void hitpush(int target, int damage, fpsent *d, fpsent *at, vec &from, vec &to, bool isrl)
    { dbg;
        if(d->type==ENT_BALL) { ((ballset::ball *)d)->ballhit(damage, at, from, to); }
        else
        { dbg;
	        vec v(to);
	        v.sub(from);
	        v.normalize();
	        hit(target, hitreward (damage, d, at, from, to), d, at, v, isrl);
		}
    };

    static const int RL_DAMRAD = 40;  

    void radialeffect(fpsent *o, vec &v, int cn, int qdam, fpsent *at, vec &dir, float dist, int gun)
    { dbg;
        if(o->state!=CS_ALIVE) return;
        if(dist<RL_DAMRAD) 
        { dbg;
            int damage = (int)(qdam*(1-dist/1.5f/RL_DAMRAD));
            if(gun==GUN_RL && o==at) damage /= 2; 
            hit(cn, damage, o, at, dir, true);
        };
    };

    float rocketdist(fpsent *o, vec &dir, vec &v)
    { dbg;
        vec middle = o->o;
        middle.z -= (o->aboveeye+o->eyeheight)/2;
        float dist = middle.dist(v, dir);
        if(dist<0) dist = 0;
        dir.normalize();
        return dist;
    };

    void explode(bool local, fpsent *owner, vec &v, dynent *notthis, int qdam, int gun)
    { dbg;
        particle_splash(0, 200, 300, v);
        playsound(S_RLHIT, &v);
        newsphere(v, RL_DAMRAD, gun==GUN_RL ? 0 : 1);
        if(!local) return;
        loopi(cl.numdynents())
        { dbg;
            fpsent *o = (fpsent *)cl.iterdynents(i);
            if(!o || o==notthis) continue;
            vec dir;
            float dist = rocketdist(o, dir, v);
            radialeffect(o, v, i-1, qdam, owner, dir, dist, gun);
        };
    };

    void splash(projectile *p, vec &v, dynent *notthis, int qdam)
    { dbg;
        p->inuse = false;
        if(p->gun!=GUN_RL)
        { dbg;
            particle_splash(0, 100, 200, v);
            playsound(S_FEXPLODE, &v);
            // no push?
        }
        else
        { dbg;
            explode(p->local, p->owner, v, notthis, qdam, GUN_RL);
        };
    };

    void projdamage(fpsent *o, projectile *p, vec &v, int i, int qdam)
    { dbg;
        if(o->state!=CS_ALIVE) return;
        if(intersect(o, p->o, v))
        { dbg;
            splash(p, v, o, qdam);
           	hitpush(i, qdam, o, p->owner, p->from, p->to, p->gun==GUN_RL);
        }; 
    };

    void moveprojectiles(int time)
    { dbg;
        loopi(MAXPROJ)
        { dbg;
            projectile *p = &projs[i];
            if(!p->inuse) continue;
            int qdam = guns[p->gun].damage*(p->owner->quadmillis ? 4 : 1);
            if(p->owner->type==ENT_AI) qdam /= MONSTERDAMAGEFACTOR;
            vec v;
            float dist = p->to.dist(p->o, v);
            float dtime = dist*1000/p->speed; 
            if(time > dtime) dtime = time;
            v.mul(time/dtime);
            v.add(p->o);
            if(p->local)
            { dbg;
                loopi(cl.numdynents())
                { dbg;
                    fpsent *o = (fpsent *)cl.iterdynents(i);
                    if(!o) continue;
                    if(!o->o.reject(v, 10.0f) && p->owner!=o) projdamage(o, p, v, i-1, qdam);
                };
            };
            if(p->inuse)
            { dbg;
                if(dist<4)
                { dbg;
                    if(raycubepos(p->o, vec(p->to).sub(p->o), p->to, 0, RAY_CLIPMAT|RAY_POLY)>=4) continue;      // if original target was moving, reevaluate endpoint
                    splash(p, v, NULL, qdam);
                }
                else
                { dbg;
                    if(p->gun==GUN_RL) { /*dodynlight(p->o, v, 0, 255, p->owner);*/ particle_splash(5, 2, 300, v); }
                    else { particle_splash(1, 2, 300, v); particle_splash(guns[p->gun].part, 1, 1, v); };
                };       
            };
            p->o = v;
        };
    };

    void shootv(int gun, vec &from, vec &to, fpsent *d, bool local)     // create visual effect from a shot
    { dbg;
        playsound(guns[gun].sound, d==player1 ? NULL : &d->o);
        int pspeed = 25;
        vec behind = vec(from).sub(to).normalize().mul(4).add(from);
        switch(gun)
        {
            case GUN_FIST:
                break;

            case GUN_SG:
            { dbg;
                loopi(SGRAYS)
                { dbg;
                    particle_splash(0, 20, 250, sg[i]);
                    particle_flare(behind, sg[i], 300);
                };
                break;
            };

            case GUN_CG:
            case GUN_PISTOL:
            { dbg;
                particle_splash(0, 200, 250, to);
                //particle_trail(1, 10, from, to);
                vec lower = behind;
                lower.z -= 2;
                particle_flare(lower, to, 600);
                break;
            };

            case GUN_RL:
            case GUN_FIREBALL:
            case GUN_ICEBALL:
            case GUN_SLIMEBALL:
                pspeed = guns[gun].projspeed*4;
                if(d->type==ENT_AI) pspeed /= 2;
                newprojectile(from, to, (float)pspeed, local, d, gun);
                break;

            case GUN_GL:
            { dbg;
                float dist = from.dist(to);
                vec up = to;
                up.z += dist/8;
                newbouncer(from, up, local, d);
                break;
            };

            case GUN_RIFLE: 
                particle_splash(0, 200, 250, to);
                particle_trail(1, 500, from, to);
                break;
        };
    };

    fpsent *intersectclosest(vec &from, vec &to, int &n, fpsent *at)
    { dbg;
        fpsent *best = NULL;
        loopi(cl.numdynents())
        { dbg;
            fpsent *o = (fpsent *)cl.iterdynents(i);
            if(!o || o==at || o->state!=CS_ALIVE) continue;
            if(!intersect(o, from, to)) continue;
            if(!best || at->o.dist(o->o)<at->o.dist(best->o))
            { dbg;
                best = o;
                n = i-1;
            };
        };
        return best;
    };

    void shorten(vec &from, vec &to, vec &target)
    { dbg;
        target.sub(from).normalize().mul(from.dist(to)).add(from);
    };

    void raydamage(vec &from, vec &to, fpsent *d)
    { dbg;
        int qdam = guns[d->gunselect].damage;
        if(d->quadmillis) qdam *= 4;
        if(d->type==ENT_AI) qdam /= MONSTERDAMAGEFACTOR;
        int i, n;
        fpsent *o, *cl;
        if(d->gunselect==GUN_SG)
        { dbg;
            bool done[SGRAYS];
            loopj(SGRAYS) done[j] = false;
            for(;;)
            { dbg;
                bool raysleft = false;
                int damage = 0;
                o = NULL;
                loop(r, SGRAYS) if(!done[r] && (cl = intersectclosest(from, sg[r], n, d)))
                { dbg;
                    if((!o || o==cl) && (damage<cl->health+cl->armour || cl->type!=ENT_AI))
                    { dbg;
                        damage += qdam;
                        o = cl;
                        done[r] = true;
                        i = n;
                        shorten(from, o->o, sg[r]);
                    }
                    else raysleft = true;
                };
                if(damage) hitpush(i, damage, o, d, from, to, false);
                if(!raysleft) break;
            };
        }
        else if(o = intersectclosest(from, to, i, d))
        { dbg;
            hitpush(i, qdam, o, d, from, to, false);
            shorten(from, o->o, to);
        };
    };

    void shoot(fpsent *d, vec &targ)
    { dbg;
        int attacktime = cl.lastmillis-d->lastaction;
        if(attacktime<d->gunwait) return;
        d->gunwait = 0;
        if(!d->attacking) return;
        d->lastaction = cl.lastmillis;
        d->lastattackgun = d->gunselect;
        if(!d->ammo[d->gunselect]) { cl.playsoundc(S_NOAMMO); d->gunwait = 600; d->lastattackgun = -1; weaponswitch(d, weaponcycle ? 0 : -1, -1); return; };
        if(d->gunselect) d->ammo[d->gunselect]--;
        vec from = d->o;
        vec to = targ;
        from.z -= 0.8f;    // below eye

        vec unitv;
        float dist = to.dist(from, unitv);
        unitv.div(dist);
        vec kickback(unitv);
        kickback.mul(guns[d->gunselect].kickamount*-2.5f);
        d->vel.add(kickback);
        if(d->rot.x<80.0f) d->rot.x += guns[d->gunselect].kickamount*0.05f;
        float shorten = 0.0f;
        
        if(dist>1024) shorten = 1024;
        if(d->gunselect==GUN_FIST || d->gunselect==GUN_BITE) shorten = 12;
        float barrier = raycube(d->o, unitv, dist, RAY_CLIPMAT|RAY_POLY);
        if(barrier < dist && (!shorten || barrier < shorten))
            shorten = barrier;
        if(shorten)
        { dbg;
            unitv.mul(shorten);
            to = from;
            to.add(unitv);
        };
        
        if(d->gunselect==GUN_SG) createrays(from, to);
        else if(d->gunselect==GUN_CG) offsetray(from, to, 1, to);

        if(d->quadmillis && attacktime>200) cl.playsoundc(S_V_QUADFIRE);

        if(!guns[d->gunselect].projspeed) raydamage(from, to, d);

        shootv(d->gunselect, from, to, d, true);

        if(d->type!=ENT_AI) cl.cc.addmsg(1, 8, SV_SHOT, d->gunselect, (int)(from.x*DMF), (int)(from.y*DMF), (int)(from.z*DMF), (int)(to.x*DMF), (int)(to.y*DMF), (int)(to.z*DMF));

        d->gunwait = guns[d->gunselect].attackdelay;

        d->totalshots += guns[d->gunselect].damage*(d->quadmillis ? 4 : 1)*(d->gunselect==GUN_SG ? SGRAYS : 1);
    };
};
