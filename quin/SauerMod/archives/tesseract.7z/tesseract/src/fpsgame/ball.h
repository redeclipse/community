// ball.cpp: implements ball projectiles for billard, etc.

struct ballset
{
    fpsclient &cl;
    vector<extentity *> &ents;
    
	enum {
		BALL_CUE = 0,
		BALL_RED,
		BALL_YELLOW,
		BALL_BLACK,
		BALL_NUM
	};
    
	struct balltype
    {
		int type;
        char *name;
        int side;
        float size;
        float r, g, b;
    };   
    
    struct ball : fpsent
    {
        fpsclient &cl;
	    vector<extentity *> &ents;

        balltype *balltypes;
        ballset *bs;
        fpsent *lfps;
        
        int mtype;
        vec spawn;

        ball(int _num, ballset *_bs) : cl(_bs->cl), ents(_bs->cl.et.ents), balltypes(_bs->balltypes), bs(_bs)
        {
			bool g = false;
			int _type = ents[_num]->attr1;

            type = ENT_BALL;

            respawn();

			if(_type>=BALL_NUM)
            { dbg;
                conoutf("warning: unknown ball in spawn: %d", _type);
                _type = BALL_CUE;
            };

			balltype *t = balltypes+(mtype = _type);
            eyeheight = t->size - 0.5f;
            aboveeye = t->size;
			radius = t->size;
            s_strcpy(name, t->name);
            weight = (int) (t->size * 10);

            health = 0;
            rot.y = 0;
            rot.x = 0;
            rot.z = 0;
            maxspeed = 10.0f;
            state = CS_ALIVE;
            lfps = cl.player1;

            o = ents[_num]->o;

	        vec orig = o;
	        o.z += t->size / 2.0;
	        
	        loopi(100)
	        { dbg;
	            extern bool inside;
	            if(collide(this) && !inside)
				{ dbg;
					g = true;
					break;
				}
	            o.z += 1.0f;
	        };
	        if (g == false)
	        { dbg;
        		conoutf("can't find ball spawn spot! (%d, %d)", o.x, o.y); 
        		o = orig;
			}
			spawn.x = o.x;
			spawn.y = o.y;
			spawn.z = o.z;
        };

	    void ballhit(int damage, fpsent *d, vec &from, vec &to)
		{ dbg;
			// only hit the cue ball (todo: expand to turn only too)
			if (this->mtype == BALL_CUE)
			{ dbg;
			    vec v = to, w = this->o, *p;
			    v.sub(from);
			    w.sub(from);
			    float c1 = w.dot(v);
			
			    if(c1<=0) p = &from;
			    else
			    { dbg;
			        float c2 = v.dot(v);
			        if(c2<=c1) p = &to;
			        else
			        { dbg;
			            float f = c1/c2;
			            v.mul(f);
			            v.add(from);
			            p = &v;
			        };
			    };
	
			    if (p->x <= this->o.x+this->radius
		        && p->x >= this->o.x-this->radius
		        && p->y <= this->o.y+this->radius
		        && p->y >= this->o.y-this->radius
		        && p->z <= this->o.z+this->aboveeye
		        && p->z >= this->o.z-this->eyeheight)
		        { dbg;
					vec hit(p->x, p->y, p->z);
					vec nud(this->o.x, this->o.y, this->o.z);
					
					float xx = fabs (nud.x-hit.x), yy = fabs (nud.y-hit.y);
					
					/// expand positional radius
					if (xx < yy)
					{ dbg;
						if (nud.x < hit.x)
							hit.x += this->radius;
						else
							hit.x -= this->radius;
					}
					else
					{ dbg;
						if (nud.y < hit.y)
							hit.y += this->radius;
						else
							hit.y -= this->radius;
					}
	
					nud.sub(hit);
					vec push(nud.x, nud.y, nud.z);
					push.mul(damage*1.0f);
	    	        vel.add(push);
	
					conoutf("damg = %d, ent = %s, hit = %s", damage, this->name, d->name);
					conoutf("from = %f,%f,%f", from.x, from.y, from.z);
					conoutf("hit  = %f,%f,%f", hit.x, hit.y, hit.z);
					conoutf("ball = %f,%f,%f", this->o.x, this->o.y, this->o.z);
					conoutf("to   = %f,%f,%f", to.x, to.y, to.z);
					conoutf("nud  = %f,%f,%f", nud.x, nud.y, nud.z);
					conoutf("push = %f,%f,%f", push.x, push.y, push.z);
				}
	            lfps = d;
			}
		}

	    void balldie(int damage, fpsent *d)
		{ dbg;
			if (this->mtype == BALL_CUE)
			{ dbg;
	        	conoutf("Foul by %s sinking the %s ball.", this->lfps->name, this->balltypes[this->mtype].name); 
				this->o.x = this->spawn.x;
				this->o.y = this->spawn.y;
				this->o.z = this->spawn.z;
				this->vel.x = 0.0;
				this->vel.y = 0.0;
				this->vel.z = 0.0;
				this->grav.x = 0.0;
				this->grav.y = 0.0;
				this->grav.z = 0.0;
			}
			else
			{ dbg;
	        	conoutf("%s ball has been sunk.", this->balltypes[this->mtype].name); 
	        	state = CS_DEAD;
				bs->ballremove();
			}
		}
    };

    balltype *balltypes;
        
    ballset(fpsclient &_cl) : cl(_cl), ents(_cl.et.ents)
    { dbg;
        static balltype _balltypes[BALL_NUM] =
        {   
            { BALL_CUE,			"Cue",		0,	10.0f, 0.5f, 0.5f, 0.5f },
            { BALL_RED,			"Red",		1,	10.0f, 0.5f, 0.0f, 0.0f },
            { BALL_YELLOW,		"Yellow",	2,	10.0f, 0.5f, 0.5f, 0.0f },
            { BALL_BLACK,		"Black",	3,	10.0f, 0.0f, 0.0f, 0.0f },
        };
        balltypes = _balltypes;
    };
    
    vector<ball *> balls;
    
    int nextball, numcleared, balltotal, mtimestart, remain, gm;

    void ballclear(int gamemode)     // called after map start or when toggling edit mode to reset/spawn all balls to initial state
    { dbg;

        loopv(balls) delete balls[i]; 

        cleardynentcache();
        balls.setsize(0);

        numcleared = 0;
        balltotal = 0;
        remain = 0;
        mtimestart = cl.lastmillis;
        gm = gamemode;

        loopv(ents) if(ents[i]->type==BALL)
        { dbg;
            ball *m = new ball(i, this); 
            balltotal++;
            balls.add(m);
        };
    };

    /*void endsp(bool allcleared)
    { dbg;
        conoutf(allcleared ? "you have cleared the map!" : "you reached the exit!");
        balltotal = 0;
        cl.cc.addmsg(1, 1, SV_FORCEINTERMISSION);
    };*/
    
    void ballremove()
    { dbg;
        numcleared++;
        cl.player1->frags = numcleared;
        remain = balltotal-numcleared;
        if (remain<=0) ballclear(gm);
        //else if((remain>0) && (remain<=5)) conoutf("only %d ball(s) remaining", remain);
    };

    void ballthink(int curtime, int gamemode)
    { dbg;
        loopv(balls) if(balls[i]->state==CS_ALIVE)
        { dbg;
	        loopvj(ents)             // equivalent of player entity touch, but only teleports are used
	        { dbg;
	            entity &e = *ents[j];
	            
				if(e.type==TELEPORT)
	            { dbg;
		            vec v = e.o;
	                v.z += balls[i]->eyeheight;
	                float dist = v.dist(balls[i]->o);
	                v.z -= balls[i]->eyeheight;
	                if(dist<16) cl.et.teleent(j, balls[i]);
	            };
			}
            cl.et.checkregions (balls[i]);
            balls[i]->move = balls[i]->strafe = 0;
            moveplayer(balls[i], 2, false);
        };
    };

    void ballrender()
    { dbg;
    	if (!editmode)
    	{
        	loopv(balls)
        	{ dbg;
				if (balls[i]->state == CS_ALIVE)
			 		renderball (balls[i]->o, balls[i]->radius, balls[i]->rot.x, balls[i]->rot.y, balls[i]->rot.z, balls[i]->balltypes[balls[i]->mtype].r, balls[i]->balltypes[balls[i]->mtype].g, balls[i]->balltypes[balls[i]->mtype].b);
			};
		}
    };
};
