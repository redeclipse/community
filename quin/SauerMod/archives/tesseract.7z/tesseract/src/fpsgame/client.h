struct clientcom : iclientcom
{
    fpsclient &cl;

    bool c2sinit;       // whether we need to tell the other clients our stats

    string ctext;
    void toserver(char *text) { conoutf("%s:\f0 %s", player1->name, text); s_strcpy(ctext, text); };

    string toservermap;
    bool senditemstoserver;     // after a map change, since server doesn't have map data
    int lastping;

    bool connected, remote;
    int clientnum;

    string setmaster;
    int currentmaster;
    bool spectator;

    fpsent *player1;

    clientcom(fpsclient &_cl) : cl(_cl), c2sinit(false), senditemstoserver(false), lastping(0), connected(false), remote(false), clientnum(-1), currentmaster(-1), spectator(false), player1(_cl.player1)
    {
        CCOMMAND(clientcom, say, "C", self->toserver(args[0]));
        CCOMMAND(clientcom, name, "s", if(args[0][0]) { self->c2sinit = false; s_strncpy(self->player1->name, args[0], 16); });
        CCOMMAND(clientcom, team, "s", if(args[0][0]) { self->c2sinit = false; s_strncpy(self->player1->team, args[0], 5);  });
        CCOMMAND(clientcom, map, "s", self->changemap(args[0]));
        CCOMMAND(clientcom, kick, "s", self->kick(args[0]));
        CCOMMAND(clientcom, spectator, "ss", self->togglespectator(args[0], args[1]));
        CCOMMAND(clientcom, mastermode, "s", self->addmsg(1, 2, SV_MASTERMODE, atoi(args[0])));
        CCOMMAND(clientcom, setmaster, "s", s_strcpy(self->setmaster, args[0]));
        CCOMMAND(clientcom, getmap, "", self->getmap());
        CCOMMAND(clientcom, sendmap, "", self->sendmap());
    };

    void mapstart() { if(!spectator || currentmaster==clientnum) senditemstoserver = true; };

    void initclientnet()
    { dbg;
        setmaster[0] = 0;
        ctext[0] = 0;
        toservermap[0] = 0;
    };

    void writeclientinfo(FILE *f)
    { dbg;
        fprintf(f, "name \"%s\"\nteam \"%s\"\n", player1->name, player1->team);
    };

    void gameconnect(bool _remote)
    { dbg;
        connected = true;
        remote = _remote;
    };

    void gamedisconnect()
    { dbg;
        connected = false;
        clientnum = -1;
        c2sinit = false;
        player1->lifesequence = 0;
        currentmaster = -1;
        spectator = false;
        loopv(cl.players) DELETEP(cl.players[i]);
        cleardynentcache();
    };

    bool allowedittoggle()
    { dbg;
        bool allow = !connected || !remote || cl.gamemode==1;
        if(!allow) conoutf("editing in multiplayer requires coopedit mode (1)");
        if(allow && spectator) return false;
        return allow;
    };

    int clientnumof(dynent *d)
    { dbg;
        loopi(cl.numdynents())
        { dbg;
            dynent *o = cl.iterdynents(i);
            if(o == d) return i==0 ? clientnum : i-1;
        };
        return -1;
    };

    int parseplayer(const char *arg)
    { dbg;
        char *end;
        int n = strtol(arg, &end, 10);
        if(!cl.players.inrange(n)) return -1;
        if(*arg && !*end) return n;
        loopi(cl.numdynents())
        { dbg;
            fpsent *o = (fpsent *)cl.iterdynents(i);
            if(o && !strcmp(arg, o->name)) return i==0 ? clientnum : i-1;
        };
        return -1;
    };

    void kick(const char *arg)
    { dbg;
        if(!remote) return;
        int i = parseplayer(arg);
        if(i>=0 && i!=clientnum) addmsg(1, 2, SV_KICK, i);
    };

    void togglespectator(const char *arg1, const char *arg2)
    { dbg;
        if(!remote) return;
        int i = arg2[0] ? parseplayer(arg2) : clientnum,
            val = atoi(arg1);
        if(i>=0) addmsg(1, 3, SV_SPECTATOR, i, val);
    };

    // collect c2s messages conveniently
    ivector messages;

    void addmsg(int rel, int num, int type, ...)
    { dbg;
        if(spectator && (currentmaster!=clientnum || type<SV_MASTERMODE)) return;
        if(num!=fpsserver::msgsizelookup(type)) { s_sprintfd(s)("inconsistant msg size for %d (%d != %d)", type, num, fpsserver::msgsizelookup(type)); fatal(s); };
        messages.add(num);
        messages.add(rel);
        messages.add(type);
        va_list args;
        va_start(args, type);
        loopi(num-1) messages.add(va_arg(args, int));
        va_end(args);
    };

    void sendpacketclient(uchar *&p, bool &reliable, dynent *d)
    { dbg;
        uchar *start = p;
        if(toservermap[0])                      // suggest server to change map
        {                                       // do this exclusively as map change may invalidate rest of update
            reliable = true;
            putint(p, SV_MAPCHANGE);
            sendstring(toservermap, p);
            toservermap[0] = 0;
            putint(p, cl.nextmode);
            return;
        }
        if(!spectator || !c2sinit || ctext[0])
        { dbg;
            putint(p, SV_POS);
            putint(p, clientnum);
            putuint(p, (int)(d->o.x*DMF));              // quantize coordinates to 1/4th of a cube, between 1 and 3 bytes
            putuint(p, (int)(d->o.y*DMF));
            putuint(p, (int)(d->o.z*DMF));
            putuint(p, (int)d->rot.y);
            putint(p, (int)d->rot.x);
            putint(p, (int)d->rot.z);
            putint(p, (int)(d->vel.x*DVELF));          // quantize to itself, almost always 1 byte
            putint(p, (int)(d->vel.y*DVELF));
            putint(p, (int)(d->vel.z*DVELF));
            putint(p, (int)d->physstate | (!d->grav.iszero()<<4));
            if(!d->grav.iszero())
            { dbg;
                putint(p, (int)(d->grav.x*DVELF));      // quantize to itself, almost always 1 byte
                putint(p, (int)(d->grav.y*DVELF));
                putint(p, (int)(d->grav.z*DVELF));
            };
            // pack rest in 1 byte: strafe:2, move:2, state:3, reserved:1
            putint(p, (d->strafe&3) | ((d->move&3)<<2) | ((editmode ? CS_EDITING : (int) d->state)<<4) );
        };
        if(senditemstoserver)
        { dbg;
            reliable = true;
            putint(p, SV_ITEMLIST);
            int gamemode = cl.gamemode;
            if(!m_noitems) cl.et.putitems(p);
            putint(p, -1);
            if(m_capture) cl.cpc.sendbases(p);
            senditemstoserver = false;
        };
        if(ctext[0])    // player chat, not flood protected for now
        { dbg;
            reliable = true;
            putint(p, SV_TEXT);
            sendstring(ctext, p);
            ctext[0] = 0;
        };
        if(!c2sinit)    // tell other clients who I am
        { dbg;
            reliable = true;
            c2sinit = true;
            putint(p, SV_INITC2S);
            sendstring(player1->name, p);
            sendstring(player1->team, p);
            putint(p, player1->lifesequence);
            putint(p, player1->maxhealth);
            putint(p, player1->frags);
        };
        if(setmaster[0])
        { dbg;
            putint(p, SV_SETMASTER);
            putint(p, setmaster[1] ? 1 : atoi(setmaster));
            sendstring(setmaster[1] ? setmaster : "", p);
            setmaster[0] = '\0';
        };
        int i = 0;
        while(i < messages.length()) // send messages collected during the previous frames
        { dbg;
            int num = messages[i];
            if(p+5*num > start+MAXTRANS) break;
            if(messages[i+1]) reliable = true;
            i += 2;
            loopj(num) putint(p, messages[i++]);
        };
        messages.remove(0, i);
        if(MAXTRANS-(p-start)>=10 && cl.lastmillis-lastping>250)
        { dbg;
            putint(p, SV_PING);
            putint(p, cl.lastmillis);
            lastping = cl.lastmillis;
        };
    };

    void updatepos(fpsent *d)
    { dbg;
        // update the position of other clients in the game in our world
        // don't care if he's in the scenery or other players,
        // just don't overlap with our client

        const float r = player1->radius+d->radius;
        const float dx = player1->o.x-d->o.x;
        const float dy = player1->o.y-d->o.y;
        const float dz = player1->o.z-d->o.z;
        const float rz = player1->aboveeye+d->eyeheight;
        const float fx = (float)fabs(dx), fy = (float)fabs(dy), fz = (float)fabs(dz);
        if(fx<r && fy<r && fz<rz && player1->state!=CS_SPECTATOR && d->state!=CS_DEAD)
        { dbg;
            if(fx<fy) d->o.y += dy<0 ? r-fy : -(r-fy);  // push aside
            else      d->o.x += dx<0 ? r-fx : -(r-fx);
        };
        int lagtime = cl.lastmillis-d->lastupdate;
        if(lagtime)
        { dbg;
            d->plag = (d->plag*5+lagtime)/6;
            d->lastupdate = cl.lastmillis;
        };
    };

    void parsepacketclient(uchar *end, uchar *p)   // processes any updates from the server
    { dbg;
        int gamemode = cl.gamemode;
        char text[MAXTRANS];
        int cn = -1, type;
        fpsent *d = NULL;
        bool mapchanged = false, inited = false;

        while(p<end) switch(type = getint(p))
        {
            case SV_INITS2C:                    // welcome messsage from the server
            { dbg;
                cn = getint(p);
                int prot = getint(p);
                if(prot!=PROTOCOL_VERSION)
                { dbg;
                    conoutf("you are using a different game protocol (you: %d, server: %d)", PROTOCOL_VERSION, prot);
                    disconnect();
                    return;
                };
                toservermap[0] = 0;
                clientnum = cn;                 // we are now fully connected
                if(!getint(p)) s_strcpy(toservermap, cl.getclientmap());   // we are the first client on this server, set map
                break;
            };

            case SV_POS:                        // position of another client
            { dbg;
                cn = getint(p);
                d = cl.getclient(cn);
                if(!d) return;
                d->o.x = getuint(p)/DMF;
                d->o.y = getuint(p)/DMF;
                d->o.z = getuint(p)/DMF;
                d->rot.y = (float)getuint(p);
                d->rot.x = (float)getint(p);
                d->rot.z = (float)getint(p);
                d->vel.x = getint(p)/DVELF;
                d->vel.y = getint(p)/DVELF;
                d->vel.z = getint(p)/DVELF;
                int physstate = getint(p);
                d->physstate = physstate & 0x0F;
                if(physstate&0x10)
                { dbg;
                    d->grav.x = getint(p)/DVELF;
                    d->grav.y = getint(p)/DVELF;
                    d->grav.z = getint(p)/DVELF;
                }
                else d->grav = vec(0, 0, 0);
                int f = getint(p);
                d->strafe = (f&3)==3 ? -1 : f&3;
                f >>= 2;
                d->move = (f&3)==3 ? -1 : f&3;
                int state = (f>>2)&7;
                if(state==CS_DEAD && d->state!=CS_DEAD) d->lastaction = cl.lastmillis;
                d->state = state;
                updatephysstate(d);
                updatepos(d);
                inited = false;
                break;
            };

            case SV_SOUND:
                if(!d) return;
                playsound(getint(p), &d->o);
                break;

            case SV_TEXT:
            { dbg;
                if(!d) return;
                sgetstr(text, p);
                s_sprintfd(ds)("@%s", &text);
                if(d->state!=CS_DEAD && d->state!=CS_SPECTATOR) particle_text(d->abovehead(), ds, 9);
                conoutf("%s:\f0 %s", d->name, &text);
                break;
            };

            case SV_MAPCHANGE:
                sgetstr(text, p);
                changemapserv(text, getint(p));
                mapchanged = true;
                break;

            case SV_ITEMLIST:
            { dbg;
                int n;
                if(mapchanged) { senditemstoserver = false; cl.et.resetspawns(); };
                while((n = getint(p))!=-1)
                { dbg;
                    if(mapchanged) cl.et.setspawn(n, true);
                    getint(p); // type
                };
                break;
            };

            case SV_MAPRELOAD:          // server requests next map
            { dbg;
                getint(p);
                s_sprintfd(nextmapalias)("nextmap_%s%s", m_capture ? "capture_" : "", cl.getclientmap());
                char *map = getalias(nextmapalias);     // look up map in the cycle
                changemap(*map ? map : cl.getclientmap());
                break;
            };

            case SV_INITC2S:            // another client either connected or changed name/team
            { dbg;
                if(!d) return;
                s_sprintfd(aname)("%s", d->name);
                s_sprintfd(ateam)("%s", d->team);
                sgetstr(text, p);
                s_strcpy(d->name, text);
                sgetstr(text, p);
                s_strcpy(d->team, text);

                if(aname[0])          // already connected
                { dbg;
                    if(strcmp(d->name, aname))
                        conoutf("%s is now known as %s", d->name, aname);
                    else if(strcmp(d->team, ateam))
                        conoutf("%s is now on team %s", d->name, ateam);
                }
                else                    // new client
                { dbg;
                    c2sinit = false;    // send new players my info again
                    conoutf("connected: %s", d->name, d->team);
                    loopv(cl.players)   // clear copies since new player doesn't have them
                        if(cl.players[i]) freeeditinfo(cl.players[i]->edit);
                    extern editinfo *localedit;
                    freeeditinfo(localedit);
                };
                d->lifesequence = getint(p);
                d->maxhealth = getint(p);
                d->frags = getint(p);
                inited = true;
                break;
            };

            case SV_CDIS:
                cn = getint(p);
                if(!cl.players.inrange(cn) || !(d = cl.players[cn])) break;
                conoutf("player %s disconnected", d->name);
                DELETEP(cl.players[cn]);
                cleardynentcache();
                if(currentmaster==cn) currentmaster = -1;
                break;

            case SV_SHOT:
            { dbg;
                if(!d) return;
                int gun = getint(p);
                vec s, e;
                s.x = getint(p)/DMF;
                s.y = getint(p)/DMF;
                s.z = getint(p)/DMF;
                e.x = getint(p)/DMF;
                e.y = getint(p)/DMF;
                e.z = getint(p)/DMF;
                if(gun==GUN_SG) cl.ws.createrays(s, e);
                d->gunwait = 0;
                d->lastaction = cl.lastmillis;
                d->lastattackgun = d->gunselect;
                cl.ws.shootv(gun, s, e, d, false);
                break;
            };

            case SV_DAMAGE:
            { dbg;
                if(!d) return;
                int target = getint(p);
                int damage = getint(p);
                int ls = getint(p);
                vec dir;
                dir.x = getint(p)/DVELF;
                dir.y = getint(p)/DVELF;
                dir.z = getint(p)/DVELF;
                if(target==clientnum)
                { dbg;
                    if(ls==player1->lifesequence) { cl.selfdamage(damage, cn, d); player1->vel.add(dir); };
                }
                else
                { dbg;
                    fpsent *victim = cl.getclient(target);
                    victim->lastpain = cl.lastmillis;
                    vec v = victim->abovehead();
                    playsound(S_PAIN1+rnd(5), &v);
                    cl.ws.damageeffect(v, damage, "@(-%dh)", damage);
                };
                break;
            };

            case SV_DIED:
            { dbg;
                if(!d) return;
                int actor = getint(p);
                if(actor==cn)
                { dbg;
                    conoutf("\f2%s suicided", d->name);
                }
                else if(actor==clientnum)
                { dbg;
                    int frags;
                    if(isteam(player1->team, d->team))
                    { dbg;
                        frags = -1;
                        conoutf("\f2you fragged a teammate (%s)", d->name);
                    }
                    else
                    { dbg;
                        frags = 1;
                        conoutf("\f2you fragged %s", d->name);
                    };
                    addmsg(1, 2, SV_FRAGS, player1->frags += frags);
                }
                else
                { dbg;
                    fpsent *a = cl.getclient(actor);
                    if(a)
                    { dbg;
                        if(isteam(a->team, d->name))
                        { dbg;
                            conoutf("\f2%s fragged his teammate (%s)", a->name, d->name);
                        }
                        else
                        { dbg;
                            conoutf("\f2%s fragged %s", a->name, d->name);
                        };
                    };
                };
                playsound(S_DIE1+rnd(2), &d->o);
                if(!inited) d->lifesequence++;
                break;
            };

            case SV_FRAGS:
            { dbg;
                if(!d) return;
                s_sprintfd(ds)("@%d", d->frags = getint(p));
                particle_text(d->abovehead(), ds, 9);
                break;
            };

            case SV_RESUME:
            { dbg;
                cn = getint(p);
                d = (cn == clientnum ? player1 : cl.getclient(cn));
                if(!d) return;
                d->maxhealth = getint(p);
                d->frags = getint(p);
                break;
            };

            case SV_ITEMPICKUP:
            { dbg;
                if(!d) return;
                int i = getint(p);
                getint(p);
                if(!cl.et.ents.inrange(i)) break;
                cl.et.setspawn(i, false);
                char *name = cl.et.itemname(i);
                if(name) particle_text(d->abovehead(), name, 9);
                if(cl.et.ents[i]->type==I_BOOST && !inited) d->maxhealth += 10;
                break;
            };

            case SV_ITEMSPAWN:
            { dbg;
                int i = getint(p);
                if(!cl.et.ents.inrange(i)) break;
                cl.et.setspawn(i, true);
                playsound(S_ITEMSPAWN, &cl.et.ents[i]->o);
                char *name = cl.et.itemname(i);
                if(name) particle_text(cl.et.ents[i]->o, name, 9);
                break;
            };

            case SV_ITEMACC:            // server acknowledges that I picked up this item
                cl.et.realpickup(getint(p), player1);
                break;

            case SV_EDITF:              // coop editing messages
            case SV_EDITT:
            case SV_EDITM:
            case SV_FLIP:
            case SV_COPY:
            case SV_PASTE:
            case SV_ROTATE:
            case SV_REPLACE:
            case SV_MOVE:
            case SV_EDITRG:
            case SV_EDITLM:
            { dbg;
                if(!d) return;
                selinfo sel;
                sel.o.x = getint(p); sel.o.y = getint(p); sel.o.z = getint(p);
                sel.s.x = getint(p); sel.s.y = getint(p); sel.s.z = getint(p);
                sel.grid = getint(p); sel.orient = getint(p);
                sel.cx = getint(p); sel.cxs = getint(p); sel.cy = getint(p), sel.cys = getint(p);
                sel.corner = getint(p);
                sel.ent = -1;
                int dir, mode, tex, newtex, mat, allfaces, rgn, tag, r, g, b, a;
                ivec moveo;
                switch(type)
                {
                    case SV_EDITF: dir = getint(p); mode = getint(p); mpeditface(dir, mode, sel, false); break;
                    case SV_EDITT: tex = getint(p); allfaces = getint(p); mode = getint(p), mpedittex(tex, allfaces, mode, sel, false); break;
                    case SV_EDITM: mat = getint(p); tag = getint(p); r = getint(p); g = getint(p); b = getint(p); a = getint(p); mpeditmat(mat, tag, r, g, b, a, sel, false); break;
                    case SV_EDITRG: rgn = getint(p); tag = getint(p); mpeditrgn(rgn, tag, sel, false); break;
                    case SV_EDITLM: mat = getint(p); r = getint(p); g = getint(p); b = getint(p); mpeditelem(mat, r, g, b, sel, false); break;
                    case SV_FLIP: mpflip(sel, false); break;
                    case SV_COPY: if(d) mpcopy(d->edit, sel, false); break;
                    case SV_PASTE: if(d) mppaste(d->edit, sel, false); break;
                    case SV_ROTATE: dir = getint(p); mprotate(dir, sel, false); break;
                    case SV_REPLACE: tex = getint(p); newtex = getint(p); mode = getint(p); mpreplacetex(tex, newtex, mode, sel, false); break;
                    case SV_MOVE: moveo.x = getint(p); moveo.y = getint(p); moveo.z = getint(p); mpmovecubes(moveo, sel, false); break;
                };
                break;
            };
            case SV_EDITENT:            // coop edit of ent
            { dbg;
                if(!d) return;
                int i = getint(p);
                float x = getint(p)/DMF, y = getint(p)/DMF, z = getint(p)/DMF;
                int type = getint(p);
                int attr1 = getint(p), attr2 = getint(p), attr3 = getint(p), attr4 = getint(p);

                mpeditent(i, vec(x, y, z), type, attr1, attr2, attr3, attr4, false);
                break;
            };

            case SV_PONG:
                addmsg(0, 2, SV_CLIENTPING, player1->ping = (player1->ping*5+cl.lastmillis-getint(p))/6);
                break;

            case SV_CLIENTPING:
                if(!d) return;
                d->ping = getint(p);
                break;

            case SV_GAMEMODE:
                cl.nextmode = getint(p);
                break;

            case SV_TIMEUP:
                cl.timeupdate(getint(p));
                break;

            case SV_SERVMSG:
                sgetstr(text, p);
                conoutf("%s", text);
                break;

            case SV_CURRENTMASTER:
                currentmaster = getint(p);
                break;

            case SV_PING:
            case SV_MASTERMODE:
            case SV_KICK:
                getint(p);
                break;

            case SV_SPECTATOR:
            { dbg;
                int sn = getint(p), val = getint(p);
                fpsent *s;
                if(sn==clientnum)
                { dbg;
                    spectator = val!=0;
                    s = player1;
                }
                else s = cl.getclient(sn);
                if(!s) return;
                if(val)
                { dbg;
                    if(editmode) toggleedit();
                    s->state = CS_SPECTATOR;
                }
                else if(s->state==CS_SPECTATOR) s->state = CS_ALIVE;
                break;
            };

            case SV_BASES:
            { dbg;
                while(getint(p)!=-1)
                { dbg;
                    getint(p);
                    getint(p);
                };
                break;
            };

            case SV_BASEINFO:
            { dbg;
                int base = getint(p);
                string owner, enemy;
                int converted;
                sgetstr(text, p);
                s_strcpy(owner, text);
                sgetstr(text, p);
                s_strcpy(enemy, text);
                converted = getint(p);
                int gamemode = cl.gamemode;
                if(m_capture) cl.cpc.updatebase(base, owner, enemy, converted);
                break;
            };

            case SV_TEAMSCORE:
            { dbg;
                sgetstr(text, p);
                int total = getint(p), gamemode = cl.gamemode;
                if(m_capture) cl.cpc.setscore(text, total);
                break;
            };

            case SV_REPAMMO:
            { dbg;
                if(!d) return;
                int target = getint(p), gun1 = getint(p), gun2 = getint(p);
                int gamemode = cl.gamemode;
                if(m_capture && target==clientnum) cl.cpc.recvammo(d, gun1, gun2);
                break;
            };

            case SV_GETMAP:
            case SV_FORCEINTERMISSION:
                break;

            case SV_ANNOUNCE:
            { dbg;
                int t = getint(p);
                if     (t==I_QUAD)  { conoutf("\f2quad damage will spawn in 10 seconds!"); }
                else if(t==I_BOOST) { conoutf("\f2+10 health will spawn in 10 seconds!"); };
                playsound(S_V_REGENWARN);
                break;
            };

            default:
                neterr("type");
                return;
        };
    };

    void changemapserv(char *name, int gamemode)        // forced map change from the server
    { dbg;
        if(remote && !m_mp(gamemode)) gamemode = 0;
        cl.gamemode = gamemode;
        if(editmode && !allowedittoggle()) toggleedit();
        load_world(name);
        if(m_capture) cl.cpc.setupbases();
    };

    void changemap(char *name)                      // request map change, server may ignore
    { dbg;
        if(!spectator || currentmaster==clientnum) s_strcpy(toservermap, name);
    };

    void receivefile(uchar *data, int len)
    { dbg;
        if(cl.gamemode!=1) return;
        s_sprintfd(mname)("getmap_%d", cl.lastmillis);
        s_sprintfd(fname)("packages/base/%s.ogz", mname);
        FILE *map = fopen(fname, "wb");
        if(!map) return;
        conoutf("received map");
        fwrite(data, 1, len, map);
        fclose(map);
        load_world(mname);
        remove(fname);
    };

    void getmap()
    { dbg;
        if(cl.gamemode!=1) { conoutf("\"getmap\" only works in coopedit mode"); return; };
        conoutf("getting map...");
        addmsg(1, 1, SV_GETMAP);
    };

    void sendmap()
    { dbg;
        if(cl.gamemode!=1 || (spectator && currentmaster!=clientnum)) { conoutf("\"sendmap\" only works in coopedit mode"); return; };
        conoutf("sending map...");
        s_sprintfd(mname)("sendmap_%d", cl.lastmillis);
        save_world(mname, true);
        s_sprintfd(fname)("packages/base/%s.ogz", mname);
        FILE *map = fopen(fname, "rb");
        if(map)
        { dbg;
            fseek(map, 0, SEEK_END);
            if(ftell(map) > 1024*1024) conoutf("map is too large");
            else sendfile(-1, map);
            fclose(map);
        };
        remove(fname);
    };
};
