
struct entities : icliententities
{
    fpsclient &cl;
    
    vector<extentity *> ents;

    int triggertime;

    struct itemstat { int add, max, sound; char *name; } *itemstats;

    entities(fpsclient &_cl) : cl(_cl), triggertime(1)
    {
        static itemstat _itemstats[] =
        {
            {10,    30,    S_ITEMAMMO,   "SG"},
            {20,    60,    S_ITEMAMMO,   "MG"},
            {5,     15,    S_ITEMAMMO,   "RL"},
            {5,     15,    S_ITEMAMMO,   "RI"},
            {10,    30,    S_ITEMAMMO,   "GL"},
            {30,    120,   S_ITEMAMMO,   "PI"},
            {25,    100,   S_ITEMHEALTH, "H"},
            {10,    1000,  S_ITEMHEALTH, "MH"},
            {100,   100,   S_ITEMARMOUR, "GA"},
            {200,   200,   S_ITEMARMOUR, "YA"},
            {20000, 30000, S_V_QUAD,      "Q"},
        };
        itemstats = _itemstats;
    };

    vector<extentity *> &getents() { return ents; };
    
    char *itemname(int i)
    { dbg;
        int t = ents[i]->type;
        if(t<I_SHELLS || t>I_QUAD) return NULL;
        return itemstats[t-I_SHELLS].name;
    };
    
    void renderent(extentity &e, const char *mdlname, float z, float yaw, int frame = 0, int anim = ANIM_MAPMODEL|ANIM_LOOP, int basetime = 0, float speed = 10.0f)
    { dbg;
        rendermodel(e.color, e.dir, mdlname, anim, 0, 0, e.o.x, e.o.y, z+e.o.z, yaw, 0, false, speed, basetime);
    };

    void renderentities()
    { dbg;
        if(cl.lastmillis>triggertime+1000) triggertime = 0;
        loopv(ents)
        { dbg;
            static char *entmdlnames[] =
            {
                "shells", "bullets", "rockets", "rrounds", "grenades", "cartridges", "health", "boost",
                "g_armour", "y_armour", "quad", "teleporter",
            };

            extentity &e = *ents[i];
            if(e.type==CARROT || e.type==RESPAWNPOINT)
            { dbg;
                renderent(e, e.type==CARROT ? "carrot" : "checkpoint", (float)(1+sin(cl.lastmillis/100.0+e.o.x+e.o.y)/20), cl.lastmillis/(e.attr2 ? 1.0f : 10.0f));
                continue;
            };
            if(!e.spawned && e.type!=TELEPORT) continue;
            if(e.type<I_SHELLS || e.type>TELEPORT) continue;
            renderent(e, entmdlnames[e.type-I_SHELLS], (float)(1+sin(cl.lastmillis/100.0+e.o.x+e.o.y)/20), cl.lastmillis/10.0f);
        };
    };

    void rumble(const extentity &e)
    { dbg;
        playsound(S_RUMBLE, &e.o);
    };

    void trigger(extentity &e)
    { dbg;
        if(e.attr3==29) cl.ms.endsp(false);
    };

    void baseammo(fpsent *d, int gun) { d->ammo[gun] = itemstats[gun-1].add*2; };
    void repammo(int gun) 
    { 
        int &ammo = cl.player1->ammo[gun];
        ammo = max(ammo, itemstats[gun-1].add*2);
    };

    // these two functions are called when the server acknowledges that you really
    // picked up the item (in multiplayer someone may grab it before you).

    void radditem(int i, int &v)
    { dbg;
        itemstat &is = itemstats[ents[i]->type-I_SHELLS];
        ents[i]->spawned = false;
        v += is.add;
        if(v>is.max) v = is.max;
        cl.playsoundc(is.sound);
    };

    void realpickup(int n, fpsent *d)
    { dbg;
        if(isthirdperson())
        { dbg;
            char *name = itemname(n);
            if(name) particle_text(d->abovehead(), name, 9);
        };
        switch(ents[n]->type)
        {
            case I_SHELLS:     radditem(n, d->ammo[GUN_SG]); break;
            case I_BULLETS:    radditem(n, d->ammo[GUN_CG]); break;
            case I_ROCKETS:    radditem(n, d->ammo[GUN_RL]); break;
            case I_ROUNDS:     radditem(n, d->ammo[GUN_RIFLE]); break;
            case I_GRENADES:   radditem(n, d->ammo[GUN_GL]); break;
            case I_CARTRIDGES: radditem(n, d->ammo[GUN_PISTOL]); break;
            case I_HEALTH:     radditem(n, d->health); break;

            case I_BOOST:
                d->maxhealth += 10;
                if (d==cl.player1)
                {
	                conoutf("\f2you have a permanent +10 health bonus! (%d)", d->maxhealth);
				}
                cl.playsoundc(S_V_BOOST);
                radditem(n, d->health);
                break;

            case I_GREENARMOUR:
                radditem(n, d->armour);
                d->armourtype = A_GREEN;
                break;

            case I_YELLOWARMOUR:
                radditem(n, d->armour);
                d->armourtype = A_YELLOW;
                break;

            case I_QUAD:
                radditem(n, d->quadmillis);
                if (d==cl.player1)
                {
	                conoutf("\f2you got the quad!");
				}
                cl.playsoundc(S_V_QUAD);
                break;
        };
    };

    // these functions are called when the client touches the item

    void additem(int i, int &v, int spawnsec)
    { dbg;
        if(v<itemstats[ents[i]->type-I_SHELLS].max)                              // don't pick up if not needed
        { dbg;
            int gamemode = cl.gamemode;
            cl.cc.addmsg(1, 3, SV_ITEMPICKUP, i, m_classicsp ? 100000 : spawnsec);     // first ask the server for an ack
            ents[i]->spawned = false;                                            // even if someone else gets it first
        };
    };

	void teleport(int n, fpsent *d)
	{
    	particle_splash(15, 500, 1000, d->o);
        d->o = ents[n]->o;
        d->rot.y = ents[n]->attr1;
        d->rot.x = 0;
        d->vel = vec(0, 0, 0);//vec(cosf(RAD*(d->rot.y-90)), sinf(RAD*(d->rot.y-90)), 0);
        entinmap(d);
        cl.playsoundc(S_TELEPORT);
    	particle_splash(15, 500, 1000, d->o);
	}

    void teleent(int n, fpsent *d)     // also used by monsters
    { dbg;
        int e = -1, tag = ents[n]->attr1, beenhere = -1;
        for(;;)
        { dbg;
            e = findentity(TELEDEST, e+1);
            if(e==beenhere || e<0) { conoutf("no teleport destination for tag %d", tag); return; };
            if(beenhere<0) beenhere = e;
            if(ents[e]->attr2==tag)
            { dbg;
				teleport(e, d);
                break;
            };
        };
    };

    void telergn(int tag, fpsent *d)     // also used by monsters
    { dbg;
        int e = -1, beenhere = -1;
        for(;;)
        { dbg;
            e = findentity(TELEDEST, e+1);
            if(e==beenhere || e<0) { conoutf("no teleport destination for tag %d", tag); return; };
            if(beenhere<0) beenhere = e;
            if(ents[e]->attr2==tag)
            { dbg;
				teleport(e, d);
                break;
            };
        };
    };

    void pickup(int n, fpsent *d)
    { dbg;
        int np = 1;
        loopv(cl.players) if(cl.players[i] && cl.players[i]->state!=CS_SPECTATOR) np++;

        np = np<3 ? 4 : (np>4 ? 2 : 3);         // spawn times are dependent on number of players
        int ammo = np*4;
        switch(ents[n]->type)
        {
            case I_SHELLS:     additem(n, d->ammo[GUN_SG], ammo); break;
            case I_BULLETS:    additem(n, d->ammo[GUN_CG], ammo); break;
            case I_ROCKETS:    additem(n, d->ammo[GUN_RL], ammo); break;
            case I_ROUNDS:     additem(n, d->ammo[GUN_RIFLE], ammo); break;
            case I_GRENADES:   additem(n, d->ammo[GUN_GL], ammo); break;
            case I_CARTRIDGES: additem(n, d->ammo[GUN_PISTOL], ammo); break;
            case I_HEALTH:     additem(n, d->health,  np*5); break;
            case I_BOOST:      additem(n, d->health,  60); break;

            case I_GREENARMOUR:
                // (100h/100g only absorbs 200 damage)
                if(d->armourtype==A_YELLOW && d->armour>=100) break;
                additem(n, d->armour, 20);
                break;

            case I_YELLOWARMOUR:
                additem(n, d->armour, 20);
                break;

            case I_QUAD:
                additem(n, d->quadmillis, 60);
                break;
                
            case TELEPORT:
            { dbg;
                if(cl.lastmillis-ents[n]->lasttrigger<500) break;
                ents[n]->lasttrigger = cl.lastmillis;
                teleent(n, d);
                break;
            };

            case RESPAWNPOINT:
                if(n==cl.respawnent) break;
                cl.respawnent = n;
                conoutf("\f2respawn point set!");
                cl.playsoundc(S_V_RESPAWNPOINT);
                break;

            case JUMPPAD:
            { dbg;
                if(cl.lastmillis-ents[n]->lasttrigger<300) break;
                ents[n]->lasttrigger = cl.lastmillis;
                vec v((int)(char)ents[n]->attr3*10.0f, (int)(char)ents[n]->attr2*10.0f, ents[n]->attr1*12.5f);
                d->timeinair = 0;
                d->grav = vec(0, 0, 0);
                d->vel = v;
//                cl.player1->vel.z = 0;
//                cl.player1->vel.add(v);
                cl.playsoundc(S_JUMPPAD);
                break;
            };
        };
    };

    bool inlos(vec &o, vec &q, vec &v)
    { dbg;
        vec ray(q.x, q.y, q.z);
        ray.sub(o);
        v.sub(v);
        float mag = ray.magnitude();
        float distance = raycubepos(o, ray, v, mag, RAY_CLIPMAT|RAY_POLY);
        return distance >= mag; 
    };

    void checkitems(fpsent *d)
    { dbg;
        if(d->state == CS_EDITING || d->state == CS_SPECTATOR) return;
        itemstats[I_HEALTH-I_SHELLS].max = d->maxhealth;
        vec o = d->o;
        o.z -= d->eyeheight;
        loopv(ents)
        { dbg;
            extentity &e = *ents[i];
            if(e.type==NOTUSED) continue;
            if (e.type==SHOOTER && e.attr3==0 && cl.lastmillis-e.lasttrigger>e.attr5)
            {
				vec target;
				if (inlos(e.o, d->o, target))
				{
					
					e.lasttrigger = cl.lastmillis;
				}
			}
            if(!e.spawned && e.type!=TELEPORT && e.type!=JUMPPAD && e.type!=RESPAWNPOINT) continue;
			float dist = e.o.dist(o);
            if(dist<(e.type==TELEPORT ? 16 : 12)) pickup(i, d);
        };
    };

	void checkregions(fpsent *d)
	{ dbg;
	    if(d->state != CS_ALIVE) return;

		vec p(d->o.x - d->radius, d->o.y - d->radius, d->o.z - d->eyeheight);
		vec t(d->o.x + d->radius, d->o.y + d->radius, d->o.z + d->aboveeye );
		
		for (; p.x <= t.x; p.x += 1.0f)
		{
			for (; p.y <= t.y; p.y += 1.0f)
			{
				for (; p.y <= t.y; p.y += 1.0f)
				{
					int rgn = getcuberegion((int)p.x, (int)p.y, (int)p.z);
				    int tag = getcubergntag((int)p.x, (int)p.y, (int)p.z);
	
				    switch (rgn)
				    {
						case RGN_TELEPORT:
							{
				                static int rlastteleport = 0;
				                if(cl.lastmillis-rlastteleport<500) break;
				                rlastteleport = cl.lastmillis;
				                telergn(tag, d);
								break;
							}
						case RGN_TRIGGER:
							{
				                static int rlasttrigger = 0;
				                if(cl.lastmillis-rlasttrigger<1000) break;
				                rlasttrigger = cl.lastmillis;
							    s_sprintfd(aliasname)("region_trigger_%d", tag);
							    if(identexists(aliasname))
							    { dbg;
							        execute(aliasname);
							    };
								break;
							}
						default:
								break;
					}
				}
			}
		}
	};

    void checkquad(fpsent *d, int time)
    { dbg;
        if(d->quadmillis && (d->quadmillis -= time)<0)
        { dbg;
            d->quadmillis = 0;
            
           	cl.playsoundc(S_V_QUADFADE);

			if (d==cl.player1)
			{
            	conoutf("\f2quad damage is over");
			}
        };
    };

    void putitems(uchar *&p)            // puts items in network stream and also spawns them locally
    { dbg;
        int gamemode = cl.gamemode;
        loopv(ents) if(ents[i]->type>=I_SHELLS && ents[i]->type<=I_QUAD)
        { dbg;
            putint(p, i);
            putint(p, ents[i]->type);
            
            ents[i]->spawned = (m_sp || (ents[i]->type!=I_QUAD && ents[i]->type!=I_BOOST)); 
        };
    };

    void resetspawns() { loopv(ents) ents[i]->spawned = false; };
    void setspawn(int i, bool on) { if(ents.inrange(i)) ents[i]->spawned = on; };

    extentity *newentity() { return new fpsentity(); };

    void fixentity(extentity &e)
    { dbg;
        switch(e.type)
        {
            case MONSTER:
            case TELEDEST:
                e.attr2 = e.attr1;
            case RESPAWNPOINT:
                e.attr1 = (int)cl.player1->rot.y;
            case SHOOTER:
                e.attr1 = (int)cl.player1->rot.y;
                e.attr2 = (int)cl.player1->rot.x;
        };
    };

    const char *entnameinfo(entity &e) { return ""; };
    const char *entname(int i)
    { dbg;
        static const char *entnames[] =
        {
            "none?", "light", "mapmodel", "playerstart",
            "shells", "bullets", "rockets", "riflerounds", "grenades", "cartridges",
            "health", "healthboost", "greenarmour", "yellowarmour", "quaddamage",
            "teleport", "teledest",
            "monster", "carrot", "jumppad",
            "base", "respawnpoint", "ball", "shooter",
            "", "", "", "",
        };
        return i>=0 && i<(int)(sizeof(entnames)/sizeof(entnames[0])) ? entnames[i] : "";
    };
    
    int extraentinfosize() { return 0; };       // size in bytes of what the 2 methods below read/write... so it can be skipped by other games

    void writeent(entity &e, char *buf)   // write any additional data to disk (except for ET_ ents)
    {
    };

    void readent(entity &e, char *buf)     // read from disk, and init
    { dbg;
    	if (!tessmap)
    	{ dbg;
	        if(tessver <= 10)
	        { dbg;
	            if(e.type >= 7) e.type++;
	        };
	        if(tessver <= 12)
	        { dbg;
	            if(e.type >= 8) e.type++;
	        };
		}
    };

    void editent(int i)
    { dbg;
        extentity &e = *ents[i];
        if(e.type==BASE)
        { dbg;
            int gamemode = cl.gamemode;
            if(m_capture) cl.cpc.setupbases();
        };
        cl.cc.addmsg(1, 10, SV_EDITENT, i, (int)(e.o.x*DMF), (int)(e.o.y*DMF), (int)(e.o.z*DMF), e.type, e.attr1, e.attr2, e.attr3, e.attr4);
    };

    float dropheight(entity &e)
    { dbg;
        if(e.type==MAPMODEL || e.type==BASE) return 0.0f;
        return 4.0f;
    };
};
