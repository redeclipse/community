// script binding functionality


enum { ID_VAR, ID_COMMAND, ID_ICOMMAND, ID_ALIAS };

enum { NO_OVERRIDE = INT_MAX, OVERRIDDEN = 0 };

template <class T> struct tident
{
    int _type;           // one of ID_* above
    char *_name;
    int _min, _max;      // ID_VAR
    int *_storage;       // ID_VAR
    int _override;       // either NO_OVERRIDE, OVERRIDDEN, or value
    void (*_fun)();      // ID_VAR, ID_COMMAND
    char *_narg;         // ID_VAR, ID_COMMAND, ID_ICOMMAND
    char *_action;       // ID_ALIAS
    int _persist;        // ID_VAR, ID_ALIAS
    int _world;		 	 // ID_VAR
    int _tess;			 // ID_VAR
    char *_isexecuting;  // ID_ALIAS
    T *self;
    
    tident() {};
    tident(int t, char *n, int m, int x, int *s, void *f, char *g, char *a, int p, int w, int c, T *_s)
        : _type(t), _name(n), _min(m), _max(x), _storage(s), _override(NO_OVERRIDE), _fun((void (__cdecl *)(void))f), _narg(g), _action(a), _persist(p), _world(w), _tess(c), _isexecuting(0), self(_s) {};
    virtual ~tident() {};        

    tident &operator=(const tident &o) { memcpy(this, &o, sizeof(tident)); return *this; };        // force vtable copy, ugh
    
    int operator()() { return (int)(size_t)_narg; };
    
    virtual void run(char **args) {};
};

typedef tident<void> ident;

extern void addident(char *name, ident *id);
extern void ints(int v);
extern void result(const char *s);

// nasty macros for registering script functions, abuses globals to avoid excessive infrastructure
#define COMMANDN(name, fun, nargs) static bool __dummy_##fun = addcommand(#name, (void (*)())fun, nargs, false, false)
#define COMMAND(name, nargs) COMMANDN(name, name, nargs)
#define TCOMMAND(name, nargs) static bool __dummy_##name = addcommand(#name, (void (*)())name, nargs, false, true)
#define WCOMMAND(name, nargs) static bool __dummy_##name = addcommand(#name, (void (*)())name, nargs, true, false)

#define _VAR(name, global, min, cur, max, persist)  int global = variable(#name, min, cur, max, &global, NULL, persist, false, false)
#define VARN(name, global, min, cur, max) _VAR(name, global, min, cur, max, false)
#define VAR(name, min, cur, max) _VAR(name, name, min, cur, max, false)
#define VARP(name, min, cur, max) _VAR(name, name, min, cur, max, true)
#define _VARF(name, global, min, cur, max, body, persist)  void var_##name(); int global = variable(#name, min, cur, max, &global, var_##name, persist, false, false); void var_##name() { body; }
#define VARFN(name, global, min, cur, max, body) _VARF(name, global, min, cur, max, body, false)
#define VARF(name, min, cur, max, body) _VARF(name, name, min, cur, max, body, false)
#define VARFP(name, min, cur, max, body) _VARF(name, name, min, cur, max, body, true)

#define WVAR(name, min, cur, max) int name = variable(#name, min, cur, max, &name, NULL, false, true, false)
#define TWVAR(name, min, cur, max) int name = variable(#name, min, cur, max, &name, NULL, false, true, true)

// new style macros, have the body inline, and allow binds to happen anywhere, even inside class constructors, and access the surrounding class
#define _COMMAND(t, ts, sv, tv, n, g, b) struct cmd_##n : tident<t> { cmd_##n(ts) : tident<t>(ID_ICOMMAND, #n, 0, 0, 0, 0, g, 0, false, false, false, sv) { addident(_name, (ident *)this); }; void run(char **args) { b; }; } icom_##n tv
#define ICOMMAND(n, g, b) _COMMAND(void, , NULL, , n, g, b)
#define CCOMMAND(t, n, g, b) _COMMAND(t, t *_s, _s, (this), n, g, b)
 
#define IVAR(n, m, c, x)  struct var_##n : ident { var_##n() : ident(ID_VAR, #n, m, x, (int *)&_narg, 0, (char *)c, 0, false, false, false, NULL) { addident(_name, this); }; } n
//#define ICALL(n, a) { char *args[] = a; icom_##n.run(args); }
