// this file defines static map entities ("entity") and dynamic entities (players/monsters, "dynent")
// the gamecode extends these types to add game specific functionality

// ET_*: the only static entity types dictated by the engine... rest are gamecode dependent

enum { ET_EMPTY=0, ET_LIGHT, ET_MAPMODEL, ET_PLAYERSTART, ET_GAMESPECIFIC };

struct entity                                   // persistent map entity
{
    vec o;                                      // position
    short attr1, attr2, attr3, attr4, attr5;
    uchar type;                                 // type is one of the above
    uchar reserved;
};

enum
{
    TRIGGER_RESET = 0,
    TRIGGERING,
    TRIGGERED,
    TRIGGER_RESETTING,
    TRIGGER_DISAPPEARED
};

struct extentity : entity                       // part of the entity that doesn't get saved to disk
{
    uchar spawned, inoctanode, visible, triggerstate;        // the only dynamic state of a map entity
    vec color, dir;
    int lasttrigger;

    extentity() : visible(false), triggerstate(TRIGGER_RESET), lasttrigger(0) {};
};

//extern vector<extentity *> ents;                // map entities

struct animstate                                // used for animation blending of animated characters
{
    int anim, frame, range, basetime;
    float speed;
    animstate() : anim(0), frame(0), range(0), basetime(0), speed(100.0f) {};

    bool operator==(const animstate &o) const { return frame==o.frame && range==o.range && basetime==o.basetime && speed==o.speed; };
    bool operator!=(const animstate &o) const { return frame!=o.frame || range!=o.range || basetime!=o.basetime || speed!=o.speed; };
};

enum
{
	ANIM_DYING 			= 0,
	ANIM_DEAD,			// 1
	ANIM_PAIN,			// 2
	ANIM_IDLE,			// 3
	ANIM_IDLE_ATTACK,	// 4
	ANIM_RUN, 			// 5
	ANIM_RUN_ATTACK,	// 6
	ANIM_EDIT,			// 7
	ANIM_LAG,			// 8
	ANIM_JUMP,			// 9
	ANIM_JUMP_ATTACK, 	// 10
	ANIM_CROUCH_DYING,	// 11
	ANIM_CROUCH_PAIN,	// 12
	ANIM_CROUCH_IDLE,	// 13
	ANIM_CROUCH_WALK,	// 14
	ANIM_CROUCH_ATTACK,	// 15
	ANIM_GUNSHOOT,		// 16
	ANIM_GUNIDLE,		// 17
	ANIM_MAPMODEL,		// 18
	ANIM_TRIGGER,		// 19
	NUMANIMS 			// 20
};

#define ANIM_INDEX      0xFF
#define ANIM_LOOP       (1<<8)
#define ANIM_START      (1<<9)
#define ANIM_END        (1<<10)
#define ANIM_REVERSE    (1<<11)

enum { CS_ALIVE = 0, CS_DEAD, CS_LAGGED, CS_EDITING, CS_SPECTATOR };
enum { PHYS_FLOAT = 0, PHYS_FALL, PHYS_SLIDE, PHYS_SLOPE, PHYS_FLOOR, PHYS_STEP_UP, PHYS_STEP_DOWN, PHYS_BOUNCE };
enum { ENT_PLAYER = 0, ENT_AI, ENT_CAMERA, ENT_BOUNCE, ENT_BALL };
enum { M_NONE = 0, M_SEARCH, M_HOME, M_ATTACKING, M_PAIN, M_SLEEP, M_AIMING };  // monster/ai states

struct physent                                  // base entity type, can be affected by physics
{
    vec o, vel, grav, rot, orient;              // origin, velocity, gravity, rotation, orientation
    float jyaw, jpitch;							// joystick impulses
    float maxspeed, weight;                     // cubes per second, 100 for player
    int timeinair, last;
    float radius, eyeheight, aboveeye;          // bounding box size
    vec floor;                                  // the normal of floor the dynent is on

    bool inwater;
    bool jumpnext, crouchnext;
    bool blocked, moving, crouch;               // used by physics to signal ai

    char move, strafe;

    uchar physstate;                            // one of PHYS_* above
    uchar state;                                // one of CS_* above
    uchar type;                                 // one of ENT_* above

    int aistate, airate;			  			// used for ai controls
    vec airot, aivec;		   					// targeting/homing vector
    int aims, aistart;             				// millis at which transition to another aistate takes place

    physent() : o(0, 0, 0), rot(0, 0, 0), maxspeed(100.f), weight(100.f),
               radius(4.1f), eyeheight(14.f), aboveeye(1.f), 
               inwater(false), blocked(false), moving(true), state(CS_ALIVE), type(ENT_PLAYER), aistate(M_NONE),
               airate(50), aims(0), aistart(0)
               { reset(); };
               
    void reset()
    {
        vel = grav = vec(0, 0, 0);
		jyaw = jpitch = 0.0f;
		jumpnext = crouchnext = crouch = false;
        timeinair = strafe = move = last = 0;
        physstate = PHYS_FALL;
    };
};

#define entcrouch(a,b) \
		if (tessmap) { \
			if ((b == true) && ((a)->crouch == false)) { (a)->eyeheight /= 2; (a)->aboveeye /= 2; (a)->o.z -= (a)->eyeheight; } \
			if ((b == false) && ((a)->crouch == true)) { (a)->o.z += (a)->eyeheight; (a)->eyeheight *= 2; (a)->aboveeye *= 2; } \
			(a)->crouch = (b == true ? true : false); \
			(a)->crouchnext = false; \
		}

struct dynent : physent                         // animated characters, or characters that can receive input
{
    bool k_left, k_right, k_up, k_down;         // see input code

    animstate prev[2], current[2];              // md2's need only [0], md3's need aih for the lower&upper model
    int lastanimswitchtime[2];

    dynent() : physent() { reset(); loopi(2) lastanimswitchtime[i] = -1; };
               
    void stopmoving()
    {
        k_left = k_right = k_up = k_down = jumpnext = crouchnext = false;
        move = strafe = 0;
    };
        
    void reset()
    {
        physent::reset();
        stopmoving();
    };

    vec abovehead() { return vec(o).add(vec(0, 0, aboveeye+4)); };
};

