#include "pch.h"
#include "engine.h"

VARP(watersubdiv, 0, 2, 3);
VARP(waterlod, 0, 1, 3);
TWVAR(waterwaves, 0, 1, 1);

int wx1, wy1, wx2, wy2, wsize;

static inline void vertw(int type, float v1, float v2, float v3, float t1, float t2, float t)
{ dbg;
    glTexCoord2f(t1, t2);
	if (type == 1)
	    glVertex3f(v1, v2, v3-1.1f-(float)sin((v1-wx1)/wsize*(v2-wy1)/wsize*(v1-wx2)*(v2-wy2)*59/23+t)*0.8f);
	else
	    glVertex3f(v1, v2, v3-1.0f);
};

static inline float dx(float x) { return x+(float)sin(x*2+lastmillis/1000.0f)*0.04f; };
static inline float dy(float x) { return x+(float)sin(x*2+lastmillis/900.0f+PI/5)*0.05f; };

// renders mat for bounding rect area that contains mat... simple but very inefficient

void rendermat(int type, uint subdiv, int x, int y, int z, uint size, int xx, int yy)
{ 
    float xf = 8.0f/xx;
    float yf = 8.0f/yy;
    float xs = subdiv*xf;
    float ys = subdiv*yf;
    float t1 = lastmillis/300.0f;
    float t2 = lastmillis/4000.f;
    
    wx1 = x;
    wy1 = y;
    wx2 = wx1 + size,
    wy2 = wy1 + size;
    wsize = size;
    
    ASSERT((wx1 & (subdiv - 1)) == 0);
    ASSERT((wy1 & (subdiv - 1)) == 0);

    for(int xx = wx1; xx<wx2; xx += subdiv)
    { dbg;
        float xo = xf*(xx+t2);
        glBegin(GL_TRIANGLE_STRIP);
        for(int yy = wy1; yy<wy2; yy += subdiv)
        { dbg;
            float yo = yf*(yy+t2);
            if(yy==wy1)
            { dbg;
                vertw(type, xx, yy, z, dx(xo), dy(yo), t1);
                vertw(type, xx+subdiv, yy, z, dx(xo+xs), dy(yo), t1);
            };
            vertw(type, xx, yy+subdiv, z, dx(xo), dy(yo+ys), t1);
            vertw(type, xx+subdiv, yy+subdiv, z, dx(xo+xs), dy(yo+ys), t1);
        };
        glEnd();
        int n = (wy2-wy1-1)/subdiv;
        n = (n+2)*2;
        xtraverts += n;
    };
};

uint calcmatsubdiv(int x, int y, int z, uint size)
{ dbg;
    float dist;
    if(player->o.x >= x && player->o.x < x + size &&
       player->o.y >= y && player->o.y < y + size)
        dist = fabs(player->o.z - float(z));
    else
    { dbg;
        vec t(x + size/2, y + size/2, z + size/2);
        dist = t.dist(player->o) - size*1.42f/2;
    };
    uint subdiv = watersubdiv + int(dist) / (32 << waterlod);
    if(subdiv >= 8*sizeof(subdiv))
        subdiv = ~0;
    else
        subdiv = 1 << subdiv;
    return subdiv;
};

uint rendermatlod(int type, int x, int y, int z, uint size, int xx, int yy)
{ dbg;
    if(size <= (uint)(32 << waterlod))
    { dbg;
        uint subdiv = calcmatsubdiv(x, y, z, size);
        if(subdiv < size * 2)
            rendermat(type, min(subdiv, size), x, y, z, size, xx, yy);
        return subdiv;
    }
    else
    { dbg;
        uint subdiv = calcmatsubdiv(x, y, z, size);
        if(subdiv >= size)
        { dbg;
            if(subdiv < size * 2)
                rendermat(type, size, x, y, z, size, xx, yy);
            return subdiv;
        };
        uint childsize = size / 2,
             subdiv1 = rendermatlod(type, x, y, z, childsize, xx, yy),
             subdiv2 = rendermatlod(type, x + childsize, y, z, childsize, xx, yy),
             subdiv3 = rendermatlod(type, x + childsize, y + childsize, z, childsize, xx, yy),
             subdiv4 = rendermatlod(type, x, y + childsize, z, childsize, xx, yy),
             minsubdiv = subdiv1;
        minsubdiv = min(minsubdiv, subdiv2);
        minsubdiv = min(minsubdiv, subdiv3);
        minsubdiv = min(minsubdiv, subdiv4);
        if(minsubdiv < size * 2)
        { dbg;
            if(minsubdiv >= size)
                rendermat(type, size, x, y, z, size, xx, yy);
            else
            { dbg;
                if(subdiv1 >= size) 
                    rendermat(type, childsize, x, y, z, childsize, xx, yy);
                if(subdiv2 >= size) 
                    rendermat(type, childsize, x + childsize, y, z, childsize, xx, yy);
                if(subdiv3 >= size) 
                    rendermat(type, childsize, x + childsize, y + childsize, z, childsize, xx, yy);
                if(subdiv4 >= size) 
                    rendermat(type, childsize, x, y + childsize, z, childsize, xx, yy);
            };
        };
        return minsubdiv;
    };
};

void renderfall(materialsurface &m, float offset, int xx, int yy)
{ dbg;
    float xf = 8.0f/xx;
    float yf = 8.0f/yy;
    float d = lastmillis/4000.f;
    int dim = dimension(m.orient), 
        csize = C[dim]==2 ? m.rsize : m.csize,
        rsize = R[dim]==2 ? m.rsize : m.csize;

    glBegin(GL_POLYGON);
    loopi(4)
    { dbg;
        vec v(m.o.tovec());
        v[dim] += dimcoord(m.orient) ? -offset : offset; 
        if(i == 1 || i == 2) v[dim^1] += csize;
        if(i <= 1) v.z += rsize;
        glTexCoord2f(xf*v[dim^1], yf*(v.z+d));
        glVertex3fv(v.v);
    };
    glEnd();

    xtraverts += 4;
};

int visiblematerial(cube &c, int orient, int x, int y, int z, int size)
{ dbg;
    switch(c.material)
    {
    case MAT_AIR:
         break;

    case MAT_WATER:
    case MAT_FOG:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return (orient != O_BOTTOM ? MATSURF_VISIBLE : MATSURF_EDIT_ONLY);
        break;

    case MAT_GLASS:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return MATSURF_VISIBLE;
        break;

    default:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return MATSURF_EDIT_ONLY;
        break;
    };
    return MATSURF_NOT_VISIBLE; 
};   

int matsurfcmp(const materialsurface *x, const materialsurface *y)
{ dbg;
    if(x->material < y->material) return -1;
    if(x->material > y->material) return 1;
    if(x->mattag < y->mattag) return -1;
    if(x->mattag > y->mattag) return 1;
    if(x->mattex < y->mattex) return -1;
    if(x->mattex > y->mattex) return 1;
    if(x->matcol[0] < y->matcol[0]) return -1;
    if(x->matcol[0] > y->matcol[0]) return 1;
    if(x->matcol[1] < y->matcol[1]) return -1;
    if(x->matcol[1] > y->matcol[1]) return 1;
    if(x->matcol[2] < y->matcol[2]) return -1;
    if(x->matcol[2] > y->matcol[2]) return 1;
    if(x->matcol[3] < y->matcol[3]) return -1;
    if(x->matcol[3] > y->matcol[3]) return 1;
    if(x->orient < y->orient) return -1;
    if(x->orient > y->orient) return 1;
    int dim = dimension(x->orient), xc = x->o[dim], yc = y->o[dim];
    if(xc < yc) return -1;
    if(xc > yc) return 1;
    return 0;
};


void sortmatsurfs(materialsurface *matsurf, int matsurfs)
{ dbg;
    qsort(matsurf, matsurfs, sizeof(materialsurface), (int (*)(const void*, const void*))matsurfcmp);
};

void drawface(int orient, int x, int y, int z, int csize, int rsize, float offset, float xx, float yy)
{ dbg;
    float xf = 8.0f/xx;
    float yf = 8.0f/yy;
    int dim = dimension(orient), c = C[dim], r = R[dim];
    glBegin(GL_POLYGON);
    loopi(4)
    { dbg;
        int coord = fv[orient][i];
        int cc = cubecoords[coord][c]/8*csize;
        int rr = cubecoords[coord][r]/8*rsize;
        vec v(x, y, z);

        v[dim] += dimcoord(orient) ? -offset : offset;
		v[c] += cc;
        v[r] += rr;

        glTexCoord2f(xf*v.x, yf*v.y);
        glVertex3fv(v.v);
    };
    glEnd();

    xtraverts += 4;
};

void watercolour(int *r, int *g, int *b)
{ dbg;
	if (!tessmap)
	{
    	hdr.watercolour[0] = *r;
    	hdr.watercolour[1] = *g;
    	hdr.watercolour[2] = *b;
	}
	else
	{
		conoutf("water material colour is now defined when using editmat");
	}
};
COMMAND(watercolour, "iii");

VAR(showmat, 0, 1, 1);

void rendermatsurfs(materialsurface *matbuf, int matsurfs)
{ dbg;
    if(!matsurfs) return;
	if (tessmap)
	{
		int xx, yy;
		Texture *t;
		uchar wcol[4] = { 0, 0, 0, 0 };
		
		#define tessmat(mat, s) \
		{ \
			loopi(matsurfs) { \
				materialsurface &m = matbuf[i]; \
				if(m.material==mat) { \
					wcol[0] = m.matcol[0]; wcol[1] = m.matcol[1]; wcol[2] = m.matcol[2]; wcol[3] = m.matcol[3]; \
					glColor4ubv(wcol); \
			        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); \
					if (m.mattex != DEFAULT_SKY) { defaultshader->set(); t = lookuptexture(m.mattex).sts[0].t; glEnable(GL_TEXTURE_2D); glBindTexture(GL_TEXTURE_2D, t->gl); } \
					else { notextureshader->set(); glDisable(GL_TEXTURE_2D); } \
					xx = t->xs; \
					yy = t->ys; \
					s; \
				}; \
			} \
		}

		#define tessfill(mat, r, g, b, a, s) \
		{ \
			wcol[0] = r; wcol[1] = g; wcol[2] = b; wcol[3] = a; \
			glColor4ubv(wcol); \
	        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); \
	        notextureshader->set(); \
			glDisable(GL_TEXTURE_2D); \
			loopi(matsurfs) { \
				materialsurface &m = matbuf[i]; \
				if(m.material==mat) { s; }; \
			} \
		}

		tessmat(MAT_WATER,
		 if(m.orient != O_TOP) renderfall(m, m.csize, xx, yy); 
		 else if(rendermatlod(waterwaves ? 1 : 0, m.o.x, m.o.y, m.o.z, m.csize, xx, yy) >= (uint)m.csize * 2)
		     rendermat(waterwaves ? 1 : 0, m.csize, m.o.x, m.o.y, m.o.z, m.csize, xx, yy);
		);
		
		tessfill(MAT_CLIP, 255, 0, 0, 128, drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, 0.1f, 0.0f, 0.0f));

		tessmat(MAT_GLASS, drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, 0.1f, xx, yy));

		tessfill(MAT_NOCLIP, 0, 255, 0, 128, drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, 0.1f, 0.0f, 0.0f));

		tessmat(MAT_FOG,
		 if(m.orient != O_TOP) renderfall(m, m.csize, xx, yy); 
		 else if(rendermatlod(2, m.o.x, m.o.y, m.o.z, m.csize, xx, yy) >= (uint)m.csize * 2)
		     rendermat(2, m.csize, m.o.x, m.o.y, m.o.z, m.csize, xx, yy);
		);
	}
	else
	{
		uchar wcol[4] = { 128, 128, 128, 192 };

		if(hdr.watercolour[0] || hdr.watercolour[1] || hdr.watercolour[2]) memcpy(wcol, hdr.watercolour, 3);
		glColor4ubv(wcol);
		
		Texture *t = lookuptexture(DEFAULT_LIQUID).sts[0].t;
		int xx = t->xs;
		int yy = t->ys;
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture(GL_TEXTURE_2D, t->gl);
		#define matloop(mat, s) loopi(matsurfs) { materialsurface &m = matbuf[i]; if(m.material==mat) { s; }; }
		defaultshader->set();
		
		matloop(MAT_WATER,
		 if(m.orient != O_TOP) renderfall(m, 0.1f, xx, yy); 
		 else if(rendermatlod(waterwaves ? 1 : 0, m.o.x, m.o.y, m.o.z, m.csize, xx, yy) >= (uint)m.csize * 2)
		     rendermat(waterwaves ? 1 : 0, m.csize, m.o.x, m.o.y, m.o.z, m.csize, xx, yy);
		);
		
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);
		glColor3f(0.3f, 0.15f, 0.0f);
		notextureshader->set();
		matloop(MAT_GLASS, drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, 0.1f, 0.0f, 0.0f));
	}
};

void rendermatgrid(materialsurface *matbuf, int matsurfs)
{ dbg;
    if(!matsurfs) return;
    uchar cols[MAT_EDIT][3] =
    {
        { 0, 0, 0 },   // MAT_AIR - no edit volume,
        { 0, 0, 85 },  // MAT_WATER - blue,
        { 85, 0, 0 },  // MAT_CLIP - red,
        { 0, 85, 85 }, // MAT_GLASS - cyan,
        { 0, 85, 0 },  // MAT_NOCLIP - green
        { 128, 128, 128 },  // MAT_FOG - grey
    };
    int lastmat = -1;
    loopi(matsurfs)
    { dbg;
        materialsurface &m = matbuf[i];
        if(m.material != lastmat)
        { dbg;
            lastmat = m.material;
            glColor3ubv(cols[lastmat >= MAT_EDIT ? lastmat-MAT_EDIT : lastmat]);
        };
        drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, -0.1f, 0.0f, 0.0f);
    };
};

//#undef dbg
//#define dbg { vline = __LINE__; snprintf(vfile, 511, "%s", __FILE__); printf("%s:%s:%d\n", vfile, __PRETTY_FUNCTION__, vline); };

struct QuadNode
{
    int x, y, size;
    uint filled;
    QuadNode *child[4];

    QuadNode(int x, int y, int size) : x(x), y(y), size(size), filled(0) { loopi(4) child[i] = 0; };

    void clear()
    {
        loopi(4) DELETEP(child[i]);
    };

    ~QuadNode()
    {
        clear();
    };

    void insert(int mx, int my, int msize)
    { dbg;
        if(size == msize)
        { dbg;
            filled = 0xF;
            return;
        };
        int csize = size>>1, i = 0;
        dbg; if(mx >= x+csize) i |= 1;
        dbg; if(my >= y+csize) i |= 2; 
        dbg; if(csize == msize) 
        { dbg; 
            filled |= (1 << i);
            return;
        };
        dbg; if(!child[i]) child[i] = new QuadNode(i&1 ? x+csize : x, i&2 ? y+csize : y, csize);
        dbg; child[i]->insert(mx, my, msize);
        loopj(4) if(child[j])
        { dbg; 
            if(child[j]->filled == 0xF)
            {
                DELETEP(child[j]);
                filled |= (1 << j);
            };
        };
        dbg; 
    };
    
    void genmatsurf(int mat, int tag, int tex, int r, int g, int b, int a, int orient, int x, int y, int z, int size, materialsurface *&matbuf)
    {
        materialsurface &m = *matbuf++;
        m.material = mat; 
        m.mattag = tag; 
        m.mattex = tex; 
        m.matcol[0] = r; 
        m.matcol[1] = g; 
        m.matcol[2] = b; 
        m.matcol[3] = a; 
        m.orient = orient;
        m.csize = size;
        m.rsize = size;
        int dim = dimension(orient);
        m.o[C[dim]] = x;
        m.o[R[dim]] = y;
        m.o[dim] = z;
    };

    void genmatsurfs(int mat, int tag, int tex, int r, int g, int b, int a, int orient, int z, materialsurface *&matbuf)
    {
        if(filled == 0xF) genmatsurf(mat, tag, tex, r, g, b, a, orient, x, y, z, size, matbuf);
        else if(filled)
        {
            int csize = size>>1; 
            loopi(4) if(filled & (1 << i))  
                genmatsurf(mat, tag, tex, r, g, b, a, orient, i&1 ? x+csize : x, i&2 ? y+csize : y, z, csize, matbuf);
        };
        loopi(4) if(child[i]) child[i]->genmatsurfs(mat, tag, tex, r, g, b, a, orient, z, matbuf);
    };

    void genrgnsurf(int rgn, int tag, int orient, int x, int y, int z, int size, regionsurface *&rgnbuf)
    {
        regionsurface &m = *rgnbuf++;
        m.region = rgn; 
        m.rgntag = tag; 
        m.orient = orient;
        m.csize = size;
        m.rsize = size;
        int dim = dimension(orient);
        m.o[C[dim]] = x;
        m.o[R[dim]] = y;
        m.o[dim] = z;
    };

    void genrgnsurfs(int rgn, int tag, int orient, int z, regionsurface *&rgnbuf)
    {
        if(filled == 0xF) genrgnsurf(rgn, tag, orient, x, y, z, size, rgnbuf);
        else if(filled)
        {
            int csize = size>>1; 
            loopi(4) if(filled & (1 << i))  
                genrgnsurf(rgn, tag, orient, i&1 ? x+csize : x, i&2 ? y+csize : y, z, csize, rgnbuf);
        };
        loopi(4) if(child[i]) child[i]->genrgnsurfs(rgn, tag, orient, z, rgnbuf);
    };

    void genelementsurf(int id, int ex, int ey, int ez, int orient, int x, int y, int z, int size, elementsurface *&buf)
    {
        elementsurface &m = *buf++;
        m.id = id; 
        m.x = ex; 
        m.y = ey; 
        m.z = ez; 
        m.orient = orient;
        m.csize = size;
        m.rsize = size;
        int dim = dimension(orient);
        m.o[C[dim]] = x;
        m.o[R[dim]] = y;
        m.o[dim] = z;
    };

    void genelementsurfs(int id, int ex, int ey, int ez, int orient, int z, elementsurface *&buf)
    {
        if(filled == 0xF) genelementsurf(id, ex, ey, ez, orient, x, y, z, size, buf);
        else if(filled)
        {
            int csize = size>>1; 
            loopi(4) if(filled & (1 << i))  
                genelementsurf(id, ex, ey, ez, orient, i&1 ? x+csize : x, i&2 ? y+csize : y, z, csize, buf);
        };
        loopi(4) if(child[i]) child[i]->genelementsurfs(id, ex, ey, ez, orient, z, buf);
    };
};

int mergematcmp(const materialsurface *x, const materialsurface *y)
{ dbg;
    int dim = dimension(x->orient), c = C[dim], r = R[dim];
    if(x->o[r] + x->rsize < y->o[r] + y->rsize) return -1;
    if(x->o[r] + x->rsize > y->o[r] + y->rsize) return 1;
    if(x->o[c] < y->o[c]) return -1;
    if(x->o[c] > y->o[c]) return 1;
    return 0;
};

int mergematr(materialsurface *m, int sz, materialsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    for(int i = sz-1; i >= 0; --i)
    { dbg;
        if(m[i].o[r] + m[i].rsize < n.o[r]) break;
        if(m[i].o[r] + m[i].rsize == n.o[r] && m[i].o[c] == n.o[c] && m[i].csize == n.csize)
        { dbg;
            n.o[r] = m[i].o[r];
            n.rsize += m[i].rsize;
            memmove(&m[i], &m[i+1], (sz - (i+1)) * sizeof(materialsurface));
            return 1;
        }; 
    };
    return 0;
};

int mergematc(materialsurface &m, materialsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    if(m.o[r] == n.o[r] && m.rsize == n.rsize && m.o[c] + m.csize == n.o[c])
    { dbg;
        n.o[c] = m.o[c];
        n.csize += m.csize;
        return 1;
    };
    return 0;
};

int mergemat(materialsurface *m, int sz, materialsurface &n)
{ dbg;
    for(bool merged = false; sz; merged = true)
    { dbg;
        int rmerged = mergematr(m, sz, n);
        sz -= rmerged;
        if(!rmerged && merged) break;
        if(!sz) break;
        int cmerged = mergematc(m[sz-1], n);
        sz -= cmerged;
        if(!cmerged) break;
    };
    m[sz++] = n;
    return sz;
};

int mergemats(materialsurface *m, int sz)
{ dbg;
    qsort(m, sz, sizeof(materialsurface), (int (*)(const void *, const void *))mergematcmp);

    int nsz = 0;
    loopi(sz) nsz = mergemat(m, nsz, m[i]);
    return nsz;
};
    
VARF(optmats, 0, 1, 1, allchanged());
                
int optimizematsurfs(materialsurface *matbuf, int matsurfs)
{ dbg;
    if(!optmats) return matsurfs;
    materialsurface *cur = matbuf, *end = matbuf+matsurfs;
    while(cur < end)
    { dbg;
         materialsurface *start = cur++;
         int dim = dimension(start->orient);
         while(cur < end && 
               cur->material == start->material && 
               cur->mattag == start->mattag && 
               cur->mattex == start->mattex && 
               cur->matcol[0] == start->matcol[0] && 
               cur->matcol[1] == start->matcol[1] && 
               cur->matcol[2] == start->matcol[2] && 
               cur->matcol[3] == start->matcol[3] && 
               cur->orient == start->orient && 
               cur->o[dim] == start->o[dim])
            ++cur;
         materialsurface *oldbuf = matbuf;
         if(cur-start<4) 
         { dbg;
            memcpy(matbuf, start, (cur-start)*sizeof(materialsurface));
            matbuf += cur-start;
         }
         else
         { dbg;
            QuadNode vmats(0, 0, hdr.worldsize);
            loopi(cur-start) { dbg; vmats.insert(start[i].o[C[dim]], start[i].o[R[dim]], start[i].csize); }
            dbg; vmats.genmatsurfs(start->material, start->mattag, start->mattex, start->matcol[0], start->matcol[1], start->matcol[2], start->matcol[3], start->orient, start->o[dim], matbuf);
         };
         if(start->material != MAT_WATER || start->orient != O_TOP) matbuf = oldbuf + mergemats(oldbuf, matbuf - oldbuf);
         
    };
    return matsurfs - (end-matbuf);
};

int visibleregion(cube &c, int orient, int x, int y, int z, int size)
{ dbg;
    switch(c.region)
    {
    case RGN_NONE:
         break;

    case RGN_TELEPORT:
    case RGN_TRIGGER:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return MATSURF_VISIBLE;
        break;

    default:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return MATSURF_EDIT_ONLY;
        break;
    };
    return MATSURF_NOT_VISIBLE; 
};   

int rgnsurfcmp(const regionsurface *x, const regionsurface *y)
{ dbg;
    if(x->region < y->region) return -1;
    if(x->region > y->region) return 1;
    if(x->rgntag < y->rgntag) return -1;
    if(x->rgntag > y->rgntag) return 1;
    if(x->orient < y->orient) return -1;
    if(x->orient > y->orient) return 1;
    int dim = dimension(x->orient), xc = x->o[dim], yc = y->o[dim];
    if(xc < yc) return -1;
    if(xc > yc) return 1;
    return 0;
};


void sortrgnsurfs(regionsurface *rgnsurf, int rgnsurfs)
{ dbg;
    qsort(rgnsurf, rgnsurfs, sizeof(regionsurface), (int (*)(const void*, const void*))rgnsurfcmp);
};

VAR(showrgn, 0, 1, 1);

void renderrgngrid(regionsurface *rgnbuf, int rgnsurfs)
{ dbg;
    if(!rgnsurfs || !showrgn) return;
	struct rgndef
	{
		char *name;
    	uchar col[3];
	} rgnd[RGN_EDIT] = {
       { "",			{ 0, 0, 0 }		},
       { "teleport",	{ 0, 0, 0 }		},
       { "trigger",		{ 64, 0, 0 }	}
    };

    loopi(rgnsurfs)
    { dbg;
        regionsurface &m = rgnbuf[i];
        if(m.region != RGN_NONE)
        { dbg;
        	int rgn = m.region >= RGN_EDIT ? m.region-RGN_EDIT : m.region;
        	
            glColor3ubv(rgnd[rgn].col);
	        drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, -0.1f, 0.0f, 0.0f);
        };
    };
};

int mergergncmp(const regionsurface *x, const regionsurface *y)
{ dbg;
    int dim = dimension(x->orient), c = C[dim], r = R[dim];
    if(x->o[r] + x->rsize < y->o[r] + y->rsize) return -1;
    if(x->o[r] + x->rsize > y->o[r] + y->rsize) return 1;
    if(x->o[c] < y->o[c]) return -1;
    if(x->o[c] > y->o[c]) return 1;
    return 0;
};

int mergergnr(regionsurface *m, int sz, regionsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    for(int i = sz-1; i >= 0; --i)
    { dbg;
        if(m[i].o[r] + m[i].rsize < n.o[r]) break;
        if(m[i].o[r] + m[i].rsize == n.o[r] && m[i].o[c] == n.o[c] && m[i].csize == n.csize)
        { dbg;
            n.o[r] = m[i].o[r];
            n.rsize += m[i].rsize;
            memmove(&m[i], &m[i+1], (sz - (i+1)) * sizeof(regionsurface));
            return 1;
        }; 
    };
    return 0;
};

int mergergnc(regionsurface &m, regionsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    if(m.o[r] == n.o[r] && m.rsize == n.rsize && m.o[c] + m.csize == n.o[c])
    { dbg;
        n.o[c] = m.o[c];
        n.csize += m.csize;
        return 1;
    };
    return 0;
};

int mergergn(regionsurface *m, int sz, regionsurface &n)
{ dbg;
    for(bool merged = false; sz; merged = true)
    { dbg;
        int rmerged = mergergnr(m, sz, n);
        sz -= rmerged;
        if(!rmerged && merged) break;
        if(!sz) break;
        int cmerged = mergergnc(m[sz-1], n);
        sz -= cmerged;
        if(!cmerged) break;
    };
    m[sz++] = n;
    return sz;
};

int mergergns(regionsurface *m, int sz)
{ dbg;
    qsort(m, sz, sizeof(regionsurface), (int (*)(const void *, const void *))mergergncmp);

    int nsz = 0;
    loopi(sz) nsz = mergergn(m, nsz, m[i]);
    return nsz;
};
    
int optimizergnsurfs(regionsurface *rgnbuf, int rgnsurfs)
{ dbg;
    if(!optmats) return rgnsurfs;
    regionsurface *cur = rgnbuf, *end = rgnbuf+rgnsurfs;
    while(cur < end)
    { dbg;
         regionsurface *start = cur++;
         int dim = dimension(start->orient);
         while(cur < end && 
               cur->region == start->region && 
               cur->rgntag == start->rgntag && 
               cur->orient == start->orient && 
               cur->o[dim] == start->o[dim])
            ++cur;
         regionsurface *oldbuf = rgnbuf;
         if(cur-start<4) 
         { dbg;
            memcpy(rgnbuf, start, (cur-start)*sizeof(regionsurface));
            rgnbuf += cur-start;
         }
         else
         { dbg;
            QuadNode vrgns(0, 0, hdr.worldsize);
            loopi(cur-start) { dbg; vrgns.insert(start[i].o[C[dim]], start[i].o[R[dim]], start[i].csize); }
            dbg; vrgns.genrgnsurfs(start->region, start->rgntag, start->orient, start->o[dim], rgnbuf);
         };
         rgnbuf = oldbuf + mergergns(oldbuf, rgnbuf - oldbuf);
         
    };
    return rgnsurfs - (end-rgnbuf);
};

int visibleelement(cube &c, int id, int orient, int x, int y, int z, int size)
{ dbg;
    switch(id)
    {
    case ELEM_GRAVITY:
        if(visibleface(c, orient, x, y, z, size, c.material))
            return MATSURF_EDIT_ONLY;
        break;
    case ELEM_NONE:
	default:
         break;
    };
    return MATSURF_NOT_VISIBLE; 
};   

int elemsurfcmp(const elementsurface *ex, const elementsurface *ey)
{ dbg;
    if(ex->id < ey->id) return -1;
    if(ex->id > ey->id) return 1;
    if(ex->x < ey->x) return -1;
    if(ex->x > ey->x) return 1;
    if(ex->y < ey->y) return -1;
    if(ex->y > ey->y) return 1;
    if(ex->z < ey->z) return -1;
    if(ex->z > ey->z) return 1;
    if(ex->orient < ey->orient) return -1;
    if(ex->orient > ey->orient) return 1;
    int dim = dimension(ex->orient), xc = ex->o[dim], yc = ey->o[dim];
    if(xc < yc) return -1;
    if(xc > yc) return 1;
    return 0;
};


void sortelementsurfs(elementsurface *elemsurf, int surfs)
{ dbg;
    qsort(elemsurf, surfs, sizeof(elementsurface), (int (*)(const void*, const void*))elemsurfcmp);
};

VAR(showelem, 0, 0, 1);

void renderelementgrid(int id, elementsurface *buf, int surfs)
{ dbg;
    if(!surfs || !showelem) return;
	struct elementdef
	{
		char *name;
    	uchar col[3];
	} elementd[ELEM_EDIT] = {
       { "",			{ 0, 0, 0 }			},
       { "gravity",		{ 0, 0, 128 }		},
    };

    glColor3ubv(elementd[id].col);

    loopi(surfs)
    { dbg;
        elementsurface &m = buf[i];
        if(m.id != ELEM_NONE)
        { dbg;
	        drawface(m.orient, m.o.x, m.o.y, m.o.z, m.csize, m.rsize, -0.1f, 0.0f, 0.0f);
        };
    };
};

int mergeelementcmp(const elementsurface *x, const elementsurface *y)
{ dbg;
    int dim = dimension(x->orient), c = C[dim], r = R[dim];
    if(x->o[r] + x->rsize < y->o[r] + y->rsize) return -1;
    if(x->o[r] + x->rsize > y->o[r] + y->rsize) return 1;
    if(x->o[c] < y->o[c]) return -1;
    if(x->o[c] > y->o[c]) return 1;
    return 0;
};

int mergeelementr(elementsurface *m, int sz, elementsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    for(int i = sz-1; i >= 0; --i)
    { dbg;
        if(m[i].o[r] + m[i].rsize < n.o[r]) break;
        if(m[i].o[r] + m[i].rsize == n.o[r] && m[i].o[c] == n.o[c] && m[i].csize == n.csize)
        { dbg;
            n.o[r] = m[i].o[r];
            n.rsize += m[i].rsize;
            memmove(&m[i], &m[i+1], (sz - (i+1)) * sizeof(elementsurface));
            return 1;
        }; 
    };
    return 0;
};

int mergeelementc(elementsurface &m, elementsurface &n)
{ dbg;
    int dim = dimension(n.orient), c = C[dim], r = R[dim];
    if(m.o[r] == n.o[r] && m.rsize == n.rsize && m.o[c] + m.csize == n.o[c])
    { dbg;
        n.o[c] = m.o[c];
        n.csize += m.csize;
        return 1;
    };
    return 0;
};

int mergeelement(elementsurface *m, int sz, elementsurface &n)
{ dbg;
    for(bool merged = false; sz; merged = true)
    { dbg;
        int rmerged = mergeelementr(m, sz, n);
        sz -= rmerged;
        if(!rmerged && merged) break;
        if(!sz) break;
        int cmerged = mergeelementc(m[sz-1], n);
        sz -= cmerged;
        if(!cmerged) break;
    };
    m[sz++] = n;
    return sz;
};

int mergeelements(elementsurface *m, int sz)
{ dbg;
    qsort(m, sz, sizeof(elementsurface), (int (*)(const void *, const void *))mergeelementcmp);

    int nsz = 0;
    loopi(sz) nsz = mergeelement(m, nsz, m[i]);
    return nsz;
};
    
int optimizeelementsurfs(elementsurface *buf, int surfs)
{ dbg;
    if(!optmats) return surfs;
    elementsurface *cur = buf, *end = buf+surfs;
    while(cur < end)
    { dbg;
         elementsurface *start = cur++;
         int dim = dimension(start->orient);
         while(cur < end && 
               cur->id == start->id && 
               cur->x == start->x && 
               cur->y == start->y && 
               cur->z == start->z && 
               cur->orient == start->orient && 
               cur->o[dim] == start->o[dim])
            ++cur;
         elementsurface *oldbuf = buf;
         if(cur-start<4) 
         { dbg;
            memcpy(buf, start, (cur-start)*sizeof(elementsurface));
            buf += cur-start;
         }
         else
         { dbg;
            QuadNode velements(0, 0, hdr.worldsize);
            loopi(cur-start) { dbg; velements.insert(start[i].o[C[dim]], start[i].o[R[dim]], start[i].csize); }
            dbg; velements.genelementsurfs(start->id, start->x, start->y, start->z, start->orient, start->o[dim], buf);
         };
         buf = oldbuf + mergeelements(oldbuf, buf - oldbuf);
         
    };
    return surfs - (end-buf);
};
