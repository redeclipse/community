// core world management routines

#include "pch.h"
#include "engine.h"

cube *worldroot = newcubes(F_SOLID);
int allocnodes = 0;

cube *newcubes(uint face)
{ dbg;
    cube *c = new cube[8];
    loopi(8)
    { dbg;
        c->gravity[0][0] = c->gravity[0][1] = c->gravity[0][2] = c->gravity[1][0] = c->gravity[1][1] = c->gravity[1][2] = 0;
        c->material = MAT_AIR;
        c->mattag = c->mattex = c->matcol[0] = c->matcol[1] = c->matcol[2] = c->matcol[3] = 0;
        c->region = RGN_NONE;
        c->visible = 0;
        c->children = NULL;
        c->va = NULL;
        setfaces(*c, face);
        c->surfaces = NULL;
        c->normals = NULL;
        c->clip = NULL;
        c->ents = NULL;
        loopl(6)
        { dbg;
            c->texture[l] = 2+l;
        };
        c++;
    };
    allocnodes++;
    return c-8;
};

int familysize(cube &c)
{ dbg;
    int size = 1;
    if(c.children) loopi(8) size += familysize(c.children[i]);
    return size;
};

void freeocta(cube *c)
{ dbg;
    if(!c) return;
    loopi(8) discardchildren(c[i]);
    delete[] c;
    allocnodes--;
};

void discardchildren(cube &c)
{ dbg;
    if(c.va) destroyva(c.va);
    c.va = NULL;
    freesurfaces(c);
    freenormals(c);
    freeclipplanes(c);
    freeoctaentities(c);
    if(c.children)
    { dbg;
        freeocta(c.children);
        c.children = NULL;
    };
};

void getcubevector(cube &c, int d, int x, int y, int z, ivec &p)
{ dbg;
    ivec v(d, x, y, z);

    loopi(3)
        p[i] = edgeget(cubeedge(c, i, v[R[i]], v[C[i]]), v[D[i]]);
};

void setcubevector(cube &c, int d, int x, int y, int z, ivec &p)
{ dbg;
    ivec v(d, x, y, z);

    loopi(3)
        edgeset(cubeedge(c, i, v[R[i]], v[C[i]]), v[D[i]], p[i]);
};

void optiface(uchar *p, cube &c)
{ dbg;
    loopi(4) if(edgeget(p[i], 0)!=edgeget(p[i], 1)) return;
    emptyfaces(c);
};

void printcube()
{ dbg;
    cube &c = lookupcube(lu.x, lu.y, lu.z, 0); // assume this is cube being pointed at
    conoutf("= %p =", &c);
    conoutf(" x  %.8x",c.faces[0]);
    conoutf(" y  %.8x",c.faces[1]);
    conoutf(" z  %.8x",c.faces[2]);
};

COMMAND(printcube, "");

bool isvalidcube(cube &c)
{ dbg;
    clipplanes p;
    genclipplanes(c, 0, 0, 0, 256, p);
    loopi(8) // test that cube is convex
    { dbg;
        vvec v;
        calcvert(c, 0, 0, 0, 256, v, i);
        if(!pointincube(p, v.tovec()))
            return false;
    };
    return true;
};

void validatec(cube *c, int size)
{ dbg;
    loopi(8)
    { dbg;
        if(c[i].children)
        { dbg;
            if(size<=4)
            { dbg;
                solidfaces(c[i]);
                discardchildren(c[i]);
            }
            else validatec(c[i].children, size>>1);
        }
        else
        { dbg;
            loopj(3) optiface((uchar *)&(c[i].faces[j]), c[i]);
            loopj(12)
                if(edgeget(c[i].edges[j], 1)>8 ||
                   edgeget(c[i].edges[j], 1)<edgeget(c[i].edges[j], 0))
                    emptyfaces(c[i]);
        };
    };
};

ivec lu;
int lusize;
bool luperfect;
cube &lookupcube(int tx, int ty, int tz, int tsize)
{ dbg;
    int size = hdr.worldsize;
    int x = 0, y = 0, z = 0;
    cube *c = worldroot;
    luperfect = true;
    for(;;)
    { dbg;
        size >>= 1;
        ASSERT(size);
        if(tz>=z+size) { z += size; c += 4; };
        if(ty>=y+size) { y += size; c += 2; };
        if(tx>=x+size) { x += size; c += 1; };
        //if(tsize==size) break;
        if(abs(tsize)>=size) break;
        if(c->children==NULL)
        { dbg;
            //if(!tsize) break;
            if(tsize<=0) break;
            if(isempty(*c))
            { dbg;
                c->children = newcubes(F_EMPTY);
                loopi(8)
                { dbg;
                    loopl(6) c->children[i].texture[l] = c->texture[l];

                    c->children[i].gravity[0][0] = c->gravity[0][0];
                    c->children[i].gravity[0][1] = c->gravity[0][1];
                    c->children[i].gravity[0][2] = c->gravity[0][2];
                    c->children[i].gravity[1][0] = c->gravity[1][0];
                    c->children[i].gravity[1][1] = c->gravity[1][1];
                    c->children[i].gravity[1][2] = c->gravity[1][2];

                    c->children[i].material = c->material;
                    c->children[i].mattag = c->mattag;
                    c->children[i].mattex = c->mattex;
                    c->children[i].matcol[0] = c->matcol[0];
                    c->children[i].matcol[1] = c->matcol[1];
                    c->children[i].matcol[2] = c->matcol[2];
                    c->children[i].matcol[3] = c->matcol[3];

                    c->children[i].region = c->region;
                    c->children[i].rgntag = c->rgntag;
                };
            }
            else if(!subdividecube(*c)) luperfect = false;
        };
        c = c->children;
    };
    lu.x = x;
    lu.y = y;
    lu.z = z;
    lusize = size;
    return *c;
};

cube &neighbourcube(int x, int y, int z, int size, int rsize, int orient)
{ dbg;
    switch(orient)
    {
        case O_BOTTOM: z -= size; break;
        case O_TOP:    z += size; break;
        case O_BACK:   y -= size; break;
        case O_FRONT:  y += size; break;
        case O_LEFT:   x -= size; break;
        case O_RIGHT:  x += size; break;
    };
    return lookupcube(x, y, z, rsize);
};

uchar octantrectangleoverlap(const ivec &c, int size, const ivec &o, const ivec &s)
{ dbg;
    uchar p = 0xFF; // bitmask of possible collisions with octants. 0 bit = 0 octant, etc
    ivec v(c);
    v.add(size);
    if(v.z <= o.z)     p &= 0xF0; // not in a -ve Z octant
    if(v.z >= o.z+s.z) p &= 0x0F; // not in a +ve Z octant
    if(v.y <= o.y)     p &= 0xCC; // not in a -ve Y octant
    if(v.y >= o.y+s.y) p &= 0x33; // etc..
    if(v.x <= o.x)     p &= 0xAA;
    if(v.x >= o.x+s.x) p &= 0x55;
    return p;
};

int getcuberegion(int x, int y, int z)
{
	return (int)lookupcube(x, y, z).region;
}

int getcubergntag(int x, int y, int z)
{
	return (int)lookupcube(x, y, z).rgntag;
}

int getcubeelement(int id, int x, int y, int z, int v)
{
	cube &c = lookupcube(x, y, z);
	switch (id)
	{
		case ELEM_GRAVITY:
			if (v > 0 && v < 3)
				return (c.gravity[1][v] ? c.gravity[0][v] : 0-c.gravity[0][v]);
			break;
		default:
			break;
	}
	return 0;
}
