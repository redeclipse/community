// worldio.cpp: loading & saving of maps and savegames

#include "pch.h"
#include "engine.h"

bool tessmap;
int tessver;

void backup(char *name, char *backupname)
{ dbg;
    remove(backupname);
    rename(name, backupname);
};

string cgzname, bakname, pcfname, mcfname, owvname, shtname;

VARP(savebak, 0, 2, 2);

void setnames(const char *fname)
{ dbg;
    string name, pakname, mapname;
    s_strncpy(name, fname, 100);
    char *slash = strpbrk(name, "/\\");
    if(slash)
    { dbg;
        s_strncpy(pakname, name, slash-name+1);
        s_strcpy(mapname, slash+1);
    }
    else
    { dbg;
        s_strcpy(pakname, "base");
        s_strcpy(mapname, name);
    };
    s_sprintf(cgzname)("packages/%s/%s.ogz",      pakname, mapname);
    s_sprintf(owvname)("packages/%s/%s.owv",      pakname, mapname);
    s_sprintf(shtname)("packages/%s/%s.jpg",      pakname, mapname);
    if(savebak==1) s_sprintf(bakname)("packages/%s/%s.BAK", pakname, mapname);
    else s_sprintf(bakname)("packages/%s/%s_%li.BAK", pakname, mapname, time (NULL));
    s_sprintf(pcfname)("packages/%s/package.cfg", pakname);
    s_sprintf(mcfname)("packages/%s/%s.cfg",      pakname, mapname);

    path(cgzname);
    path(owvname);
    path(shtname);
    path(bakname);
};

ushort readushort(gzFile f)
{ dbg;
    ushort t;
    gzread(f, &t, sizeof(ushort));
    endianswap(&t, sizeof(ushort), 1);
    return t;
}

void writeushort(gzFile f, ushort u)
{ dbg;
    endianswap(&u, sizeof(ushort), 1);
    gzwrite(f, &u, sizeof(ushort));
}

enum { OCTSAV_CHILDREN = 0, OCTSAV_EMPTY, OCTSAV_SOLID, OCTSAV_NORMAL, OCTSAV_LODCUBE };

void savec(cube *c, gzFile f, bool nolms)
{ dbg;
    loopi(8)
    { dbg;
        if(c[i].children && !c[i].surfaces)
        { dbg;
            gzputc(f, OCTSAV_CHILDREN);
            savec(c[i].children, f, nolms);
        }
        else
        { dbg;
            if(c[i].children) gzputc(f, OCTSAV_LODCUBE);
            else if(isempty(c[i])) gzputc(f, OCTSAV_EMPTY);
            else if(isentirelysolid(c[i])) gzputc(f, OCTSAV_SOLID);
            else
            { dbg;
                gzputc(f, OCTSAV_NORMAL);
                gzwrite(f, c[i].edges, 12);
            };
            loopj(6) writeushort(f, c[i].texture[j]);
            uchar mask = (c[i].material != MAT_AIR ? 0x80 : 0) | (c[i].normals && !nolms ? 0x40 : 0);
            if(c[i].normals && !nolms) loopj(6) if(c[i].normals[j].normals[0] != bvec(128, 128, 128)) mask |= 1 << j;
            // save surface info for lighting
            if(!c[i].surfaces || nolms)
            { dbg;
                if (tessmap)
				{
					gzputc(f, c[i].gravity[0][0]);
					gzputc(f, c[i].gravity[0][1]);
					gzputc(f, c[i].gravity[0][2]);
					gzputc(f, c[i].gravity[1][0]);
					gzputc(f, c[i].gravity[1][1]);
					gzputc(f, c[i].gravity[1][2]);
				}
                
				gzputc(f, mask);
                if(c[i].material != MAT_AIR) gzputc(f, c[i].material);
                
				if (tessmap)
				{
					gzputc(f, c[i].mattag);
					gzputc(f, c[i].mattex);
					gzputc(f, c[i].matcol[0]);
					gzputc(f, c[i].matcol[1]);
					gzputc(f, c[i].matcol[2]);
					gzputc(f, c[i].matcol[3]);
				
					gzputc(f, c[i].region);
					gzputc(f, c[i].rgntag);
				}
                if(c[i].normals && !nolms) loopj(6) if(mask & (1 << j))
                { dbg;
                    loopk(sizeof(surfaceinfo)) gzputc(f, 0);
                    gzwrite(f, &c[i].normals[j], sizeof(surfacenormals));
                }; 
            }
            else
            { dbg;
                loopj(6) if(c[i].surfaces[j].lmid >= LMID_RESERVED) mask |= 1 << j;
                if (tessmap)
				{
					gzputc(f, c[i].gravity[0][0]);
					gzputc(f, c[i].gravity[0][1]);
					gzputc(f, c[i].gravity[0][2]);
					gzputc(f, c[i].gravity[1][0]);
					gzputc(f, c[i].gravity[1][1]);
					gzputc(f, c[i].gravity[1][2]);
				}
                
				gzputc(f, mask);
                if(c[i].material != MAT_AIR) gzputc(f, c[i].material);
                
				if (tessmap)
				{
					gzputc(f, c[i].mattag);
					gzputc(f, c[i].mattex);
					gzputc(f, c[i].matcol[0]);
					gzputc(f, c[i].matcol[1]);
					gzputc(f, c[i].matcol[2]);
					gzputc(f, c[i].matcol[3]);
				
					gzputc(f, c[i].region);
					gzputc(f, c[i].rgntag);
				}
                loopj(6) if(mask & (1 << j))
                { dbg;
                    surfaceinfo tmp = c[i].surfaces[j];
                    endianswap(&tmp.x, sizeof(ushort), 3);
                    gzwrite(f, &tmp, sizeof(surfaceinfo));
                    if(c[i].normals) gzwrite(f, &c[i].normals[j], sizeof(surfacenormals));
                };
            };
            if(c[i].children) savec(c[i].children, f, nolms);
        };
    };
};

cube *loadchildren(gzFile f);



void loadc(gzFile f, cube &c)
{ dbg;
    bool haschildren = false;
    switch(gzgetc(f))
    {
        case OCTSAV_CHILDREN:
            c.children = loadchildren(f);
            return;

        case OCTSAV_LODCUBE: haschildren = true;    break;
        case OCTSAV_EMPTY:  emptyfaces(c);          break;
        case OCTSAV_SOLID:  solidfaces(c);          break;
        case OCTSAV_NORMAL: gzread(f, c.edges, 12); break;

        default:
            fatal("garbage in map");
    };
    loopi(6) c.texture[i] = hdr.version<14 ? gzgetc(f) : readushort(f);
    if(hdr.version < 7) loopi(3) gzgetc(f); //gzread(f, c.colour, 3);
    else
    { dbg;
		if (tessmap && tessver > 22)
		{
		    c.gravity[0][0] = gzgetc(f);
		    c.gravity[0][1] = gzgetc(f);
		    c.gravity[0][2] = gzgetc(f);
		    c.gravity[1][0] = gzgetc(f);
		    c.gravity[1][1] = gzgetc(f);
		    c.gravity[1][2] = gzgetc(f);
		}
		else
		{
		    c.gravity[0][0] = elements[ELEM_GRAVITY].x;
		    c.gravity[0][1] = elements[ELEM_GRAVITY].y;
		    c.gravity[0][2] = elements[ELEM_GRAVITY].z;
		    c.gravity[1][0] = c.gravity[1][1] = c.gravity[1][2] = 1;
		}
		
        uchar mask = gzgetc(f);
        if(mask & 0x80) c.material = gzgetc(f);

		if (tessmap && tessver > 21)
		{
			c.mattag = gzgetc(f);
		    c.mattex = gzgetc(f);
		    c.matcol[0] = gzgetc(f);
		    c.matcol[1] = gzgetc(f);
		    c.matcol[2] = gzgetc(f);
		    c.matcol[3] = gzgetc(f);
		}
		else
		{
			c.mattag = materials[c.material].tag;
		    c.mattex = materials[c.material].tex;
		    c.matcol[0] = materials[c.material].r;
		    c.matcol[1] = materials[c.material].g;
		    c.matcol[2] = materials[c.material].b;
		    c.matcol[3] = materials[c.material].a;
		}
		if (tessmap && tessver > 20)
		{
			c.region = gzgetc(f);
		    c.rgntag = gzgetc(f);
		}
		else
		{
			c.region = RGN_NONE;
		    c.rgntag = 0;
		}

		if(mask & 0x3F)
        { dbg;
            uchar lit = 0;
            newsurfaces(c);
            if(mask & 0x40) newnormals(c);
            loopi(6)
            { dbg;
                if(mask & (1 << i))
                { dbg;
                    gzread(f, &c.surfaces[i], sizeof(surfaceinfo));
                    endianswap(&c.surfaces[i].x, sizeof(ushort), 3);
                    if(hdr.version < 10) ++c.surfaces[i].lmid;
                    if(hdr.version < 18)
                    { dbg;
                        if(c.surfaces[i].lmid >= LMID_AMBIENT1) ++c.surfaces[i].lmid;
                        if(c.surfaces[i].lmid >= LMID_BRIGHT1) ++c.surfaces[i].lmid;
                    };
                    if(mask & 0x40) gzread(f, &c.normals[i], sizeof(surfacenormals));
                }
                else c.surfaces[i].lmid = LMID_AMBIENT;
                if(c.surfaces[i].lmid != LMID_AMBIENT) lit |= 1 << i;
            };
            if(!lit) freesurfaces(c);
        };
    };
    c.children = (haschildren ? loadchildren(f) : NULL);
};

cube *loadchildren(gzFile f)
{ dbg;
    cube *c = newcubes();
    loopi(8) loadc(f, c[i]);
    // TODO: remip c from children here
    return c;
};

void save_world(char *mname, bool nolms, bool tess)
{ dbg;
	bool wastess = tessmap;
	
    if(!*mname) mname = cl->getclientmap();
    setnames(mname);
    
	if(savebak) backup(cgzname, bakname);
    
	gzFile g = gzopen(cgzname, "wb9");
    
	if(!g) { conoutf("could not write map to %s", cgzname); return; };
    
	if (tess)
	{
		tessver = hdr.version = TESSVERSION; // saving defaults to output of tesseract maps
		snprintf(hdr.head, sizeof(hdr.head)-1, "TESS");
		tessmap = true;
	}
	else
	{
		tessver = hdr.version = OCTAVERSION; // save as a sauerbraten map, lets us use our features for legacy stuff
		snprintf(hdr.head, sizeof(hdr.head)-1, "OCTA");
		tessmap = false;
	}
	
    hdr.numents = 0;
    
	const vector<extentity *> &ents = et->getents();
    loopv(ents) if(ents[i]->type!=ET_EMPTY) hdr.numents++;
    
	hdr.lightmaps = nolms ? 0 : lightmaps.length();
    header tmp = hdr;
    
	endianswap(&tmp.version, sizeof(int), 16);
    gzwrite(g, &tmp, sizeof(header));
    
    gzputc(g, (int)strlen(cl->gameident()));
    gzwrite(g, cl->gameident(), (int)strlen(cl->gameident())+1);

    writeushort(g, et->extraentinfosize());

    vector<char> extras;
    cl->writegamedata(extras);
    writeushort(g, extras.length());
    gzwrite(g, extras.getbuf(), extras.length());
    
    writeushort(g, texmru.length());
    loopv(texmru) writeushort(g, texmru[i]);

    char *ebuf = new char[et->extraentinfosize()];
    loopv(ents)
    { dbg;
        if((ents[i]->type!=ET_EMPTY) && ((tessmap) || (strcmp(cl->gameident(), "fps") != 0) || (ents[i]->type < 22))) //sauer legacy hack
        { dbg;
            entity tmp = *ents[i];
            endianswap(&tmp.o, sizeof(int), 3);
            endianswap(&tmp.attr1, sizeof(short), 5);
            gzwrite(g, &tmp, sizeof(entity));
            et->writeent(*ents[i], ebuf);
            if(et->extraentinfosize()) gzwrite(g, ebuf, et->extraentinfosize());
        };
    };
    delete[] ebuf;

    savec(worldroot, g, nolms);

    if(!nolms) loopv(lightmaps)
    { dbg;
        LightMap &lm = lightmaps[i];
        gzputc(g, lm.type);
        gzwrite(g, lm.data, sizeof(lm.data));
    };

    gzclose(g);
    conoutf("wrote map file %s", cgzname);

	if (tessmap)
		writeworldcfg(owvname, true);
	else if (wastess)
		writeworldcfg(mcfname, false);
};

void swapXZ(cube *c)
{ dbg;	
	loopi(8) 
	{ dbg;
		swap(uint,   c[i].faces[0],   c[i].faces[2]);
		swap(ushort, c[i].texture[0], c[i].texture[4]);
		swap(ushort, c[i].texture[1], c[i].texture[5]);
		if(c[i].surfaces)
		{ dbg;
			swap(surfaceinfo, c[i].surfaces[0], c[i].surfaces[4]);
			swap(surfaceinfo, c[i].surfaces[1], c[i].surfaces[5]);
		};
		if(c[i].children) swapXZ(c[i].children);
	};
};

void load_world(char *mname)        // still supports all map formats that have existed since the earliest cube betas!
{ dbg;
    int loadingstart = SDL_GetTicks();

    setnames(mname);

    gzFile f = gzopen(cgzname, "rb9");
    if(!f) { conoutf("could not read map %s", cgzname); return; };

    clearoverrides();
    computescreen(mname, true, true);

    gzread(f, &hdr, sizeof(header));
    endianswap(&hdr.version, sizeof(int), 16);

	tessver = hdr.version;

    if(isoctamap(hdr.head))
	{
    	if(hdr.version>OCTAVERSION) fatal("this map requires a newer version of sauerbraten");
    	tessmap = false;
	}
    else if(istessmap(hdr.head))
	{
    	if(hdr.version>TESSVERSION) fatal("this map requires a newer version of tesseract");
    	tessmap = true;
	}
	else
	{
		conoutf("%s is a %s map version %d", cgzname, hdr.head, hdr.version);
		fatal("while reading map: header malformatted");
	}

    if(!hdr.ambient) hdr.ambient = 25;
    if(!hdr.lerpsubdivsize)
    { dbg;
        if(!hdr.lerpangle) hdr.lerpangle = 44;
        hdr.lerpsubdiv = 2;
        hdr.lerpsubdivsize = 4;
    };

    setvar("lightprecision", hdr.mapprec ? hdr.mapprec : 32);
    setvar("lighterror", hdr.maple ? hdr.maple : 8);
    setvar("lightlod", hdr.mapllod);
    setvar("lodsize", hdr.mapwlod);
    setvar("ambient", hdr.ambient);
    setvar("fullbright", 0);
    setvar("lerpangle", hdr.lerpangle);
    setvar("lerpsubdiv", hdr.lerpsubdiv);
    setvar("lerpsubdivsize", hdr.lerpsubdivsize);
    
    string gametype;
    s_strcpy(gametype, "fps");

    bool samegame = true;
    int eif = 0;

    if(hdr.version>=16)
    { dbg;
        int len = gzgetc(f);
        gzread(f, gametype, len+1);
    };

    if(strcmp(gametype, cl->gameident())!=0)
    { dbg;
        samegame = false;
        conoutf("WARNING: loading map from %s game, ignoring entities except for lights/mapmodels)", gametype);
    };

    if(hdr.version>=16)
    { dbg;
        eif = readushort(f);
        int extrasize = readushort(f);
        vector<char> extras;
        loopj(extrasize) extras.add(gzgetc(f));
        if(samegame) cl->readgamedata(extras);
    };
    
    show_out_of_renderloop_progress(0, "clearing world...");

    texmru.setsize(0);
    if(hdr.version<14)
    { dbg;
        uchar oldtl[256];
        gzread(f, oldtl, sizeof(oldtl));
        loopi(256) texmru.add(oldtl[i]);
    }
    else
    { dbg;
        ushort nummru = readushort(f);
        loopi(nummru) texmru.add(readushort(f));
    };

    freeocta(worldroot);
    worldroot = NULL;

    show_out_of_renderloop_progress(0, "loading entities...");
    vector<extentity *> &ents = et->getents();
    ents.deletecontentsp();

    char *ebuf = new char[et->extraentinfosize()];
    loopi(hdr.numents)
    { dbg;
        extentity &e = *et->newentity();
        ents.add(&e);
        gzread(f, &e, sizeof(entity));
        endianswap(&e.o, sizeof(int), 3);
        endianswap(&e.attr1, sizeof(short), 5);
        e.spawned = false;
        e.inoctanode = false;
        if(samegame)
        { dbg;
            if(et->extraentinfosize()) gzread(f, ebuf, et->extraentinfosize());
            et->readent(e, ebuf); 
        }
        else
        { dbg;
            loopj(eif) gzgetc(f);
            if(e.type>=ET_GAMESPECIFIC || hdr.version<=14)
            { dbg;
                ents.pop();
                continue;
            };
        };
        if(hdr.version <= 14 && e.type >= ET_MAPMODEL && e.type <= 16)
        { dbg;
            if(e.type == 16) e.type = ET_MAPMODEL;
            else e.type++;
        };
        if(!insideworld(e.o))
        { dbg;
            if(e.type != ET_LIGHT)
            { dbg;
                conoutf("warning: ent outside of world: enttype[%s] index %d (%f, %f, %f)", et->entname(e.type), i, e.o.x, e.o.y, e.o.z);
            };
        };
        if(hdr.version <= 14 && e.type == ET_MAPMODEL)
        { dbg;
            e.o.z += e.attr3;
            if(e.attr4) conoutf("warning: mapmodel ent (index %d) uses texture slot %d", i, e.attr4);
            e.attr3 = e.attr4 = 0;
        };
    };
    delete[] ebuf;

    show_out_of_renderloop_progress(0, "loading octree...");
    worldroot = loadchildren(f);

	if(hdr.version <= 11)
		swapXZ(worldroot);

    if(hdr.version <= 8)
        converttovectorworld();

    show_out_of_renderloop_progress(0, "validating...");
    validatec(worldroot, hdr.worldsize>>1);

    resetlightmaps();
    if(hdr.version < 7 || !hdr.lightmaps) clearlights();
    else
    { dbg;
        loopi(hdr.lightmaps)
        { dbg;
            show_out_of_renderloop_progress(i/(float)hdr.lightmaps, "loading lightmaps...");
            LightMap &lm = lightmaps.add();
            if(hdr.version >= 17) lm.type = gzgetc(f);
            gzread(f, lm.data, 3 * LM_PACKW * LM_PACKH);
            lm.finalize();
        };
        initlights();
    };

    gzclose(f);

// FIXME: need to load texture slots before VAs can be properly sorted    
//    allchanged();

    conoutf("read map %s (%.1f seconds)", cgzname, (SDL_GetTicks()-loadingstart)/1000.0f);
    centerprintf("%s", hdr.maptitle);
    estartmap(mname);
    
	worldidents = overrideidents = 1;
    if (tessmap)
    {
	    execfile("tesseract/data/map.cfg");
	    execfile(pcfname);
	    execfile(mcfname);
	    execfile(owvname);
	}
	else
	{
	    execfile("data/default_map_settings.cfg");
	    execfile(pcfname);
	    execfile(mcfname);
	}
    worldidents = overrideidents = 0;

    allchanged();

    precacheall();

    loopv(ents)
    { dbg;
        extentity &e = *ents[i];
        if(e.type==ET_MAPMODEL && e.attr2 >= 0)
        { dbg;
            mapmodelinfo &mmi = getmminfo(e.attr2);
            if(!&mmi) conoutf("could not find map model: %d", e.attr2);
            else if(!loadmodel(mmi.name)) conoutf("could not load model: %s", mmi.name);
        };
    };
    entitiesinoctanodes();
};

void savecurrentmap() { save_world(cl->getclientmap()); };
void savemap(char *mname) { save_world(mname); };
void saveocta(char *mname) { save_world(mname, false, false); };

COMMAND(savecurrentmap, "");
COMMAND(savemap, "s");
COMMAND(saveocta, "s");


