// rendergl.cpp: core opengl rendering stuff

#include "pch.h"
#include "engine.h"

bool hasVBO = false, hasOQ = false, hasTR = false, hasFC = false;
int renderpath;

GLUquadricObj *qsphere = NULL;

PFNGLGENBUFFERSARBPROC    glGenBuffers_    = NULL;
PFNGLBINDBUFFERARBPROC    glBindBuffer_    = NULL;
PFNGLBUFFERDATAARBPROC    glBufferData_    = NULL;
PFNGLDELETEBUFFERSARBPROC glDeleteBuffers_ = NULL;

PFNGLACTIVETEXTUREARBPROC       glActiveTexture_       = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC glClientActiveTexture_ = NULL;

PFNGLGENPROGRAMSARBPROC            glGenPrograms_ = NULL;
PFNGLBINDPROGRAMARBPROC            glBindProgram_ = NULL;
PFNGLPROGRAMSTRINGARBPROC          glProgramString_ = NULL;
PFNGLPROGRAMENVPARAMETER4FARBPROC  glProgramEnvParameter4f_ = NULL;
PFNGLPROGRAMENVPARAMETER4FVARBPROC glProgramEnvParameter4fv_ = NULL;

PFNGLGENQUERIESARBPROC        glGenQueries_ = NULL;
PFNGLDELETEQUERIESARBPROC     glDeleteQueries_ = NULL;
PFNGLBEGINQUERYARBPROC        glBeginQuery_ = NULL;
PFNGLENDQUERYARBPROC          glEndQuery_ = NULL;
PFNGLGETQUERYIVARBPROC        glGetQueryiv_ = NULL;
PFNGLGETQUERYOBJECTUIVARBPROC glGetQueryObjectuiv_ = NULL;

hashtable<const char *, Shader> shaders;
static Shader *curshader = NULL;
static vector<ShaderParam> curparams;
Shader *defaultshader = NULL;
Shader *notextureshader = NULL;

Shader *lookupshaderbyname(const char *name) { return shaders.access(name); };

void compileshader(GLint type, GLuint &idx, char *def, char *tname, char *name)
{ dbg;
    glGenPrograms_(1, &idx);
    glBindProgram_(type, idx);
    def += strspn(def, " \t\r\n");
    glProgramString_(type, GL_PROGRAM_FORMAT_ASCII_ARB, (GLsizei)strlen(def), def);
    GLint err;
    glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &err);
    if(err!=-1)
    { dbg;
        conoutf("COMPILE ERROR (%s:%s) - %s", tname, name, glGetString(GL_PROGRAM_ERROR_STRING_ARB)); 
        loopi(err) putchar(*def++);
        puts(" <<HERE>> ");
        while(*def) putchar(*def++);
    };
};

void shader(int *type, char *name, char *vs, char *ps)
{ dbg;
    if(lookupshaderbyname(name)) return;
    char *rname = newstring(name);
    Shader &s = shaders[rname];
    s.name = rname;
    s.type = *type;
    loopv(curparams) s.defaultparams.add(curparams[i]);
    curparams.setsize(0);
    if(renderpath!=R_FIXEDFUNCTION)
    { dbg;
        compileshader(GL_VERTEX_PROGRAM_ARB,   s.vs, vs, "VS", name);
        compileshader(GL_FRAGMENT_PROGRAM_ARB, s.ps, ps, "PS", name);
    };
};

void setshader(char *name)
{ dbg;
    Shader *s = lookupshaderbyname(name);
    if(!s) conoutf("no such shader: %s", name);
    else curshader = s;
    curparams.setsize(0);
};

COMMAND(shader, "isss");
COMMAND(setshader, "s");

void setshaderparam(int type, int n, float x, float y, float z, float w)
{ dbg;
    if(n<0 || n>=MAXSHADERPARAMS)
    { dbg;
        conoutf("shader param index must be 0..%d\n", MAXSHADERPARAMS-1);
        return;
    };
    loopv(curparams)
    { dbg;
        ShaderParam &param = curparams[i];
        if(param.type == type && param.index == n)
        { dbg;
            param.val[0] = x;
            param.val[1] = y;
            param.val[2] = z;
            param.val[3] = w;
            return;
        };
    };
    ShaderParam param = {type, n, {x, y, z, w}};
    curparams.add(param);
};

void setvertexparam(int *n, float *x, float *y, float *z, float *w)
{ dbg;
    setshaderparam(SHPARAM_VERTEX, *n, *x, *y, *z, *w);
};

void setpixelparam(int *n, float *x, float *y, float *z, float *w)
{ dbg;
    setshaderparam(SHPARAM_PIXEL, *n, *x, *y, *z, *w);
};

COMMAND(setvertexparam, "iffff");
COMMAND(setpixelparam, "iffff");

VAR(shaderprecision, 0, 2, 3);
VAR(novbo, 0, 0, 1);

void *getprocaddress(const char *name)
{ dbg;
    return SDL_GL_GetProcAddress(name);
}

VAR(ati_texgen_bug, 0, 0, 1);
VAR(nvidia_texgen_bug, 0, 0, 1);

void gl_init(int w, int h, int bpp, int depth, int fsaa)
{ dbg;
    #define fogvalues 0.5f, 0.6f, 0.7f, 1.0f

    glViewport(0, 0, w, h);
    glClearColor(fogvalues);
    glClearDepth(1.0);
    glDepthFunc(GL_LESS);
    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
    
    
    glEnable(GL_FOG);
    glFogi(GL_FOG_MODE, GL_LINEAR);
    glFogf(GL_FOG_DENSITY, 0.25);
    glHint(GL_FOG_HINT, GL_NICEST);
    GLfloat fogcolor[4] = { fogvalues };
    glFogfv(GL_FOG_COLOR, fogcolor);
    

    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_POLYGON_OFFSET_LINE);
    glPolygonOffset(-3.0, -3.0);

    glCullFace(GL_FRONT);
    glEnable(GL_CULL_FACE);

    const char *vendor = (const char *)glGetString(GL_VENDOR);
    const char *exts = (char *)glGetString(GL_EXTENSIONS);
    const char *renderer = (char *)glGetString(GL_RENDERER);
    const char *version = (char *)glGetString(GL_VERSION);
    conoutf("Renderer: %s (%s)", renderer, vendor);
    conoutf("Driver: %s", version);
    
    // default to low precision shaders on certain cards, can be overridden with -f3
    char *weakcards[] = { "GeForce FX", "Quadro FX", "6200", "9500", "9550", "9600", "9700", "9800", "X300", "X600", "FireGL", "Intel", "Chrome", NULL }; 
    if(shaderprecision==2) for(char **wc = weakcards; *wc; wc++) if(strstr(renderer, *wc)) shaderprecision = 1;
    
    if(!strstr(exts, "GL_EXT_texture_env_combine") && !strstr(exts, "GL_ARB_texture_env_combine")) 
        fatal("No texture_env_combine extension! (your video card is WAY too old)");

    if(!strstr(exts, "GL_ARB_multitexture")) fatal("no multitexture extension!");
    glActiveTexture_       = (PFNGLACTIVETEXTUREARBPROC)      getprocaddress("glActiveTextureARB");
    glClientActiveTexture_ = (PFNGLCLIENTACTIVETEXTUREARBPROC)getprocaddress("glClientActiveTextureARB");

    if(!novbo || !strstr(exts, "GL_ARB_vertex_buffer_object"))
    { dbg;
        conoutf("WARNING: No vertex_buffer_object extension! (geometry heavy maps will be SLOW)");
        hasVBO = false;
    }
    else
    { dbg;
        glGenBuffers_    = (PFNGLGENBUFFERSARBPROC)   getprocaddress("glGenBuffersARB");
        glBindBuffer_    = (PFNGLBINDBUFFERARBPROC)   getprocaddress("glBindBufferARB");
        glBufferData_    = (PFNGLBUFFERDATAARBPROC)   getprocaddress("glBufferDataARB");
        glDeleteBuffers_ = (PFNGLDELETEBUFFERSARBPROC)getprocaddress("glDeleteBuffersARB");
        hasVBO = true;
        conoutf("Using GL_ARB_vertex_buffer_object extension.");
    };

    extern int floatvtx;
    if(strstr(vendor, "ATI")) floatvtx = 1;
    if(floatvtx) conoutf("WARNING: Using floating point vertexes. (use \"/floatvtx 0\" to disable)");

    if(!shaderprecision || !strstr(exts, "GL_ARB_vertex_program") || !strstr(exts, "GL_ARB_fragment_program"))
    { dbg;
        conoutf("WARNING: No shader support! Using fixed function fallback. (no fancy visuals for you)");
        renderpath = R_FIXEDFUNCTION;
        if(strstr(vendor, "ATI") && !shaderprecision) ati_texgen_bug = 1;
        else if(strstr(vendor, "NVIDIA")) nvidia_texgen_bug = 1;
        if(ati_texgen_bug) conoutf("WARNING: Using ATI texgen bug workaround. (use \"/ati_texgen_bug 0\" to disable)");
        if(nvidia_texgen_bug) conoutf("WARNING: Using NVIDIA texgen bug workaround. (use \"/nvidia_texgen_bug 0\" to disable)");
    }
    else
    { dbg;
        glGenPrograms_ =            (PFNGLGENPROGRAMSARBPROC)           getprocaddress("glGenProgramsARB");
        glBindProgram_ =            (PFNGLBINDPROGRAMARBPROC)           getprocaddress("glBindProgramARB");
        glProgramString_ =          (PFNGLPROGRAMSTRINGARBPROC)         getprocaddress("glProgramStringARB");
        glProgramEnvParameter4f_ =  (PFNGLPROGRAMENVPARAMETER4FARBPROC) getprocaddress("glProgramEnvParameter4fARB");
        glProgramEnvParameter4fv_ = (PFNGLPROGRAMENVPARAMETER4FVARBPROC)getprocaddress("glProgramEnvParameter4fvARB");
        renderpath = R_ASMSHADER;
        conoutf("Rendering using the OpenGL 1.5 assembly shader path.");
        glEnable(GL_VERTEX_PROGRAM_ARB);
        glEnable(GL_FRAGMENT_PROGRAM_ARB);
    };

    if(strstr(exts, "GL_ARB_occlusion_query"))
    { dbg;
        GLint bits;
        glGetQueryiv_ = (PFNGLGETQUERYIVARBPROC)getprocaddress("glGetQueryivARB");
        glGetQueryiv_(GL_SAMPLES_PASSED_ARB, GL_QUERY_COUNTER_BITS_ARB, &bits);
        if(bits)
        { dbg;
            glGenQueries_ =        (PFNGLGENQUERIESARBPROC)       getprocaddress("glGenQueriesARB");
            glDeleteQueries_ =     (PFNGLDELETEQUERIESARBPROC)    getprocaddress("glDeleteQueriesARB");
            glBeginQuery_ =        (PFNGLBEGINQUERYARBPROC)       getprocaddress("glBeginQueryARB");
            glEndQuery_ =          (PFNGLENDQUERYARBPROC)         getprocaddress("glEndQueryARB");
            glGetQueryObjectuiv_ = (PFNGLGETQUERYOBJECTUIVARBPROC)getprocaddress("glGetQueryObjectuivARB");
            hasOQ = true;
            conoutf("Using GL_ARB_occlusion_query extension.");
        };
    };
    if(!hasOQ) conoutf("WARNING: No occlusion query support! (large maps may be SLOW)");

    if(renderpath == R_ASMSHADER)
    { dbg;
        if(strstr(exts, "GL_ARB_texture_rectangle"))
        { dbg;
            hasTR = true;
            conoutf("Using GL_ARB_texture_rectangle extension.");
        }
        else conoutf("WARNING: No texture rectangle support. (no full screen shaders)");
    };
    if(!strstr(exts, "GL_ARB_texture_non_power_of_two")) conoutf("WARNING: Non-power-of-two textures not supported!");

    if(fsaa) glEnable(GL_MULTISAMPLE);

    if(!(qsphere = gluNewQuadric())) fatal("glu sphere");
    gluQuadricDrawStyle(qsphere, GLU_FILL);
    gluQuadricOrientation(qsphere, GLU_OUTSIDE);
    gluQuadricTexture(qsphere, GL_TRUE);
    glNewList(1, GL_COMPILE);
    gluSphere(qsphere, 1, 12, 6);
    glEndList();

    exec("tesseract/data/stdshader.cfg");
    defaultshader = lookupshaderbyname("default");
    notextureshader = lookupshaderbyname("notexture");
    defaultshader->set();
};

SDL_Surface *texrotate(SDL_Surface *s, int numrots, int type)
{ dbg;
    numrots &= 3;
    if(!numrots) return s;
    SDL_Surface *d = SDL_CreateRGBSurface(SDL_SWSURFACE, numrots&1 ? s->h : s->w, numrots&1 ? s->w : s->h, s->format->BitsPerPixel, s->format->Rmask, s->format->Gmask, s->format->Bmask, s->format->Amask);
    if(!d) fatal("create surface");
    int depth = s->format->BitsPerPixel==24 ? 3 : 4;
    loop(y, s->h) loop(x, s->w)
    { dbg;
        uchar *src = (uchar *)s->pixels+(y*s->w+x)*depth;
        int dx = x, dy = y;
        if(numrots>1) dx = (s->w-1)-x;
        if(numrots<3) dy = (s->h-1)-y;
        if(numrots!=2) swap(int, dx, dy);
        uchar *dst = (uchar *)d->pixels+(dy*d->w+dx)*depth;
        loopi(depth) dst[i]=src[i];
        if(type==TEX_NORMAL || type==TEX_NORMAL_SPEC)
        { dbg;
            if(numrots>1) dst[0] = 255-dst[0];      // flip X   on normal when 180/270 degrees
            if(numrots<3) dst[1] = 255-dst[1];      // flip Y   on normal when  90/180 degrees
            if(numrots!=2) swap(uchar, dst[0], dst[1]);       // swap X/Y on normal when  90/270 degrees
        };
    }; 
    SDL_FreeSurface(s);
    return d;
};

SDL_Surface *texoffset(SDL_Surface *s, int xoffset, int yoffset)
{ dbg;
    xoffset = max(xoffset, 0);
    xoffset %= s->w;
    yoffset = max(yoffset, 0); 
    yoffset %= s->h;
    if(!xoffset && !yoffset) return s;
    SDL_Surface *d = SDL_CreateRGBSurface(SDL_SWSURFACE, s->w, s->h, s->format->BitsPerPixel, s->format->Rmask, s->format->Gmask, s->format->Bmask, s->format->Amask);
    if(!d) fatal("create surface");
    int depth = s->format->BitsPerPixel==24 ? 3 : 4;
    uchar *src = (uchar *)s->pixels;
    loop(y, s->h)
    { dbg;
        uchar *dst = (uchar *)d->pixels+((y+yoffset)%d->h)*d->pitch;
        memcpy(dst+xoffset*depth, src, (s->w-xoffset)*depth);
        memcpy(dst, src+(s->w-xoffset)*depth, xoffset*depth);
        src += s->pitch;
    };
    SDL_FreeSurface(s);
    return d;
};
 
void createtexture(int tnum, int w, int h, void *pixels, bool clamp, bool mipit, int bpp, GLenum target)
{ dbg;
    glBindTexture(target, tnum);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexParameteri(target, GL_TEXTURE_WRAP_S, clamp ? GL_CLAMP_TO_EDGE : GL_REPEAT);
    glTexParameteri(target, GL_TEXTURE_WRAP_T, clamp ? GL_CLAMP_TO_EDGE : GL_REPEAT);
    glTexParameteri(target, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(target, GL_TEXTURE_MIN_FILTER, mipit ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR); 
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    int mode = bpp==24 ? GL_RGB : GL_RGBA;
    if(mipit) { if(gluBuild2DMipmaps(target, mode, w, h, mode, GL_UNSIGNED_BYTE, pixels)) fatal("could not build mipmaps"); }
    else glTexImage2D(target, 0, mode, w, h, 0, mode, GL_UNSIGNED_BYTE, pixels);
}

hashtable<char *, Texture> textures;

Texture *crosshair = NULL; // used as default, ensured to be loaded

static Texture *newtexture(const char *rname, SDL_Surface *s, bool clamp = false, bool mipit = true)
{ dbg;
    Texture *t = &textures[newstring(rname)];
    s_strcpy(t->name, rname);
    t->bpp = s->format->BitsPerPixel;
    t->xs = s->w;
    t->ys = s->h;
    glGenTextures(1, &t->gl);
    createtexture(t->gl, t->xs, t->ys, s->pixels, clamp, mipit, t->bpp);
    SDL_FreeSurface(s);
    return t;
};

static SDL_Surface *texturedata(const char *tname, Slot::Tex *tex = NULL, bool msg = true)
{ dbg;
    static string pname;
    if(tex && !tname)
    { dbg;
        s_sprintf(pname)("packages/%s", tex->name);
        tname = path(pname);
    };
    
    //show_out_of_renderloop_progress(0, tname);

    SDL_Surface *s = IMG_Load(tname);
    if(!s) { if(msg) conoutf("could not load texture %s", tname); return NULL; };
    int bpp = s->format->BitsPerPixel;
    if(bpp!=24 && bpp!=32) { SDL_FreeSurface(s); if (msg) { conoutf("texture must be 24 or 32 bpp: %s", tname); }; return NULL; };
    if(tex)
    { dbg;
        if(tex->rotation) s = texrotate(s, tex->rotation, tex->type);
        if(tex->xoffset || tex->yoffset) s = texoffset(s, tex->xoffset, tex->yoffset);
    };
    return s;
};

Texture *textureload(const char *name, bool clamp, bool mipit, bool msg)
{ dbg;
    string tname;
    s_strcpy(tname, name);
    Texture *t = textures.access(path(tname));
    if(t) return t;
    SDL_Surface *s = texturedata(tname, NULL, msg);
    return s ? newtexture(tname, s, clamp, mipit) : crosshair;
};

void cleangl()
{ dbg;
    if(qsphere) gluDeleteQuadric(qsphere);
    enumeratekt(textures, char *, k, Texture, t, { delete[] k; /*t;*/ });
    textures.clear();
};

bool settexture(const char *name)
{ dbg;
	Texture *t = textureload(name, false, true, false);
    glBindTexture(GL_TEXTURE_2D, t->gl);
    return t != crosshair;
};

vector<Slot> slots;

int curtexnum = 0;

void texturereset() { curtexnum = 0; slots.setsize(0); };

ShaderParam *findshaderparam(Slot &s, int type, int index)
{ dbg;
    loopv(s.params)
    { dbg;
        ShaderParam &param = s.params[i];
        if(param.type==type && param.index==index) return &param;
    };
    loopv(s.shader->defaultparams)
    { dbg;
        ShaderParam &param = s.shader->defaultparams[i];
        if(param.type==type && param.index==index) return &param;
    };
    return NULL;
};

void texture(char *type, char *name, int *rot, int *xoffset, int *yoffset)
{ dbg;
    if(curtexnum<0 || curtexnum>=0x10000) return;
    struct { const char *name; int type; } types[] = 
    {
        {"c", TEX_DIFFUSE},
        {"u", TEX_UNKNOWN},
        {"d", TEX_DECAL},
        {"n", TEX_NORMAL},
        {"ns", TEX_NORMAL_SPEC},
        {"g", TEX_GLOW},
        {"s", TEX_SPEC},
        {"z", TEX_DEPTH},
    };
    int tnum = -1;
    loopi(sizeof(types)/sizeof(types[0])) if(!strcmp(types[i].name, type)) { tnum = i; break; };
    if(tnum<0) tnum = atoi(type);
    if(tnum==TEX_DIFFUSE) curtexnum++;
    else if(!curtexnum) return;
    Slot &s = tnum!=TEX_DIFFUSE ? slots.last() : slots.add();
    if(tnum==TEX_DIFFUSE)
    { dbg;
        s.shader = curshader ? curshader : defaultshader;
        loopv(curparams)
        { dbg;
            ShaderParam &param = curparams[i], *defaultparam = findshaderparam(s, tnum, param.index);    
            if(!defaultparam || memcmp(param.val, defaultparam->val, sizeof(param.val))) s.params.add(param);
        };
    };
    s.loaded = false;
    if(s.sts.length()>=8) conoutf("warning: too many textures in slot %d", curtexnum);
    Slot::Tex &st = s.sts.add();
    st.type = tnum;
    st.combined = -1;
    st.rotation = max(*rot, 0)&3;
    st.xoffset = max(*xoffset, 0);
    st.yoffset = max(*yoffset, 0);
    st.t = NULL;
    s_strcpy(st.name, name);
    path(st.name);
};

COMMAND(texturereset, "");
COMMAND(texture, "ssiii");

static int findtextype(Slot &s, int type, int last = -1)
{ dbg;
    for(int i = last+1; i<s.sts.length(); i++) if((type&(1<<s.sts[i].type)) && s.sts[i].combined<0) return i;
    return -1;
};

#define writetex(t, body) \
    { \
        uchar *dst = (uchar *)t->pixels; \
        loop(y, t->h) loop(x, t->w) \
        { \
            body; \
            dst += t->format->BitsPerPixel/8; \
        } \
    }

#define sourcetex(t, s) uchar *src = &((uchar *)s->pixels)[(s->format->BitsPerPixel/8)*((y%t->h)*s->w + (x%t->w))];

static void addglow(SDL_Surface *c, SDL_Surface *g, Slot &s)
{ dbg;
    ShaderParam *cparam = findshaderparam(s, SHPARAM_PIXEL, 0);
    float color[3] = {1, 1, 1};
    if(cparam) memcpy(color, cparam->val, sizeof(color));     
    writetex(c, 
        sourcetex(c, g);
        loopk(3) dst[k] = min(255, int(dst[k]) + int(src[k] * color[k]));
    );
};
 
static void blenddecal(SDL_Surface *c, SDL_Surface *d)
{ dbg;
    writetex(c,
        sourcetex(c, d);
        uchar a = src[3];
        loopk(3) dst[k] = (int(src[k])*int(a) + int(dst[k])*int(255-a))/255;
    );
};

static void mergespec(SDL_Surface *c, SDL_Surface *s)
{ dbg;
    writetex(c,
        sourcetex(c, s);
        dst[3] = (int(src[0]) + int(src[1]) + int(src[2]))/3;
    );
};

static void mergedepth(SDL_Surface *c, SDL_Surface *z)
{ dbg;
    writetex(c,
        sourcetex(c, z);
        dst[3] = src[0];
    );
};
 
static void addname(vector<char> &key, Slot &slot, Slot::Tex &t)
{ dbg;
    if(t.combined>=0) key.add('&');
    s_sprintfd(tname)("packages/%s", t.name);
    for(const char *s = path(tname); *s; key.add(*s++));
    if(t.rotation)
    { dbg;
        s_sprintfd(rnum)("#%d", t.rotation);
        for(const char *s = rnum; *s; key.add(*s++));
    };
    if(t.xoffset || t.yoffset)
    { dbg;
        s_sprintfd(toffset)("+%d,%d", t.xoffset, t.yoffset);
        for(const char *s = toffset; *s; key.add(*s++));
    };
    switch(t.type)
    {
        case TEX_GLOW:
        { dbg;
            ShaderParam *cparam = findshaderparam(slot, SHPARAM_PIXEL, 0);
            s_sprintfd(suffix)("?%.2f,%.2f,%.2f", cparam ? cparam->val[0] : 1.0f, cparam ? cparam->val[1] : 1.0f, cparam ? cparam->val[2] : 1.0f);
            for(const char *s = suffix; *s; key.add(*s++));
        };
    };
};

static void texcombine(Slot &s, int index, Slot::Tex &t)
{ dbg;
    vector<char> key;
    addname(key, s, t);
    if(renderpath==R_FIXEDFUNCTION && t.type!=TEX_DIFFUSE) { t.t = crosshair; return; };
    switch(t.type)
    {
        case TEX_DIFFUSE:
            if(renderpath!=R_FIXEDFUNCTION) break;
            for(int i = -1; (i = findtextype(s, (1<<TEX_DECAL)|(1<<TEX_GLOW), i))>=0;)
            { dbg;
                s.sts[i].combined = index;
                addname(key, s, s.sts[i]);
            };
            break;

        case TEX_NORMAL:
        case TEX_GLOW:
        { dbg;
            int i = findtextype(s, (1<<TEX_SPEC)|(1<<TEX_DEPTH));
            if(i<0) break;
            s.sts[i].combined = index;
            addname(key, s, s.sts[i]);
            break;
        };                 
    };
    key.add('\0');
    t.t = textures.access(key.getbuf());
    if(t.t) return;
    SDL_Surface *ts = texturedata(NULL, &t);
    if(!ts) { t.t = crosshair; return; };
    switch(t.type)
    {
        case TEX_DIFFUSE:
            loopv(s.sts)
            { dbg;
                Slot::Tex &b = s.sts[i];
                if(b.combined!=index) continue;
                SDL_Surface *bs = texturedata(NULL, &b);
                if(!bs) continue;
                if((ts->w%bs->w)==0 && (ts->h%bs->h)==0) switch(b.type)
                { 
                    case TEX_DECAL: if(bs->format->BitsPerPixel==32) blenddecal(ts, bs); break;
                    case TEX_GLOW: addglow(ts, bs, s); break;
                };
                SDL_FreeSurface(bs);
            };
            break;        

        case TEX_NORMAL:
        case TEX_GLOW:
            loopv(s.sts)
            { dbg;
                Slot::Tex &a = s.sts[i];
                if(a.combined!=index) continue;
                SDL_Surface *as = texturedata(NULL, &a);
                if(!as) break;
                if(ts->format->BitsPerPixel!=32)
                { dbg;
                    SDL_Surface *ns = SDL_CreateRGBSurface(SDL_SWSURFACE, ts->w, ts->h, 32, ts->format->Rmask, ts->format->Gmask, ts->format->Bmask, ts->format->Amask);
                    if(!ns) fatal("create surface");
                    SDL_BlitSurface(ts, NULL, ns, NULL);
                    SDL_FreeSurface(ts);
                    ts = ns;
                };
                switch(a.type)
                {
                    case TEX_SPEC: mergespec(ts, as); break;
                    case TEX_DEPTH: mergedepth(ts, as); break;
                };
                SDL_FreeSurface(as);
                break; // only one combination
            };
            break;
    };
    t.t = newtexture(key.getbuf(), ts);
};

Slot &lookuptexture(int slot, bool load)
{ dbg;
    Slot &s = slots[slots.inrange(slot) ? slot : 0];
    if(s.loaded || !load) return s;
    loopv(s.sts)
    { dbg;
        Slot::Tex &t = s.sts[i];
        if(t.combined<0) texcombine(s, i, t);
    };
    s.loaded = true;
    return s;
};

Shader *lookupshader(int slot) { return slots.inrange(slot) ? slots[slot].shader : defaultshader; };

VARFP(gamma, 30, 100, 300,
{ dbg;
    float f = gamma/100.0f;
    if(SDL_SetGamma(f,f,f)==-1)
    { dbg;
        conoutf("Could not set gamma (card/driver doesn't support it?)");
        conoutf("sdl: %s", SDL_GetError());
    };
});

VARF(wireframe, 0, 0, 1, if(noedit(true)) wireframe = 0);

void transplayer()
{ dbg;
    glLoadIdentity();

    glRotatef(player->rot.x,-1.0,0.0,0.0);
    glRotatef(player->rot.y,0.0,1.0,0.0);
    glRotatef(player->rot.z,0.0,0.0,1.0);

    // move from RH to Z-up LH quake style worldspace
   	glRotatef(-90.0, 1.0, 0.0, 0.0);

    glScalef(1.0, -1.0, 1.0);

    glTranslatef(-camera1->o.x, -camera1->o.y, 0-camera1->o.z);

};

VARP(fov, 10, 110, 160);

int xtraverts, xtravertsva;

WVAR(fog, 16, 4000, 1000024);
WVAR(fogcolour, 0, 0x8099B3, 0xFFFFFF);

VARP(sparklyfix, 0, 1, 1);
VAR(showsky, 0, 1, 1);

extern int explicitsky, skyarea;

void drawskybox(int farplane, bool limited)
{ dbg;
    glDisable(GL_FOG);

    if(limited)
    { dbg;
        notextureshader->set();

        glDisable(GL_TEXTURE_2D);
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        rendersky();
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glEnable(GL_TEXTURE_2D);

        defaultshader->set();
    };

    glLoadIdentity();
    glRotated(player->rot.x, -1.0, 0.0, 0.0);
    glRotated(player->rot.y,  0.0, 1.0, 0.0);
    glRotated(90.0, 1.0, 0.0, 0.0);
    glColor3f(1.0f, 1.0f, 1.0f);
    if(limited) glDepthFunc(editmode || !insideworld(player->o) ? GL_ALWAYS : GL_GEQUAL);
    draw_envbox(farplane/2);
    transplayer();
    if(limited) 
    { dbg;
        if(!levelshot && editmode && showsky)
        { dbg;
            notextureshader->set();

            glDepthFunc(GL_LEQUAL);
            glDisable(GL_TEXTURE_2D);
            glDepthMask(GL_FALSE);
            if(!wireframe) glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            glColor3f(0.5f, 0.0f, 0.5f);
            rendersky(true);
            if(!wireframe) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glDepthMask(GL_TRUE);
            glEnable(GL_TEXTURE_2D);

            defaultshader->set();
        };
        glDepthFunc(GL_LESS);
    };

    glEnable(GL_FOG);
};

const int NUMSCALE = 7;
Shader *fsshader = NULL, *scaleshader = NULL;
GLuint rendertarget[NUMSCALE];
GLfloat fsparams[4];
int fs_w = 0, fs_h = 0;

void setfullscreenshader(char *name, int *x, int *y, int *z, int *w)
{ dbg;
    if(!hasTR || !*name)
    { dbg;
        fsshader = NULL;
    }
    else
    { dbg;
        Shader *s = lookupshaderbyname(name);
        if(!s) return conoutf("no such fullscreen shader: %s", name);
        fsshader = s;
        string ssname;
        s_strcpy(ssname, name);
        s_strcat(ssname, "_scale");
        scaleshader = lookupshaderbyname(ssname);
        static bool rtinit = false;
        if(!rtinit)
        { dbg;
            rtinit = true;
            glGenTextures(NUMSCALE, rendertarget);
        };
        conoutf("now rendering with: %s", name);
        fsparams[0] = *x/255.0f;
        fsparams[1] = *y/255.0f;
        fsparams[2] = *z/255.0f;
        fsparams[3] = *w/255.0f;
    };
};

COMMAND(setfullscreenshader, "siiii");

void renderfsquad(int w, int h, Shader *s)
{ dbg;
    s->set();
    glViewport(0, 0, w, h);
    if(s==scaleshader)
    { dbg;
        w *= 2;
        h *= 2;
    };
    glBegin(GL_QUADS);
    glTexCoord2i(0, 0); glVertex3f(-1, -1, 0);
    glTexCoord2i(w, 0); glVertex3f( 1, -1, 0);
    glTexCoord2i(w, h); glVertex3f( 1,  1, 0);
    glTexCoord2i(0, h); glVertex3f(-1,  1, 0);
    glEnd();
};

void renderfullscreenshader(int w, int h)
{ dbg;
    if(!fsshader || renderpath==R_FIXEDFUNCTION) return;

    glDisable(GL_DEPTH_TEST);
    glDepthMask(GL_FALSE);
    glEnable(GL_TEXTURE_RECTANGLE_ARB);

    if(fs_w != w || fs_h != h)
    { dbg;
        char *pixels = new char[w*h*3];
        loopi(NUMSCALE)
            createtexture(rendertarget[i], w>>i, h>>i, pixels, true, false, 24, GL_TEXTURE_RECTANGLE_ARB);
        delete[] pixels;
        fs_w = w;
        fs_h = h;
    };

    glProgramEnvParameter4f_(GL_FRAGMENT_PROGRAM_ARB, 0, fsparams[0], fsparams[1], fsparams[2], fsparams[3]);

    int nw = w, nh = h;

    loopi(NUMSCALE)
    { dbg;
        glBindTexture(GL_TEXTURE_RECTANGLE_ARB, rendertarget[i]);
        glCopyTexSubImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, 0, 0, 0, 0, nw, nh);
        if(i>=NUMSCALE-1 || !scaleshader) break;
        renderfsquad(nw /= 2, nh /= 2, scaleshader);
    };

    if(scaleshader) loopi(NUMSCALE)
    { dbg;
        glActiveTexture_(GL_TEXTURE0_ARB+i);
        glEnable(GL_TEXTURE_RECTANGLE_ARB);
        glBindTexture(GL_TEXTURE_RECTANGLE_ARB, rendertarget[i]);
    };
    renderfsquad(w, h, fsshader);

    glActiveTexture_(GL_TEXTURE0_ARB);
    glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST);
};

WVAR(thirdperson, 0, 0, 1);
VARP(thirdpersondistance, 10, 50, 1000);
VARP(thirdpersonheight, 1, 5, 50);
physent *camera1 = NULL;
bool isthirdperson() { return player!=camera1; };

void recomputecamera()
{ dbg;
    if(editmode || !thirdperson)
    { dbg;
        camera1 = player;
    }
    else
    { dbg;
        static physent tempcamera;
        camera1 = &tempcamera;
        *camera1 = *player;
        camera1->reset();
        camera1->type = ENT_CAMERA;
        
		vec v;
		float a = (((float)thirdpersondistance)/((float)thirdpersonheight));
		float p = atanf(a);
		camera1->rot.x = player->rot.x + p;
		camera1->rot.y = player->rot.y;
        camera1->move = 0-thirdpersondistance;
        camera1->eyeheight = 2;
		vecfromyawpitch(camera1->rot.y, camera1->rot.x, camera1->move, 0, v, true);
		camera1->o.add(v);
    };
};

void project(float fovy, float aspect, int farplane)
{ dbg;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fovy, aspect, 0.54f, farplane);
    glMatrixMode(GL_MODELVIEW);
};

void gl_drawframe(int w, int h, float curfps)
{ dbg;
    defaultshader->set();

    recomputecamera();
    
    glClear(GL_DEPTH_BUFFER_BIT|(wireframe ? GL_COLOR_BUFFER_BIT : 0));

	#define findcube(z) lookupcube((int)camera1->o.x, (int)camera1->o.y, z)
    float fovy = (float)fov*h/w;
    float aspect = w/(float)h;
    int curmat = findcube(int(camera1->o.z + camera1->aboveeye*0.5f)).material;
    float fogc[4] = { (fogcolour>>16)/256.0f, ((fogcolour>>8)&255)/256.0f, (fogcolour&255)/256.0f, 1.0f };
    
    if (!editmode)
    {
	    if((curmat == MAT_WATER) || (curmat == MAT_FOG))
	    { dbg;
	    	int a, b; // based on the amount of fog currently above
		    int curtag = findcube(int(camera1->o.z + camera1->aboveeye*0.5f)).mattag;
			
			if (curmat == MAT_WATER)
			{
		        fovy += (float)sin(lastmillis/1000.0)*2.0f;
		        aspect += (float)sin(lastmillis/1000.0+PI)*0.1f;
			}
			fogc[0] = findcube(int(camera1->o.z + camera1->aboveeye*0.5f)).matcol[0] / 256.0f;
			fogc[1] = findcube(int(camera1->o.z + camera1->aboveeye*0.5f)).matcol[1] / 256.0f;
			fogc[2] = findcube(int(camera1->o.z + camera1->aboveeye*0.5f)).matcol[2] / 256.0f;
			
	    	for (a = int(camera1->o.z + camera1->aboveeye*0.5f), b = 0; (a < (hdr.worldsize/2)) && (findcube(a).material == MAT_FOG); a++)
	    	{
				b++;
			}
	    	
	    	int fl = (curtag+96)/(8+(b/10));
	    	if (fl < 100) fl = 100; // don't go lower than 100, it's too blinding
	    	
	        glFogi(GL_FOG_START, 0);
	        glFogi(GL_FOG_END, fl);
	    }
	    else
	    {
		    glFogi(GL_FOG_START, (fog+64)/8);
		    glFogi(GL_FOG_END, fog);
		}
	}
	else
	{
	    glFogi(GL_FOG_START, 4096/8);
	    glFogi(GL_FOG_END, fog);
	}
    glFogfv(GL_FOG_COLOR, fogc);
    glClearColor(fogc[0], fogc[1], fogc[2], 1.0f);
    int farplane = max(max(fog*2, 384), hdr.worldsize*2);

    project(fovy, aspect, farplane);

    transplayer();

    glEnable(GL_TEXTURE_2D);
    
    glPolygonMode(GL_FRONT_AND_BACK, wireframe ? GL_LINE : GL_FILL);
    
    xtravertsva = xtraverts = glde = 0;

    visiblecubes(worldroot, hdr.worldsize/2, 0, 0, 0, w, h);

    bool limitsky = explicitsky || (sparklyfix && skyarea*10 / (float(hdr.worldsize>>4)*float(hdr.worldsize>>4)*6) < 9);

    if(limitsky) drawskybox(farplane, true);

    glTexEnvf(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2.0f);
    
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    if(ati_texgen_bug) glEnable(GL_TEXTURE_GEN_R);     // should not be needed, but apparently makes some ATI drivers happy

    renderq();

    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);
    if(ati_texgen_bug) glDisable(GL_TEXTURE_GEN_R);

    glTexEnvf(GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 1.0f);

    if(!wireframe) renderoutline();

    rendermapmodels();

    defaultshader->set();

    cl->rendergame();

    defaultshader->set();

    if(!limitsky) drawskybox(farplane, false);

    project(65, aspect, farplane);
    if(!isthirdperson()) cl->drawhudgun();
    project(fovy, aspect, farplane);

    defaultshader->set();

    rendermaterials();
    renderregions();
    renderelements();

    glDisable(GL_FOG);

    renderspheres(curtime);
    render_particles(curtime);

    glDisable(GL_CULL_FACE);

    renderfullscreenshader(w, h);

    glDisable(GL_TEXTURE_2D);
    notextureshader->set();

    gl_drawhud(w, h, (int)curfps, 0, verts.length(), curmat);

    glEnable(GL_CULL_FACE);
    glEnable(GL_FOG);
};

