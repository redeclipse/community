// main.cpp: initialisation & main loop

#include "pch.h"
#include "engine.h"

#ifdef DBG
int vline;
char vfile[512];
#endif

void quit()                     // normal exit
{ dbg;
    writeservercfg();
    disconnect(true);
    if(strcmp(cl->gameident(), "fps")==0) writecfg();       // TEMP HACK: make other games not overwrite cfg
    cleangl();
    cleanupserver();
    SDL_ShowCursor(1);
    freeocta(worldroot);
    extern void clear_command(); clear_command();
    extern void clear_console(); clear_console();
    extern void clear_menus();   clear_menus();
    extern void clear_mdls();    clear_mdls();
    extern void clear_sound();   clear_sound();
    SDL_Quit();
    exit(0);
};

void fatal(char *s, char *o)    // failure exit
{
    s_sprintfd(msg)("%s%s\n", s, o);
    printf(msg);
    #ifdef WIN32
        MessageBox(NULL, msg, "sauerbraten fatal error", MB_OK|MB_SYSTEMMODAL);
    #endif
    exit(1);
};

void die (int sig)
{
#ifdef DBG
    s_sprintfd(msg)("Signal %d at %s:%d\n", sig, vfile, vline);
#else
    s_sprintfd(msg)("Signal %d\n", sig);
#endif
	fatal ("Violation: ", msg);
};

SDL_Surface *screen = NULL;
SDL_Joystick *joystick = NULL;

int curtime;
int lastmillis = 0;

dynent *player = NULL;

int scr_w = 640, scr_h = 480;

void screenshot()
{ dbg;
    SDL_Surface *image;
    SDL_Surface *temp;
    int idx;
    if(image = SDL_CreateRGBSurface(SDL_SWSURFACE, scr_w, scr_h, 24, 0x0000FF, 0x00FF00, 0xFF0000, 0))
    { dbg;
        if(temp  = SDL_CreateRGBSurface(SDL_SWSURFACE, scr_w, scr_h, 24, 0x0000FF, 0x00FF00, 0xFF0000, 0))
        { dbg;
            glReadPixels(0, 0, scr_w, scr_h, GL_RGB, GL_UNSIGNED_BYTE, image->pixels);
            for (idx = 0; idx<scr_h; idx++)
            { dbg;
                char *dest = (char *)temp->pixels+temp->pitch*idx;
                memcpy(dest, (char *)image->pixels+image->pitch*(scr_h-1-idx), 3*scr_w);
                endianswap(dest, 3, scr_w);
            };
            s_sprintfd(buf)("screenshot_%li.bmp", time (NULL));
            SDL_SaveBMP(temp, buf);
            SDL_FreeSurface(temp);
        };
        SDL_FreeSurface(image);
    };
};

COMMAND(screenshot, "");
COMMAND(quit, "");

void bar(float bar, int x, int y, int w, int h, float r, float g, float b)
{ dbg;
		int rx = x*3, ry = y*3, rw = w*3, rh = h*3;
        glColor3f(r, g, b);
        glVertex2f(rx, ry);
        glVertex2f(bar*(rx+rw), ry);
        glVertex2f(bar*(rx+rw), ry+rh);
        glVertex2f(rx, ry+rh);
};

string cst;
bool css;

void computescreen(char *text, bool sht, bool swap)
{ dbg;
    int w = scr_w, h = scr_h;
    gettextres(w, h);

    loopi(2)
    { dbg;
        int rx = (w-68), ry = 0, rw = rx+64, rh = ry+32;
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, w*3, h*3, 0, -1, 1);
        glClearColor(0.0f, 0.0f, 0.0f, 1);
        glClear(GL_COLOR_BUFFER_BIT);
        glEnable(GL_BLEND);
        glEnable(GL_TEXTURE_2D);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);

        draw_text(text, 30, 16);

        glLoadIdentity();
        glOrtho(0, w, h, 0, -1, 1);

        settexture("data/sauer_logo_512_256.png");
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glBegin(GL_QUADS);
        glTexCoord2f(0, 0); glVertex2i(rx, ry);
        glTexCoord2f(1, 0); glVertex2i(rw, ry);
        glTexCoord2f(1, 1); glVertex2i(rw, rh);
        glTexCoord2f(0, 1); glVertex2i(rx, rh);
        glEnd();

		if (sht)
		{
			extern string shtname;
		    glDisable(GL_BLEND);
		    
	        if (!settexture(shtname))
	        {
		        strcpy(shtname+strlen(shtname)-3, "png"); // try png if no jpg
		        
		        if (!settexture(shtname))
		        {
			        strcpy(shtname+strlen(shtname)-3, "bmp"); // try bmp then.. ugh
		
			        if (!settexture(shtname))
			        {
				        settexture("data/sauer_logo_512_256.png"); // fine!
					}
				}
			}
	        
			glBegin(GL_QUADS);
	        glTexCoord2f(0, 0); glVertex2i(0, 32);
	        glTexCoord2f(1, 0); glVertex2i(w, 32);
	        glTexCoord2f(1, 1); glVertex2i(w, h-32);
	        glTexCoord2f(0, 1); glVertex2i(0, h-32);
	        glEnd();
		}
        if (swap) SDL_GL_SwapBuffers();
    };
	s_sprintf(cst)("%s", text);
	css = sht;
};

void show_out_of_renderloop_progress(float bar1, const char *fmt, ...)   // also used during loading
{ dbg;
    if(!inbetweenframes) return;

	s_sprintfdlv(text,fmt,fmt);

    clientkeepalive();      // make sure our connection doesn't time out while loading maps etc.

	computescreen(cst, css, false);

    int w = scr_w, h = scr_h;
    gettextres(w, h);

    glDisable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0, w*3, h*3, 0, -1, 1);
    notextureshader->set();

    glBegin(GL_QUADS);
    bar(bar1, 0, h-32, w, 32, 0.0f, 0.0f, 0.5f);
    glEnd();

    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    defaultshader->set();

    if(text) draw_text(text, 30, (h-28)*3);

    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);

    glPopMatrix();
    glEnable(GL_DEPTH_TEST);
    SDL_GL_SwapBuffers();
}

void fullscreen()
{ dbg;
#ifdef WIN32
    conoutf("\"fullscreen\" command not supported on this platform. Use the -t command-line option.");
#else
    SDL_WM_ToggleFullScreen(screen);
    SDL_WM_GrabInput((screen->flags&SDL_FULLSCREEN) ? SDL_GRAB_ON : SDL_GRAB_OFF);
#endif
}

void screenres(int *w, int *h, int *bpp = 0)
{ dbg;
#ifdef WIN32
    conoutf("\"screenres\" command not supported on this platform. Use the -w and -h command-line options.");
#else
    SDL_Surface *surf = SDL_SetVideoMode(*w, *h, bpp ? *bpp : 0, SDL_OPENGL|SDL_RESIZABLE|(screen->flags&SDL_FULLSCREEN));
    if(!surf) return;
    scr_w = *w;
    scr_h = *h;
    screen = surf;
    glViewport(0, 0, *w, *h);
#endif
}

COMMAND(fullscreen, "");
COMMAND(screenres, "iii");

void keyrepeat(bool on)
{ dbg;
    SDL_EnableKeyRepeat(on ? SDL_DEFAULT_REPEAT_DELAY : 0,
                             SDL_DEFAULT_REPEAT_INTERVAL);
};

VARF(gamespeed, 10, 100, 1000, if(multiplayer()) gamespeed = 100);

int islittleendian = 1;

struct sleepcmd
{
    int millis;
    char *command;
    sleepcmd() : millis(0) {};
};

vector<sleepcmd> sleepcmds;
ICOMMAND(sleep, "ss", { sleepcmd &s = sleepcmds.add(); s.millis=atoi(args[0])+lastmillis; s.command = newstring(args[1]); });
VARF(paused, 0, 0, 1, if(multiplayer()) paused = 0);

void estartmap(const char *name)
{ dbg;
    ///if(!editmode) toggleedit();
    gamespeed = 100;
    paused = 0;
    loopv(sleepcmds) delete[] sleepcmds[i].command;
    sleepcmds.setsize(0);
    cancelsel();
    pruneundos();
    setvar("wireframe", 0);
    cl->startmap(name);
};

VAR(maxfps, 5, 200, 500);

void limitfps(int &millis, int curmillis)
{ dbg;
    static int fpserror = 0;
    int delay = 1000/maxfps - (millis-curmillis);
    if(delay < 0) fpserror = 0;
    else
    { dbg;
        fpserror += 1000%maxfps;
        if(fpserror >= maxfps)
        { dbg;
            ++delay;
            fpserror -= maxfps;
        };
        if(delay > 0)
        { dbg;
            SDL_Delay(delay);
            millis += delay;
        };
    };
};

#if defined(WIN32) && !defined(_DEBUG) && !defined(__GNUC__)
void stackdumper(unsigned int type, EXCEPTION_POINTERS *ep)
{
    if(!ep) fatal("unknown type");
    EXCEPTION_RECORD *er = ep->ExceptionRecord;
    CONTEXT *context = ep->ContextRecord;
    string out, t;
    s_sprintf(out)("Sauerbraten Win32 Exception: 0x%x [0x%x]\n\n", er->ExceptionCode, er->ExceptionCode==EXCEPTION_ACCESS_VIOLATION ? er->ExceptionInformation[1] : -1);
    STACKFRAME sf = {{context->Eip, 0, AddrModeFlat}, {}, {context->Ebp, 0, AddrModeFlat}, {context->Esp, 0, AddrModeFlat}, 0};
    SymInitialize(GetCurrentProcess(), NULL, TRUE);

    while(::StackWalk(IMAGE_FILE_MACHINE_I386, GetCurrentProcess(), GetCurrentThread(), &sf, context, NULL, ::SymFunctionTableAccess, ::SymGetModuleBase, NULL))
    {
        struct { IMAGEHLP_SYMBOL sym; string n; } si = { { sizeof( IMAGEHLP_SYMBOL ), 0, 0, 0, sizeof(string) } };
        IMAGEHLP_LINE li = { sizeof( IMAGEHLP_LINE ) };
        DWORD off;
        if(SymGetSymFromAddr(GetCurrentProcess(), (DWORD)sf.AddrPC.Offset, &off, &si.sym) && SymGetLineFromAddr(GetCurrentProcess(), (DWORD)sf.AddrPC.Offset, &off, &li))
        {
            char *del = strrchr(li.FileName, '\\');
            s_sprintf(t)("%s - %s [%d]\n", si.sym.Name, del ? del + 1 : li.FileName, li.LineNumber);
            s_strcat(out, t);
        };
    };
    fatal(out);
};
#endif

bool inbetweenframes = false;

int main(int argc, char **argv)
{
    #ifdef WIN32
    //atexit((void (__cdecl *)(void))_CrtDumpMemoryLeaks);
    #ifndef _DEBUG
    #ifndef __GNUC__
    __try {
    #endif
    #endif
    #endif

    bool dedicated = false;
    int fs = SDL_FULLSCREEN, par = 0, depth = 0, bpp = 0, fsaa = 0;
    char *load = "mode -2; map tesseract/test";
    
    islittleendian = *((char *)&islittleendian);

#ifndef WIN32
  	signal (SIGBUS, die);
  	signal (SIGTRAP, die);
  	signal (SIGSYS, die);
  	signal (SIGQUIT, die);
  	signal (SIGKILL, die);
  	signal (SIGHUP, die);
#endif
  	signal (SIGFPE, die);
  	signal (SIGILL, die);
  	signal (SIGSEGV, die);
  	signal (SIGABRT, die);
  	signal (SIGTERM, die);
  	signal (SIGINT, die);

    #define log(s) puts("init: " s)
    log("sdl");

    for(int i = 1; i<argc; i++)
    { dbg;
        if(argv[i][0]=='-') switch(argv[i][1])
        {
            case 'd': dedicated = true; break;
            case 'w': scr_w = atoi(&argv[i][2]); scr_h = scr_w*3/4; break;
            case 'h': scr_h = atoi(&argv[i][2]); break;
            case 'z': depth = atoi(&argv[i][2]); break;
            case 'b': bpp = atoi(&argv[i][2]); break;
            case 'a': fsaa = atoi(&argv[i][2]); break;
            case 't': fs = 0; break;
            case 'f': 
            { dbg;
                extern int shaderprecision; 
                shaderprecision = atoi(&argv[i][2]); 
                shaderprecision = min(max(shaderprecision, 0), 3);
                break;
            };
            case 'v': 
            { dbg;
                extern int novbo; 
                novbo = 1; 
                break;
            };
            case 'l': 
            { dbg;
                load = &argv[i][2]; 
                break;
            };
            default:  if(!serveroption(argv[i])) conoutf("unknown commandline option");
        }
        else conoutf("unknown commandline argument");
    };

    #ifdef _DEBUG
    par = SDL_INIT_NOPARACHUTE;
    fs = 0;
    SetEnvironmentVariable("SDL_DEBUG", "1");
    #endif

    //#ifdef WIN32
    //SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
    //#endif

    if(SDL_Init(SDL_INIT_TIMER|SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_JOYSTICK|par)<0) fatal("Unable to initialize SDL: ", SDL_GetError());

    log("enet");
    if(enet_initialize()<0) fatal("Unable to initialise network module");

    initserver(dedicated);  // never returns if dedicated

    log("video: mode");
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    if(depth) SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, depth); 
    if(fsaa)
    { dbg;
        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
        SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, fsaa);
    };
    screen = SDL_SetVideoMode(scr_w, scr_h, bpp, SDL_OPENGL|SDL_RESIZABLE|fs);
    if(screen==NULL) fatal("Unable to create OpenGL screen: ", SDL_GetError());

    log("video: misc");
    SDL_WM_SetCaption("sauerbraten engine", NULL);
    #ifndef WIN32
    if(fs)
    #endif
    SDL_WM_GrabInput(SDL_GRAB_ON);
    keyrepeat(false);
    SDL_ShowCursor(0);

	log("input: joystick");
    SDL_JoystickEventState(SDL_ENABLE);
    if (!(joystick = SDL_JoystickOpen(0)))
		log("input: cannot open joystick");

    log("console");
    persistidents = 0;
    if(!execfile("tesseract/data/stdlib.cfg")) fatal("cannot find data files (you are running from the wrong folder, try .bat file in the main folder)");   // this is the first file we load.

    log("gl");
    gl_init(scr_w, scr_h, bpp, depth, fsaa);
    crosshair = textureload(newstring("data/crosshair.png"));
    if(!crosshair) fatal("could not find core textures");
    computescreen("initializing...", false, true);
    inbetweenframes = true;
    particleinit();

    log("world");
    camera1 = player = cl->iterdynents(0);
    empty_world(7, true);

    log("sound");
    initsound();

    log("cfg");
    newmenu("frags\tpj\tping\tteam\tname");
    newmenu("ping\tplr\tserver");
    exec("tesseract/data/keymap.cfg");
//    exec("tesseract/data/map.cfg");
    exec("tesseract/data/menus.cfg");
    exec("tesseract/data/sounds.cfg");
    exec("tesseract/data/brush.cfg");
    execfile("tesseract/data/mybrushes.cfg");
    execfile("tesseract/data/servers.cfg");
    
    persistidents = 1;
    
    if(!execfile("tesseract/data/config.cfg")) exec("tesseract/data/defaults.cfg");
    execfile("tesseract/autoexec.cfg");

    persistidents = 0;

    string gamecfgname;
    s_strcpy(gamecfgname, "tesseract/data/game_");
    s_strcat(gamecfgname, cl->gameident());
    s_strcat(gamecfgname, ".cfg");
    exec(gamecfgname);

    persistidents = 1;

    log("localconnect");
    localconnect();
    cc->gameconnect(false);
    //cc->changemap(load ? load : "test");
    execute(load);

    log("mainloop");
    int ignore = 5, grabmouse = 0;
    for(;;)
    { dbg;
        static int frames = 0;
        static float fps = 10.0;
        static int curmillis = 0;
        int millis = SDL_GetTicks();
        limitfps(millis, curmillis);
        int elapsed = millis-curmillis;
        curtime = elapsed*gamespeed/100;
        if(curtime>200) curtime = 200;
        else if(curtime<1) curtime = 1;
        if(paused) curtime = 0;
        if(lastmillis) cl->updateworld(worldpos, curtime, lastmillis);
        loopv(sleepcmds)
        { dbg;
            sleepcmd &s = sleepcmds[i];
            if(s.millis && lastmillis>s.millis)
            { dbg;
                execute(s.command);
                delete[] s.command;
                sleepcmds.remove(i);
                i--;
            };
        };

        lastmillis += curtime;
        curmillis = millis;

        serverslice(time(NULL), 0);

        frames++;
        fps = (1000.0f/elapsed+fps*10)/11;
        //if(curtime>14) printf("%d: %d\n", millis, curtime);

        extern void updatevol(); updatevol();

        inbetweenframes = false;
        SDL_GL_SwapBuffers();
        if(frames>2) gl_drawframe(scr_w, scr_h, fps);
        //SDL_Delay(10);
        inbetweenframes = true;
        
        joyupdate(curtime);

        SDL_Event event;
        int lasttype = 0, lastbut = 0;
        while(SDL_PollEvent(&event))
        { dbg;
            switch(event.type)
            {
                case SDL_QUIT:
                    quit();
                    break;

                #ifndef WIN32
                case SDL_VIDEORESIZE:
                    screenres(&event.resize.w, &event.resize.h);
                    break;
                #endif

                case SDL_KEYDOWN:
                case SDL_KEYUP:
                    keypress(event.key.keysym.sym, event.key.state==SDL_PRESSED, event.key.keysym.unicode);
                    break;

                case SDL_JOYBUTTONDOWN:
                case SDL_JOYBUTTONUP:
					{
						int code = ((0-6)-event.jbutton.button);
                    	keypress(code, event.jbutton.state==SDL_PRESSED, 0);
					}
                    break;

				case SDL_JOYAXISMOTION:
                    joymove(event.jaxis.axis, event.jaxis.value);
                    break;

                case SDL_ACTIVEEVENT:
                    if(event.active.state & SDL_APPINPUTFOCUS)
                        grabmouse = event.active.gain;
                    else
                    if(event.active.gain)
                        grabmouse = 1;
                    break;

                case SDL_MOUSEMOTION:
                    if(ignore) { ignore--; break; };
                    if(!(screen->flags&SDL_FULLSCREEN) && grabmouse)
                    { dbg;
                        if(event.motion.x == scr_w / 2 && event.motion.y == scr_h / 2) break;
                        SDL_WarpMouse(scr_w / 2, scr_h / 2);
                    };
                    #ifndef WIN32
                    if((screen->flags&SDL_FULLSCREEN) || grabmouse)
                    #endif
                    mousemove(event.motion.xrel, event.motion.yrel);
                    break;

                case SDL_MOUSEBUTTONDOWN:
                case SDL_MOUSEBUTTONUP:
                    if(lasttype==event.type && lastbut==event.button.button) break; // why?? get event twice without it
                    keypress(0-(event.button.button%6), event.button.state!=0, 0);
                    lasttype = event.type;
                    lastbut = event.button.button;
                    break;
            };
        };
    };
    
    ASSERT(0);   
    return 0;

    #if defined(WIN32) && !defined(_DEBUG) && !defined(__GNUC__)
    } __except(stackdumper(0, GetExceptionInformation()), EXCEPTION_CONTINUE_SEARCH) { return 0; };
    #endif
};
