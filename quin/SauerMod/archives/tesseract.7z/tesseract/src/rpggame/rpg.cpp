
#include "pch.h"
#include "cube.h"
#include "iengine.h"
#include "igame.h"

struct rpgdummycom : iclientcom
{
    ~rpgdummycom() {};

    void gamedisconnect() {};
    void parsepacketclient(uchar *end, uchar *p) {};
    void sendpacketclient(uchar *&p, bool &reliable, dynent *d) {};
    void receivefile(uchar *data, int len) {};
    void gameconnect(bool _remote) {};
    bool allowedittoggle() { return true; };
    void writeclientinfo(FILE *f) {};
    void toserver(char *text) {};
    void changemap(char *name) { name = "rpg_01"; load_world(name); }; // TEMP!!! override start map
};

struct rpgdummyserver : igameserver
{
    ~rpgdummyserver() {};

    void *newinfo() { return NULL; };
    void resetinfo(void *ci) {};
    void serverinit(char *sdesc, char *adminpass) {};
    void clientdisconnect(int n) {};
    int clientconnect(int n, uint ip) { return DISC_NONE; };
    void localdisconnect(int n) {};
    void localconnect(int n) {};
    char *servername() { return "foo"; };
    bool parsepacket(int sender, uchar *&p, uchar *end) { p = end; return true; };
    void welcomepacket(uchar *&p, int n) {};
    void serverinforeply(uchar *&p) {};
    void serverupdate(int seconds) {};
    bool servercompatible(char *name, char *sdec, char *map, int ping, const vector<int> &attr, int np) { return false; };
    void serverinfostr(char *buf, const char *name, const char *desc, const char *map, int ping, const vector<int> &attr, int np) {};
    int serverinfoport() { return 0; };
    int serverport() { return 0; };
    char *getdefaultmaster() { return "localhost"; };
    void sendservmsg(const char *s) {};
    void receivefile(int sender, uchar *data, int len) {};
};

struct rpgent : dynent
{
    int lastaction, lastpain;
    
    rpgent() : lastaction(0), lastpain(0) {};
};

struct rpgclient : igameclient
{
    #include "entities.h"
    #include "behaviours.h"
    #include "rpgobjset.h"

    rpgentities et;
    rpgdummycom cc;
    rpgobjset os;
    
    rpgent player1;

    int lastmillis;
    string mapname;
    
    char *curaction;

    rpgclient() : et(*this), os(*this), lastmillis(0), curaction(NULL)
    {
        CCOMMAND(rpgclient, map, "s", load_world(args[0]));    
    };
    ~rpgclient() {};

    icliententities *getents() { return &et; };
    iclientcom *getcom() { return &cc; };

    void updateworld(vec &pos, int curtime, int lm)
    { dbg;
        lastmillis = lm;
        if(!curtime) return;
        physicsframe();
        os.update(curtime);
        if(player1.state==CS_DEAD)
        { dbg;
            player1.lastaction = lastmillis;
        }
        else
        { dbg;
            moveplayer(&player1, 20, true);
            checktriggers();
        };
    };
    
    void initclient() {};
        
    void physicstrigger(physent *d, bool local, int floorlevel, int waterlevel)
    { dbg;
        if     (waterlevel>0) playsoundname("free/splash1", d==&player1 ? NULL : &d->o);
        else if(waterlevel<0) playsoundname("free/splash2", d==&player1 ? NULL : &d->o);
        if     (floorlevel>0) { if(local) playsoundname("aard/jump"); else if(d->type==ENT_AI) playsoundname("aard/jump", &d->o); }
        else if(floorlevel<0) { if(local) playsoundname("aard/land"); else if(d->type==ENT_AI) playsoundname("aard/land", &d->o); };    
    };
    
    void edittrigger(const selinfo &sel, int op, int arg1 = 0, int arg2 = 0, int arg3 = 0, int arg4 = 0, int arg5 = 0, int arg6 = 0) {};
    char *getclientmap() { return mapname; };
    void resetgamestate() {};
    void worldhurts(physent *d, int damage) {};
    
    void startmap(const char *name)
    { dbg;
        os.clearworld();
        s_strcpy(mapname, name);
        findplayerspawn(&player1);
        et.startmap();
    };
    
    void gameplayhud(int w, int h) {};
    
    void drawhudgun() {};
    bool camerafixed() { return player1.state==CS_DEAD; };
    bool canjump() { return true; };
    bool cancrouch() { return true; };
    void doattack(bool on) {};
    dynent *iterdynents(int i) { return i ? NULL : &player1; };
    int numdynents() { return 1; };
    void renderscores() {};

    void rendergame()
    { dbg;
        if(isthirdperson()) renderclient(&player1, false, "monster/ogro", false, player1.lastaction, player1.lastpain);
        os.render();
    };
    
    void treemenu()
    { dbg;
        settreeca(&curaction);
        if(os.pointingat)
        { dbg;
            os.pointingat->treemenu();
        };
        
        if(treebutton("attack", "sword.jpg")&TMB_PRESSED) { conoutf("attack"); };
        if(treebutton("inventory", "chest.jpg")&TMB_UP) { conoutf("inventory"); };
    };

    void writegamedata(vector<char> &extras) {};
    void readgamedata(vector<char> &extras) {};

    char *gameident() { return "rpg"; };
};

REGISTERGAME(rpggame, "rpg", new rpgclient(), new rpgdummyserver());

