
struct rpgobj;

struct behaviour
{
    rpgobj *o;
    
};

struct idlebehaviour : behaviour
{

};
